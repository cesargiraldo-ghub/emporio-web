export default {
	namespaced: true,
	state: () => ({
		proprietors: []
	})
}