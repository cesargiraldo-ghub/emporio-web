export default {
	namespaced: true,
	state: () => ({
		current: null,
		products: [],
		productsData: [],
	})
}