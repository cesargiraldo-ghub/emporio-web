export default {
	namespaced: true,
	state: () => ({
		customers: [],
		leaseholders: [],
		proprietors: []
	})
}