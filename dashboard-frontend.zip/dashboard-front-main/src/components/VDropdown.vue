<template>
  <div :class="{'pointer-events-none': disabled}" class="inline-block relative">
    <button type="button" ref="btn" class="outline-none" @click="show = !show" @blur="show = false">
      <slot></slot>
    </button>
    <transition name="slide-down" mode="out-in" :duration="400">
      <div
        v-if="show"
				:class="position"
        class="absolute shadow-md rounded bg-white z-10 flex flex-col divide-y leading-relaxed"
      >
        <slot name="options" className="px-3 py-2 cursor-pointer"></slot>
      </div>
    </transition>
  </div>
</template>
<script setup>
import { ref, computed, defineProps } from "vue";

const props = defineProps({
	position: {
		type: String,
		default: 'bottom'
	},
  blurClose: {
    type: Boolean,
    default: true
  },
  disabled: {
    type: Boolean,
    default: false
  }
});

const show = ref(false);
const position = computed(() => {
	switch(props.position){
		case 'top':
			return 'bottom-full'
		default:
		return 'top-full'
	}
});

</script>
