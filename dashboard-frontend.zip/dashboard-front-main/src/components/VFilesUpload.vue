<template>
  <div class="relative overflow-hidden flex flex-col gap-4">
    <div
      v-if="multiple"
      class="flex flex-wrap gap-4 justify-end items-end border-b border-gray-200 pb-4"
    >
      <div class="mr-auto" v-if="multiple">
        Hay <b class="font-semibold">{{ modelValue.length }}</b> elementos
      </div>
      <template v-if="tools">
        <label
          v-if="!hideUpload && !multiSelect"
          :for="`input_file_${$.uid}`"
          class="inline-block cursor-pointer"
        >
          <VButton
            :icon="faPlus"
            bgColor="bg-green-500"
            class="font-medium pointer-events-none"
          />
        </label>
        <VButton
          :disabled="!values.length"
          v-if="multiSelect && !hideDelete"
          @click="onDeleteMulti"
          bgColor="bg-red-500"
          :icon="faTrash"
        />
        <template v-if="!hideSelect">
          <VButton
            v-if="multiSelect"
            @click="onCheckAll"
            bgColor="bg-amber-500"
            :icon="checkAll ? faSquare : faSquareCheck"
          />
          <VButton
            v-if="hasElementes"
            @click="multiSelect = !multiSelect"
            bgColor="bg-blue-500"
            :icon="multiSelect ? faGrip : faListCheck"
          />
        </template>
      </template>
    </div>
    <input
      type="file"
      :multiple="multiple"
      :id="`input_file_${$.uid}`"
      @change="onChange"
      class="hidden"
    />
    <div
      ref="gallery"
      class="select-none w-full"
      :settings="{ licenseKey: '0000-0000-000-0000`' }"
    >
      <template v-if="hasElementes">
        <div
          class="overflow-y-auto w-full"
          :class="{
            'max-sm:aspect-[2/2.5]': modelValue.length > 4,
            'max-md:aspect-[3/2.5]': modelValue.length > 6,
            [cols.aspect]: modelValue.length > columns * 2,
          }"
        >
          <div class="grid" :class="cols.cols">
            <template v-if="modelValue">
              <div
                v-for="(value, index) in modelValue"
                :key="`image-${value.public_id}`"
                class="shadow-md bg-blue-200 rounded-lg aspect-square overflow-hidden relative pointer-events-auto"
                @click="onClickCheck($event, index)"
              >
                <VCheckItem
                  v-if="multiSelect && !hideSelect"
                  class="absolute inset-0 flex justify-end items-start p-2 bg-white bg-opacity-40"
                  @change="onChangeCheck(checkValue(value))"
                  :value="checkValue(value)"
                  :showLabel="false"
                  :checked="onChecked(checkValue(value))"
                />
                <a
                  v-bind="value.format == 'pdf' ? { 'data-type': 'iframe' } : {}"
                  data-fancybox="gallery"
                  :href="fullImage(value)"
                >
                  <img :src="image(value)" />
                </a>
                <span
                  :class="onColorFormat(value.format)"
                  class="absolute z-10 bottom-2 left-2 rounded-md leading-none px-3 py-1 text-white uppercase font-bold text-xs"
                >
                  {{ value.format }}
                </span>
                <span
                  v-if="!multiSelect && tools && !hideDelete"
                  @click="onDelete(value)"
                  class="absolute z-10 top-2 right-2 w-4 aspect-square text-red-500 bg-white shadow rounded-md cursor-pointer"
                >
                  <fa-icon
                    class="absolute inset-0 m-auto"
                    :icon="faClose"
                  ></fa-icon>
                </span>
              </div>
            </template>
            <template v-if="pendint">
              <div
                class="shadow-md bg-gray-200 rounded-lg aspect-square p-4 flex items-center"
              >
                <span
                  class="flex w-full h-2 rounded-full overflow-hidden bg-gray-300"
                >
                  <span
                    class="w-0 h-full bg-emerald-500 rounded-full transition-[width] duration-150"
                    :style="{ width: `calc(100% * ${progress})` }"
                  >
                  </span>
                </span>
              </div>
              <template v-if="pendint > 1">
                <div
                  v-for="i in pendint - 1"
                  :key="`pendint-${i}`"
                  class="shadow-md bg-gray-200 rounded-lg aspect-square flex"
                >
                  <fa-icon
                    class="text-4xl text-gray-600 opacity-50 m-auto animate-spin"
                    :icon="faCircleNotch"
                  ></fa-icon>
                </div>
              </template>
            </template>
          </div>
        </div>
      </template>
      <template v-else>
        <div class="relative rounded bg-gray-100 p-5" :class="{'aspect-square': !multiple}">
          {{message}}
          <label
            v-if="!multiple && !hideUpload && tools"
            :for="`input_file_${$.uid}`"
            class="inline-block cursor-pointer absolute bottom-2 right-2"
          >
            <VButton
              :icon="faPlus"
              bgColor="bg-green-500"
              class="font-medium pointer-events-none"
            />
          </label>
        </div>
      </template>
    </div>
  </div>
</template>
<script setup>
import { faClose, faCircleNotch, faListCheck, faPlus, faGrip, faTrash } from "@fortawesome/free-solid-svg-icons";
import { faSquare, faSquareCheck } from "@fortawesome/free-regular-svg-icons";

import {
  defineProps,
  defineEmits,
  watch,
  ref,
  computed,
  onMounted,
  onUpdated,
  onUnmounted,
} from "vue";
import VCheckItem from "@/components/VForm/VCheck/VCheckItem";
import { Fancybox } from "@fancyapps/ui";
import "@fancyapps/ui/dist/fancybox/fancybox.css";

import VButton from "@/components/VButton";

const emit = defineEmits([
  "update:modelValue",
  "onDelete",
  "onLoad",
  "onChange",
  "onDeleteMulti",
]);
const props = defineProps({
  columns: {
    type: Number,
    default: 6,
  },
  label: {
    type: String,
    default: "Picture",
  },
  multiple: {
    type: Boolean,
    default: true,
  },
  tools: {
    type: Boolean,
    default: true,
  },
  hideUpload: {
    type: Boolean,
    default: false,
  },
  hideDelete: {
    type: Boolean,
    default: false,
  },
  hideSelect: {
    type: Boolean,
    default: false,
  },
  textAddFile: {
    type: String,
    default: "Agregar documentos",
  },
  image: {
    type: Function,
    default: (i) => i,
  },
  fullImage: {
    type: Function,
    default: (i) => i,
  },
  checkValue: {
    type: Function,
    default: (i) => i,
  },
  pendint: {
    type: Number,
    default: 0,
  },
  progress: {
    type: Number,
    default: 0,
  },
  message: {
    type: String,
    default: "No hay archivos registrados",
  },
  modelValue: {
    type: Array,
    default: () => [],
  },
});

const hasElementes = computed(() => props.modelValue?.length)

const cols = computed(() => {
  switch (props.columns) {
    case 1: 
      return { cols: "grid-cols-1", aspect: "aspect-square" };
    case 4:
      return { cols: "grid-cols-2 sm:grid-cols-3 gap-5 md:grid-cols-4", aspect: "md:aspect-[4/2.5]" };
    case 5:
      return { cols: "grid-cols-2 sm:grid-cols-3 gap-5 md:grid-cols-5", aspect: "md:aspect-[5/2.5]" };
    default:
      return { cols: "grid-cols-2 sm:grid-cols-3 gap-5 md:grid-cols-6", aspect: "md:aspect-[6/2.5]" };
  }
});

const gallery = ref(null);

const initFancybox = () => {
  Fancybox.bind(gallery.value, "[data-fancybox]", {
    Thumbs: {
      type: "modern",
      showOnStart: false,
    },
  });
};

onMounted(() => {
  initFancybox();
});

onUpdated(() => {
  Fancybox.unbind(gallery.value);
  Fancybox.close();

  initFancybox();
});

onUnmounted(() => {
  Fancybox.destroy();
});

const onColorFormat = (format) => {
  switch (format) {
    case "pdf":
      return "bg-red-500";
    case "jpg":
      return "bg-blue-500";
    case "png":
      return "bg-teal-500";
    case "mp4":
      return "bg-violet-500";
    default:
      return "bg-slate-500";
  }
};

const multiSelect = ref(false);
const values = ref([]);
const onChangeCheck = (value) => {
  if (values.value.includes(value)) {
    let index = values.value.indexOf(value);
    if (index > -1) {
      values.value.splice(index, 1);
    }
  } else {
    values.value.push(value);
  }
  values.value.sort();
};

const currentCheck = ref(null);

const onChecked = (value) => {
  return values.value.includes(value);
};

const checkAll = computed(() => values.value.length == props.modelValue?.length);
const onCheckAll = () => {
  if (checkAll.value) {
    values.value = [];
  } else {
    values.value = props.modelValue.map((item) => props.checkValue(item));
    values.value.sort();
  }
};

const onClickCheck = (event, index) => {
  if (event.pointerId == 1) {
    if (event.shiftKey) {
      props.modelValue.forEach((item, i) => {
        let value = props.checkValue(item);
        if (
          (i > currentCheck.value && i < index) ||
          (i < currentCheck.value && i > index)
        ) {
          if (values.value.includes(value)) {
            let index = values.value.indexOf(value);
            if (index > -1) {
              values.value.splice(index, 1);
            }
          } else {
            values.value.push(value);
          }
          values.value.sort();
        }
      });
    }
    currentCheck.value = index;
  }
};

const onChange = ({ target }) => {
  const values = target.files;
  emit("onChange", { target, values });
};

const onDeleteMulti = () => {
  emit("onDeleteMulti", values.value);
  values.value = [];
};

watch(
  () => props.modelValue,
  (a) => {
    if (a && a.length == 0) multiSelect.value = false;
  }
);

const onLoad = () => {
  emit("onLoad");
};

watch(
  () => props.image,
  () => {
    onLoad();
  }
);

const onDelete = (value) => {
  emit("onDelete", value);
};
</script>
