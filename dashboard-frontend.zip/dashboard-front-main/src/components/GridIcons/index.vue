<template>
	<div class="flex flex-col gap-4">
		<div class="flex flex-col">
			<div>
				{{source}}
			</div>
			<template v-for="(input, name) in filter" :key="`input_${$.uid}_${name}`">
				<VInput v-bind="input" :name="name" v-model="input.value"></VInput>
			</template>
		</div>
		<div class="grid grid-cols-4 gap-6">
			<template v-if="items.length">
				<div class="grid grid-cols-1 gap-4 text-center justify-center rounded shadow bg-white p-5 overflow-hidden" v-for="(key, index) in items" :key="index">
					<i class="w-10 aspect-[5/4] relative block mx-auto">
						<fa-icon class="absolute inset-0 w-full h-full" :icon="icons[key]"/>	
					</i>
					<span class="overflow-ellipsis overflow-hidden block">
						{{key}}
					</span>
				</div>
			</template>
			<template v-else>
				<div class="col-span-4">
					No hay iconos registrados
				</div>
			</template>
		</div>
		<div class="mx-auto">
			<VPagination :pages="pagination.pages" v-model:current="list.current"></VPagination>
		</div>
	</div>
</template>
<script>
import { faSearch } from '@fortawesome/free-solid-svg-icons'
import VPagination from "@/components/VPagination"
import VInput from "@/components/VForm/VInput";

export default {
	name: 'VGridIcons',
	components: {
		VPagination,
		VInput
	},
	props: {
		icons: {
			type: Object,
			default: null
		},
		source: {
			type: String,
			default: ''
		}
	},
	data() {
		const keys = Object.keys(this.icons);
		keys.sort();

		return {
			list: {
				keys,
				items: keys,
				current: 1,
				perPage: 24
			},
			filter : {
				icon: {
					value: null,
					icon: faSearch,
					attr: {
						type: "text",
						placeholder:"Buscar icono..."
					},
				}
			}
		}
	},
	computed: {
		items(){
			return this.list.items.slice(this.pagination.start, this.pagination.end)
		},
		pagination(){
			let start = (this.list.current - 1)   * this.list.perPage;
			let end = start + this.list.perPage;
			let result = this.list.items.length / this.list.perPage
			return  {
				pages: result < 1 ? Math.ceil(result) : Math.floor(result),
				start, 
				end
			};
		}
	},
	mounted(){
		this.onFilter();
	},
	methods: {
		onFilter(){
			let fields = this.filter;
			for(let prop in fields){
				this.$watch(() => fields[prop].value, (value) => {
					this.list.current = 1;
					this.list.items = this.list.keys.filter(item => {
						let a = item.toLowerCase().replace(/ /gi, "");
						let b = value.toLowerCase().replace(/ /gi, "");

						return a.includes(b);
					})
				})
			}
		}
	}
}
</script>
<style lang="css" scoped>
</style>