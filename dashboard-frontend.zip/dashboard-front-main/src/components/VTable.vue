<template>
  <table class="VTable" :class="{ 'hide-thead': !thead }">
    <thead v-if="thead">
      <tr>
				<th v-if="move"></th>
				<th v-if="selected"></th>

        <template v-if="columns.length">
          <template v-for="col in columns" :key="`th_${$.uid}_${col.field}`">
            <th
              :class="col.class"
              v-if="col?.can ? col.can.includes(true) : true"
            >
              {{ col.label }}
            </th>
          </template>
        </template>
        <template v-else>
          <th v-for="(value, field) in rows[0]" :key="`th_${$.uid}_${field}`">
            {{ field }}
          </th>
        </template>
      </tr>
    </thead>
    <tbody v-if="rows.length == 0">
      <tr key="no-found">
        <td :colspan="columns.length + 1" class="empty justify-center !text-center">
          {{ empty }}
        </td>
      </tr>
    </tbody>
    <VueDraggable
      v-else
      :list="rows"
      item-key="id"
      tag="tbody"
      handle=".handle"
			@change="onMove"
    >
      <template #item="{ element: item, index }">
        <tr class="list-table-tr">
          <td  class="!w-full lg:!w-10" v-if="move">
            <span class="handle cursor-move opacity-60">
              <fa-icon :icon="faArrows"></fa-icon>
            </span>
          </td>
          
          <td class="!w-full lg:!w-auto" v-if="selected">
            <VCheckItem
              @change="onSelectRow($event, item)"
              :checked="row == item"
              :showLabel="false"
              class="py-2 px-4 -my-2 -mx-4 block cursor-pointer"
            />
          </td>

          <template v-if="columns.length">
            <td
              v-for="col in columns"
              :key="`td_${$.uid}_${col.field}`"
              :class="[col.class, { 'hidden-label': col.hiddenLabel }]"
              :data-label="col.label"
            >
              <slot
                name="item"
                :row="item"
                :column="col.field"
                :value="item[col.field]"
                :index="index"
              >
                <slot
                  :name="col.field"
                  :value="item[col.field]"
                  :column="col.field"
                  :row="item"
                  :index="index"
                >
                  {{ item[col.field] }}
                </slot>
              </slot>
            </td>
          </template>

          <template v-else>
            <td v-for="(value, field) in item" :key="`td_${$.uid}_${field}`">
              <slot
                :name="field"
                :value="value"
                :column="col.field"
                :row="item"
              >
                {{ value }}
              </slot>
            </td>
          </template>
        </tr>
      </template>
    </VueDraggable>
    <tfoot v-if="tfoot">
      <tr>
        <td>tfoot</td>
      </tr>
    </tfoot>
  </table>
</template>
<script setup>
import { faArrows } from "@fortawesome/free-solid-svg-icons";
import { defineProps, defineEmits, ref } from "vue";
import VCheckItem from "@/components/VForm/VCheck/VCheckItem";
import VueDraggable from "vuedraggable";
const emits = defineEmits(["rowSelected", "update:modelValue"]);
const props = defineProps({
  selected: {
    type: Boolean,
    default: false,
  },
  move: {
    type: Boolean,
    default: false,
  },
  reverse: {
    type: Boolean,
    default: false,
  },
  empty: {
    type: String,
    default: "No se encontro ningun registro",
  },
  columns: {
    type: Array,
    default: () => [],
  },
  rows: {
    type: Array,
    default: () => [],
  },
  modelValue: {
    type: Array,
    default: () => [],
  },
  thead: {
    type: Boolean,
    default: true,
  },
  tfoot: {
    type: Boolean,
    default: false,
  },
});

const row = ref(null);
const onSelectRow = ({ target }, item) => {
  row.value = target.checked ? item : null;
  emits("rowSelected", row.value);
};

const onMove = ({moved: {newIndex, oldIndex, element}}) => {
	const list = [...props.modelValue]
	list.splice(oldIndex, 1);
	list.splice(newIndex, 0, element);

	list.forEach((item, index, arr) => {
		item.position = props.reverse ? arr.length - index - 1 : index;
	});

	emits("update:modelValue", list);
}

</script>
<style lang="scss">
th {
  @apply text-left;
}
.VTable {
  @apply w-full border-y border-gray-100 rounded;
  thead {
    @apply hidden lg:table-header-group;
  }
  th {
    @apply font-medium;
  }
  tbody {
    @apply relative;
    tr {
      @apply bg-white odd:bg-stone-100 flex flex-col md:flex-row md:flex-wrap lg:table-row py-2 lg:py-0;
    }
    td {
      @apply flex md:flex-col gap-1 lg:table-cell w-full md:w-1/2 lg:w-auto flex-grow;
      &:not(.hidden-label){
        @apply text-right md:text-left
      }
      &.hidden-label {
        &::before {
          @apply hidden #{!important};
        }
      }
      &:not(.empty)::before {
        content: attr(data-label);
        @apply font-semibold text-sm opacity-90 block lg:hidden mr-auto;
      }
    }
  }
  &.hide-thead {
    tr {
      @apply odd:bg-white bg-stone-100;
    }
  }
  tr {
    & > * {
      @apply py-2 px-4;
      &.empty {
        @apply py-6 text-center;
      }
    }
  }
}
.list-table-tr {
  transition: all 1s;
  display: table-row;
  width: 100%;
}
.list-table-enter,
.list-table-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
.list-table-leave-active {
  // position: absolute;
}
</style>
