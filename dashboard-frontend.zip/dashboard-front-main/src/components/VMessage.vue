<template>
	<div class="border-2 border-current border-stone-300 font-semibold text-stone-500 bg-stone-100 rounded-md p-5 flex">
		<span class="m-auto text-center">
			<slot></slot>
		</span>
	</div>
</template>