<template>
	<span class="relative cursor-pointer" @click="onCopyClipboard(textCopy)" :title="title">
		<span class="pointer-events-none bg-emerald-400 text-white font-medium rounded py-1 px-2.5 leading-none absolute bottom-full mb-0.5 left-1/2 -translate-x-1/2 transition ease-out duration-500" :class="copy ? '-translate-y-1 opacity-100' : 'translate-y-2 opacity-0'">
			{{text}}
		</span>
		<span class="inline-flex gap-2">
			<slot></slot>
			<slot name="icon">
				<fa-icon v-if="isSecure && icon" :class="iconClass" :icon="faClone"></fa-icon>
			</slot>
		</span>
	</span>
</template>
<script setup>
import {faClone} from '@fortawesome/free-regular-svg-icons'
import {defineProps, ref, onMounted} from "vue";

defineProps({
	text: {
		type: String,
		default: "Copiado"
	},
	iconClass: {
		type: String,
		default: 'text-emerald-500'
	},
	icon: {
		type: Boolean,
		default: false,
	},
	title: {
		type: String,
		default: "Copiar texto"
	},
	textCopy: {
		type: String,
		required: true
	} 
});

const copy = ref(false);
const isSecure = ref(false);

const onCopyClipboard = (value) => {
	if(isSecure.value){
		copy.value = true;
		navigator.clipboard.writeText(value);
		setTimeout(() => {
			copy.value = false;
		}, 1000);
	}
}

onMounted(() => {
	if(navigator?.clipboard)
		isSecure.value = true
});
	
</script>