<template>
  <div class="relative group">
    <slot></slot>
    <span v-if="text && show" class="group-hover:opacity-100 group-hover:translate-y-0 opacity-0 -translate-y-2 transition duration-500 pointer-events-none p-2 absolute mb-2 bottom-full right-0 rounded-md shadow bg-blue-200 text-blue-500 font-semibold">
      {{ text }}
    </span>
  </div>
</template>

<script setup>
import {defineProps} from "vue";
defineProps({
  text: {
    type: String,
    default: ""
  },
  show: {
    type: Boolean,
    default: true,
  }
})
</script>

<style lang="scss" scoped>

</style>