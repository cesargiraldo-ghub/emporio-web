<template>
	<div class="flex flex-col max-h-full shadow" :class="[setSize, onAside]">
		<div v-if="header" class="px-4 py-3 flex bg-gray-100 sticky z-20 shadow top-0" :class="[['left', 'right'].includes(aside) ? 'rounded-none' : 'rounded-t' ]">
			<slot name="header"></slot>
			<div class="flex flex-row-reverse grow gap-2">
				<button @click="onClose" class="cursor-pointer" v-if="!hideClose">
					<fa-icon class="w-4 aspect-square text-gray-700" :icon="faClose" />
				</button>
				<slot name="top-tools"></slot>
			</div>
		</div>
		<div class="bg-white flex-grow overflow-y-auto max-h-screen" :class="[['left', 'right'].includes(aside) ? 'h-1' : 'h-auto', { 'rounded-b': !footer}, { 'rounded-t': !header}]">
			<div class="p-5">
				<slot></slot>
			</div>
		</div>
		<div v-if="footer" class="px-4 py-3 bg-gray-100 sticky z-10 shadow bottom-0" :class="[['left', 'right'].includes(aside) ? 'rounded-none' : 'rounded-b' ]">
			<slot name="footer"></slot>
		</div>
	</div>
</template>
<script>
import { faClose } from '@fortawesome/free-solid-svg-icons'
export default {

	name: 'VModalWindow',
	inject: ["onClose"],
	props: {
		hideClose: {
			type: Boolean,
			default: false
		},
		size: {
			type: String,
			default: "sm"
		},
		aside: {
			type: String,
			default: ""
		},
		footer: {
			type: Boolean,
			default: true
		},
		header: {
			type: Boolean,
			default: true
		}
	},
	data() {
		return {
			faClose
		}
	},
	mounted(){
		this.$emit('mounted')
	},
	computed: {
		onAside(){
			switch(this.aside){
				case "left":
					return "aside-left min-h-full w-screen"

				case "right":
					return "aside-right min-h-full w-screen"

				default:
					return "rounded m-auto w-full"
			}
		},
		setSize(){
			let size = null;

			switch(this.size){
				case "lg":
					size = "max-w-7xl";
					break;
				case "md":
					size = "max-w-5xl";
					break;
				case "xs":
					size = "max-w-md";
					break;
				default:
					size = "max-w-2xl"
			}

			return size; 
		}
	}
}
</script>
<style lang="css" scoped>
</style>