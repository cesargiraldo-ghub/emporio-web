<template>
  <div class="fixed flex z-50 inset-0 pointer-events-none">
    <transition name="fade" mode="out-in">
      <div
        v-if="modelValue && overlay"
        @click="() => (!hideClose ? onClose() : null)"
        class="z-0 absolute bg-black bg-opacity-75 inset-0 w-full h-full pointer-events-auto"
      ></div>
    </transition>
    <transition :name="onTransition" mode="out-in">
      <div
        v-if="modelValue"
        class="relative z-10 flex flex-col pointer-events-none shadow"
        :class="[onAside]"
      >
        <VModalWindow
          :size="size"
          :aside="aside"
          :hideClose="hideClose"
          :footer="footer"
          :header="header"
          @mounted="onOpen"
          class="pointer-events-auto"
        >
          <template #header v-if="header">
            <div class="flex gap-3">
              <slot name="before-title"></slot>
              <h2 v-if="title" class="text-lg font-semibold leading-tight">
                {{ title }}
              </h2>
              <slot name="after-title"></slot>
            </div>
          </template>
          <template #top-tools>
            <slot name="top-tools"></slot>
          </template>
          <slot></slot>
          <template #footer v-if="footer">
            <slot name="footer"></slot>
          </template>
        </VModalWindow>
      </div>
    </transition>
  </div>
</template>
<script>
import VModalWindow from "./VModalWindow";
export default {
  name: "VModal",
  components: {
    VModalWindow,
  },
  provide() {
    return {
      onClose: this.onClose,
    };
  },
  props: {
    modelValue: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: "",
    },
    size: {
      type: String,
      default: "sm",
    },
    hideClose: {
      type: Boolean,
      default: false,
    },
    aside: {
      type: String,
      default: "",
    },
    overlay: {
      type: Boolean,
      default: true,
    },
    footer: {
      type: Boolean,
      default: true,
    },
    header: {
      type: Boolean,
      default: true,
    },
  },
  computed: {
    onAside() {
      switch (this.aside) {
        case "left":
          return "aside-left justify-start left-0 mr-auto";

        case "right":
          return "aside-right justify-end right-0 ml-auto";

        default:
          return "p-5 items-center w-full";
      }
    },
    onTransition() {
      switch (this.aside) {
        case "left":
          return "swipe-right";

        case "right":
          return "swipe-left";

        default:
          return "fade";
      }
    },
  },
  mounted() {
    document.body.insertBefore(this.$el, null);
  },
  unmounted() {
    this.$el.remove();
  },
  methods: {
    onClose() {
      this.$emit("update:modelValue", false);
    },
    onOpen() {
      this.$emit("open");
    },
  },
};
</script>
<style lang="css" scoped></style>
