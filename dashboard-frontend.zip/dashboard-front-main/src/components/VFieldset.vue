<template>
	<fieldset class="relative rounded p-2.5 md:p-4" :class="[bg, border || 'shadow']">
		<legend class="flex items-center">
			<slot name="legend"></slot>
			<div :class="fixedTools ? 'fixed flex gap-3 z-20 flex-col right-5 bottom-5 xl:flex-row xl:absolute xl:right-4 xl:bottom-[inherit]': 'absolute right-4 flex gap-3 z-20'">
				<slot name="tools"></slot>
			</div>
		</legend>
		<div ref="content" class="relative">
			<slot v-if="show"></slot>
		</div>
	</fieldset>
</template>
<script setup>
import { defineProps, onMounted, ref, watch } from "vue"
import { useIntersectionObserver } from '@vueuse/core'
const props = defineProps({
	fixedTools: {
		type: Boolean,
		default: false
	},
	border: {
		type: [Boolean, String],
		default: 'border border-gray-300'
	},
	lazy: {
		type: Boolean,
		default: false
	},
	bg: {
		type: String,
		default: 'bg-white'
	},
});

const content = ref(null);
const show = ref(!props.lazy);

onMounted(async () => {

	if(!show.value){
		const {stop} = useIntersectionObserver(content, ([{isIntersecting}]) => {
			show.value = isIntersecting;
		})

		watch(() => (show.value), (a) => {
			if(a)
				stop();
		})
	}
})

</script>