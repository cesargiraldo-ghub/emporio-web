<template>
	<div class="flex flex-wrap gap-2 md:gap-4 items-center leading-none" v-if="pages > 1">
		<button @click="onPrev" :disabled="current == 1" :class="{'opacity-40': current == 1}">
			<fa-icon class="py-1 px-2 rounded text-red-500" :icon="icons.faArrowLeftLong"/>
		</button>

		<template v-for="(i, index) in items" :key="`page_${$.uid}_${i}`">
			<VItem 
				:item="onPage(i, index)"
				:active="current"
				@click="(item) => onCurrent(item)"
			/>
		</template>

		<button @click="onNext" :disabled="current == pages" :class="{'opacity-40': current == pages}">
			<fa-icon class="py-1 px-2 rounded text-red-500" :icon="icons.faArrowRightLong"/>
		</button>
	</div>
</template>
<script>
import { faArrowRightLong, faArrowLeftLong } from '@fortawesome/free-solid-svg-icons'
import VItem from "./VItem"
export default {
	name: 'VPagination',
	props: {
		pages: {
			type: Number,
			default: 0
		},
		current: {
			type: Number,
			default: 0
		}
	},
	components: {
		VItem
	},
	watch: {
		current(a){
			this.page = a;
		}
	},
	data() {
		return {
			page: this.current,
			viewPage: 3,
			offPage: 2,
			icons: {
				faArrowLeftLong,
				faArrowRightLong
			}
		}
	},
	computed: {
		offSet(){
			return this.viewPage + this.offPage;
		},
		items(){
			let offSet = this.viewPage + (this.offPage * 2);
			return this.pages > offSet ? offSet : this.pages
		}
	},
	methods: {
		onPage(i, index){
			return this.pages <= this.offSet + 2 ?
				i :
			index == 0 ? 
				1 : 
			index == this.items - 1 ?
				this.pages :
			(this.page >= this.offSet && index == 1) || (this.page < this.pages - this.viewPage && index == this.offSet) ? 
				"..." :
			this.page > this.pages - this.viewPage && this.pages > this.offSet ? 
				this.pages - this.offSet + i - this.offPage :
			this.page >= this.offSet ? 
				this.page + i - this.viewPage - 1 :
				i
		},
		onPrev(){
			if(this.page > 1){
				this.page --;
				this.$emit("update:current", this.page);
			}
		},
		onCurrent(i){
			this.page = i;
			this.$emit("update:current", this.page);
		},
		onNext(){
			if(this.page < this.pages){
				this.page ++;
				this.$emit("update:current", this.page);
			}
		}
	}
}
</script>
<style lang="css" scoped>
</style>