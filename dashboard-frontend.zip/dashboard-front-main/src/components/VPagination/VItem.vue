<template>
	<component 
		:is="tag.is"
		v-on="tag.event"
		class="py-1 px-2 rounded"
		:class="{'bg-red-500 text-white': active == item}"
	>
		{{item}}
	</component>
</template>
<script>
export default {
	name: 'VItem',
	emits: ["click"],
	props: {
		item: {
			type: [String, Number],
			default: ''
		},
		active: {
			type:  [String, Number],
			default: ''
		}
	},
	computed: {
		tag(){
			return {
				is: typeof this.item === 'number' ? 'button' : 'span',
				event: typeof this.item === 'number' ? {click: this.onClick} : {}
			};
		}
	},
	methods: {
		onClick(){
			this.$emit("click", this.item);
		}
	}
}
</script>
<style lang="css" scoped>
</style>