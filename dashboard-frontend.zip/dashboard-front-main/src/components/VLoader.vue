<template>
  <div class="-m-2 p-2" :class="[pos, {'pointer-events-none': pointerEventsNone}]">
    <div :class="$attrs.class">
      <slot></slot>
    </div>
    <transition name="fade" mode="out-in">
      <div v-if="show" class="bg-white/[.4] backdrop-blur-sm backdrop-grayscale absolute inset-0 flex z-50 pointer-events-auto">
        <fa-icon class="text-2xl text-gray-600 m-auto animate-spin" :icon="faCircleNotch"></fa-icon>
      </div>
    </transition>
  </div>
</template>
<script>
import { faCircleNotch } from '@fortawesome/free-solid-svg-icons'
export default {
  name: 'VLoader',
  inheritAttrs: false,
  props: {
    show: {
      type: Boolean,
      default: false
    },
    position: {
      type: String,
      default: "relative"
    }
  },
  data() {
    return {
      faCircleNotch
    }
  },
  computed: {
    pointerEventsNone(){
      let state = false;
      switch(this.position){
        case "fixed":
        case "absolute":
          state = !this.show
          break;
        case "relative":
          state = this.show
          break;
      }
      return state; 
    },
    pos(){
      let pos = "relative";

      switch(this.position){
        case "fixed":
          pos = "fixed inset-0 z-50"
          break;
        case "absolute":
          pos = "absolute inset-0"
          break;
      }

      return pos;
    },

  }
}
</script>
<style lang="css" scoped>
</style>