<template>
  <div
    class="sticky xl:fixed bottom-0 md:bottom-4 right-4 z-50 flex"
  >
    <div
      class="[&>*]:flex-grow [&>*]:justify-center flex flex-grow gap-2 py-2 px-3 shadow -mx-3 bg-white md:mr-0 md:flex-grow-0 md:rounded md:shadow-md md:border md:border-gray-200 md:p-4 md:gap-5 md:ml-auto"
    >
      <slot></slot>
    </div>
  </div>
</template>