<template>
	<div class="flex flex-col gap-3 mb-4" :class="alignItems">
		<template v-if="importFile">
			<label :for="$.uid" class="cursor-pointer" :class="{'pointer-events-none': !(!signature)}">
				<VButton class="pointer-events-none" :disabled="!(!signature)" size="sm" text="Subir firma" bgColor="bg-blue-200" textColor="text-blue-500"/>
			</label>
			<input class="hidden" ref="fileInput" type="file" :id="$.uid" @change="onUploadFile">
		</template>
		<div class="relative bg-white border-2 border-dashed border-gray-200 rounded">
			<canvas v-show="!modelValue" ref="canvas" width="250" height="150"></canvas>
			<img v-show="modelValue" :src="modelValue" class="object-contain w-[250px] h-[150px]" alt="">
		</div>
		<p>
			Ingresa tu firma en la zona punteada <br>
			y da clic en <b class="font-medium text-emerald-500">Confirmar firma</b>
		</p>
		<div class="flex gap-3">
			<VButton size="sm" @click="onConfirmation" :disabled="!(!signature)" text="Confirmar firma" bgColor="bg-emerald-200" textColor="text-emerald-500"/>
			<VButton size="sm" @click="onClear" text="Borrar" bgColor="bg-orange-200" textColor="text-orange-500"/>
		</div>
	</div>
</template>
<script setup>
	import {ref, onMounted, defineEmits, defineProps, watch, computed} from "vue"
	import SignaturePad from "signature_pad"
	import VButton from "@/components/VButton"

	import { useToast } from 'vue-toastification'
	const toast = useToast();

	const emits = defineEmits(["change", "update:modelValue"])
	const props = defineProps({
		align: {
			type: String,
			default: "left"
		},
		importFile: {
			type: Boolean,
			default: false
		},
		modelValue: {
			default: null
		}
	});

	const alignItems = computed(() => {
		let value = null;
		switch(props.align){
			case 'left':
				value = 'items-start text-left';
				break;
			case 'center':
				value = 'items-center text-center';
				break;
			case 'right':
				value = 'items-end text-right';
				break;
		}
		return value;
	});

	const canvas = ref(null);
	const signature = ref(props.modelValue || null);
	const signaturePad = ref(null);
	const fileInput = ref(null);

	const initSignaturePad = () => {
		signaturePad.value = new SignaturePad(canvas.value);

		if(props.modelValue){
			signaturePad.value.fromDataURL(props.modelValue);
			signaturePad.value.off();
		}
	}

	const onConfirmation = () => {	
		if(!signaturePad.value.isEmpty()){
			const data = signaturePad.value.toDataURL();
			signature.value = data;
			signaturePad.value.off();
		}else{
			toast.error("Debes registrar una firma")
		}
	}

	const onClear = () => {
		signaturePad.value.clear();
		signaturePad.value.on();
		signature.value = null;
		fileInput.value = null;
	}

	watch(() => signature.value, (a) => {
		emits("change", a);
		emits("update:modelValue", a);
	});

	const onUploadFile = ({target: {files: [file]}}) => {
		const reader = new FileReader();
		reader.addEventListener("load", ({target: {result}}) => {
			signature.value = result;
			fileInput.value = null;
		}, false);

		if(file)
			reader.readAsDataURL(file);
	}

	onMounted(() => {
		initSignaturePad();
	});
</script>