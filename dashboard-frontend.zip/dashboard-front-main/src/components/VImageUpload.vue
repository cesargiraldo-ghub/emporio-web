<template>
	<div class="relative overflow-hidden rounded shadow" :class="image ? 'bg-white' : 'bg-gray-50'">
		<input ref="input" type="file" :id="`input_file_${$.uid}`" @change="onChange" class="hidden">
		<label :for="`input_file_${$.uid}`" class="block cursor-pointer aspect-square" :class="widthFull ? 'w-full' : 'w-24 md:w-28 lg:w-32'">
			<div v-if="!image" class="inline-flex flex-col items-center justify-center border border-dashed border-gray-400 rounded text-gray-500 absolute inset-0">
				<fa-icon :icon="faImage" class="block w-1/4 h-auto mb-2 opacity-60"></fa-icon>
				<span class="text-center font-medium">{{label}}</span>
			</div>
			<transition name="fade" mode="out-in">
				<img v-if="image" @load="onLoad" :src="image" class="absolute inset-0 z-10 w-full h-full block object-center object-cover">
			</transition>
		</label>
		<span v-if="image && modelValue" @click="onDelete" class="absolute z-10 bottom-0 right-0 m-1 w-4 aspect-square bg-red-500 rounded-full cursor-pointer">
			<fa-icon class="absolute inset-0 w-90 h-90 m-auto text-white" :icon="faClose"></fa-icon>
		</span>
	</div>
</template>
<script>
export default {
	name: 'VImagesUpload',
}
</script>
<script setup>
import {faImage, faClose} from '@fortawesome/free-solid-svg-icons';
import {defineProps, defineEmits, watch, ref} from "vue";

const emit = defineEmits(['update:modelValue', 'onDelete', 'onLoad']);
const props = defineProps({
	label: {
		type: String,
		default: "Picture"
	},
	image: {
		type: String,
		default: ""
	},
	widthFull: {
		type: Boolean,
		default: false
	},
	modelValue: {
		default: null
	}
});

const input = ref(null);

watch(() => props.image, () => {
	onLoad();
})

const onChange = ({ target }) => {
	const value = target.files[0];
	emit("update:modelValue", value);
	input.value.value = null;
}

const onLoad = () => {
	emit("onLoad");
}

const onDelete = () => {
	emit("onDelete", props.modelValue);
	input.value.value = null;
}
</script>
