<template>
  <div class="flex flex-wrap">
    <Flicking :options="{ bound: true, align: 'prev', inputType: ['pointer'] }" class="!w-[1px] flex-grow">
      {{ current }}
      <label
        v-for="(item, index) in items"
        :key="`tab-item-${index}-${item.id}-${$.uid}`"
        :for="`tab-${index}-${item.id}-${$.uid}`"
        class="rounded-t border border-gray-300 border-b-transparent px-4 py-2 leading-tight font-semibold relative transition-all cursor-pointer"
        :class="[
          { 'ml-2': index, 'text-red-500': current == index }
        ]"
      >
        {{ item[title] }}
        <span
          v-if="current == index"
          class="absolute inset-x-0 border-b border-white top-full z-30"
        ></span>
      </label>
    </Flicking>
    <div
      class="p-5 border border-gray-300 rounded-b relative mt-[-1px] bg-white w-full"
    >
      <template
        v-for="(item, index) in items"
        :key="`tab-content-${index}-${item.id}-${$.uid}`"
      >
        <input
          type="radio"
          class="hidden"
          :name="`tab-${$.uid}`"
          :id="`tab-${index}-${item.id}-${$.uid}`"
          :value="index"
          v-model="current"
        />
      </template>
      <slot :item="items[current]" :index="current"></slot>
    </div>
  </div>
</template>

<script setup>
import { defineProps, ref } from "vue";
import Flicking from "@egjs/vue3-flicking";
import "@egjs/vue3-flicking/dist/flicking-inline.css";
defineProps({
  items: {
    type: Array,
    default: () => [],
  },
  title: {
    type: String,
    required: true,
  },
});

const current = ref(0);
</script>
