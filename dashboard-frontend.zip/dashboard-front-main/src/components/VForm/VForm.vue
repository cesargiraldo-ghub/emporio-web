<template>
  <form @submit="onSubmit" :class="{ 'text-center': center }">
    <div
      class="grid gap-6"
      :class="{ 'grid-cols-2 md:grid-cols-10': !disabledCols }"
    >
      
      <template v-if="keysFields.length">
        <template
          v-for="(key, index) in keysFields.filter(
            (item) => !fields[item].notInherit
          )"
          :key="`field_${index}_${$.uid}`"
        >
          <slot :name="key" :field="fields[key]">
            <VInput
              :modelValue="fields[key].value"
              :name="key"
              v-bind="fields[key]"
              :modelModifiers="fields[key].modifires || {}"
            />
          </slot>
        </template>
      </template>
      <slot
        :onSubmit="onSubmit"
        :resetForm="resetForm"
        :fields="fields"
        :errors="errors"
      ></slot>
      <template v-if="showSubmit">
        <div class="col-span-10">
          <slot name="submit" :onSubmit="onSubmit" :resetForm="resetForm">
            <VButton type="submit" :text="textSubmit"></VButton>
          </slot>
        </div>
      </template>
    </div>
  </form>
</template>
<script setup>
import { useForm } from "vee-validate";
import VInput from "@/components/VForm/VInput";
import VButton from "@/components/VButton";
import { defineProps, defineEmits, defineExpose, computed } from "vue";

/* Start Props */
const props = defineProps({
  fields: {
    type: Object,
    default: () => ({}),
  },
  disabledCols: {
    type: Boolean,
    default: false,
  },
  showSubmit: {
    type: Boolean,
    default: true,
  },
  reset: {
    type: Boolean,
    default: false,
  },
  textSubmit: {
    type: String,
    default: "Send",
  },
  center: {
    type: Boolean,
    default: false,
  },
});
/* End Props */

const keysFields = computed(() => Object.keys(props.fields));

/* Start Methods */
const emits = defineEmits(["submit", "errors"]);
const { handleSubmit, resetForm, errors, validate, values } = useForm();

const onSubmit = handleSubmit((values) => {
  const fields = {};
  for (let prop in props.fields) {
    if (props.fields[prop].value) fields[prop] = props.fields[prop].value;
  }
  
  emits("submit", { values, fields });

  if(props.reset)
    resetForm();
});

const onResetForm = () => {
  resetForm();
};

defineExpose({ onSubmit, onResetForm, errors, validate, values });
/* End Methods */
</script>
<style lang="css" scoped></style>
