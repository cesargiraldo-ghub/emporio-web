<template>
	<span class="block leading-tight relative overflow-hidden" :class="{'m-[-1px] rounded': outline}">
		<template v-if="attrs?.type == 'textarea'">
			<textarea :class="{'!bg-[#f8f8f8]':attrs.disabled }" class="input-form flex w-full bg-transparent outline-none py-2.5 px-3 leading-normal" v-on="events" v-bind="attrs" @input="onInput" :value="modelValue"></textarea>
		</template>
		<template v-else>
			<input :class="{'!bg-[#f8f8f8]':attrs.disabled }" class="input-form flex w-full bg-transparent outline-none py-2.5 px-3" v-on="events" v-bind="attrs" @input="onInput" :value="modelValue || value"/>
		</template>
		<div class="line-wrappers">
			<span v-if="!outline" class="line-base"></span>
			<span class="line-focus"></span>
		</div>
	</span>
</template>
<script setup>
import { defineProps, defineEmits, toRef } from "vue"

const props = defineProps({
	modelValue: {
		default: null
	},
	value: {
		default: null
	},
	outline: {
		type: Boolean,
		default: false 
	},
	attrs: {
		type: Object,
		default: () => ({})
	},
	events: {
		type: Object,
		default: () => ({})
	}
});
const attrs = toRef(props, 'attrs');
const events = toRef(props, 'events');

const emit = defineEmits(["update:modelValue"]);
const onInput = ({target}) => {
	emit("update:modelValue", target.value);
}
</script>
<style lang="scss">
	.input-form {
		&:focus+.line-wrappers{
			.line-focus{
				&::before, &::after{
					@apply translate-x-0;
				}
			}
		}
	}
	.line-base, .line-focus{
		&::before{
			@apply content-[''] block border absolute bottom-0 left-0 w-full  border-b-stone-400;
		}
		&::after{
			@apply content-[''] block border-2 border-transparent absolute bottom-0 left-0 border-l-stone-400 border-b-stone-400;
		}
	}
	.line-focus{
		&::before{
			@apply transition -translate-x-full duration-500 border-b-red-400;
		}
		&::after{
			@apply transition -translate-x-full duration-500 border-l-red-400 border-b-red-400;
		}
	}

</style>