<template>
  <div
    v-show="attr?.type != 'hidden'"
    :class="[
      width || 'col-span-10',
      { 'pointer-events-none opacity-50': disabled },
    ]"
  >
    <component
      :is="outline ? 'fieldset' : 'div'"
      class="flex flex-col"
      :class="[
        extrasClass,
        { 'border border-gray-300 rounded onOutline': outline },
      ]"
    >
      <component
        :is="outline ? 'legend' : 'label'"
        v-if="label"
        class="text-left z-10 relative"
        :class="[
          outline ? 'px-3 ml-2 leading-[0] text-xs' : 'mb-1 text-sm',
          classLabel,
        ]"
      >
        {{ label }} <span v-if="attr?.rules" class="text-red-500">*</span>
      </component>

      <div class="relative" :class="{ 'bg-red-100': errorMessage }">
        <span
          v-if="icon"
          class="absolute w-4 aspect-square opacity-50 top-1/2 left-2 -translate-y-1/2"
        >
          <fa-icon class="w-ful h-full block" :icon="icon"></fa-icon>
        </span>

        <transition name="slide-right" mode="out-in">
          <fa-icon
            v-if="!hiddeValidate"
            v-show="!errorMessage && (value?.length ?? value)"
            class="text-green-500 text-sm absolute right-1.5 -translate-y-1/2"
            :class="!outline ? 'top-0' : 'top-1/2'"
            :icon="faCheck"
          ></fa-icon>
        </transition>

        <template v-if="attr?.type == 'date'">
          <VInputBase
            v-bind="{
              outline,
              attrs: { ...attr, type: 'date', name },
            }"
            @update:modelValue="onInput"
            :modelValue="value"
          />
          <!-- <VueDatePicker v-bind="attr"
						:class="{'pr-4': outline}"
						select-text="Seleccionar"
						cancel-text="Cancelar"
						@closed="() => {
							validate();
						}"
						@update:modelValue="onInput" :modelValue="value"
					>
						<template #input-icon></template>
						<template #dp-input>
						</template>
					</VueDatePicker> -->
        </template>

        <template v-else-if="attr?.type == 'check'">
          <div class="py-2.5 px-3">
            <VCheck
              v-bind="{ ...attr, name }"
              @update:modelValue="onInput"
              :modelValue="value"
              :class="{ 'py-2.5 px-3': outline }"
            >
              <template #default="{ option }">
                <slot :option="option"></slot>
              </template>
            </VCheck>
          </div>
        </template>

        <template v-else-if="attr?.type == 'select'">
          <VSelect
            :class="{
              'pr-4':
                !hiddeValidate &&
                outline &&
                !errorMessage &&
                (value?.length ?? value),
            }"
            v-bind="attr"
            @search:blur="validate"
            @update:modelValue="onInput"
            :modelValue="value"
          >
            <template #no-options> No hay opciones disponibles </template>
            <template #open-indicator="{ attributes }">
              <span
                v-bind="attributes"
                class="block w-3.5 aspect-square relative"
              >
                <fa-icon
                  class="absolute inset-0 w-full h-full text-stone-500"
                  :icon="faChevronDown"
                ></fa-icon>
              </span>
            </template>
          </VSelect>
        </template>

        <template v-else-if="attr?.type == 'tag'">
          <VTag
            :hideTags="true"
            :attrs="attr"
            @update:modelValue="onInput"
            :modelValue="value"
            :modelModifiers="{ capitalize: true }"
          >
            <template #input="{ addValue }">
              <VInputBase
                v-bind="{
                  outline,
                  events: {
                    keypress: addValue,
                  },
                  attrs: { type: 'text', name },
                }"
              />
            </template>
          </VTag>
        </template>

        <template v-else-if="attr?.type == 'table'">
          <VInputTable
            ref="inputTable"
            @update:modelValue="onInput"
            :modelValue="value"
            v-bind="attr"
          >
            <template #input="{ value, row, open, clear }">
              <div v-if="!row" class="flex items-center">
                <VInputBase
                  :disabled="attr.disabled"
                  :events="{ focus: open }"
                  class="flex-grow"
                  :modelValue="value"
                ></VInputBase>
                <VButton
                  :icon="faSearch"
                  bgColor="bg-transparent"
                  textColor="text-emerald-500"
                  @click="open"
                ></VButton>
              </div>
              <slot v-else name="row" :value="row">
                <div
                  class="flex border border-stone-200 rounded bg-stone-50 items-center"
                >
                  <span
                    @click="!attr.disabled ? open() : null"
                    class="flex flex-grow cursor-pointer"
                  >
                    <span class="flex-grow px-3 py-2">{{
                      attr?.result(row)
                    }}</span>
                    <VButton
                      v-if="!attr.disabled"
                      :icon="faArrowRightArrowLeft"
                      bgColor="bg-transparent"
                      textColor="text-emerald-500"
                    ></VButton>
                  </span>
                  <VButton
                    v-if="!attr.disabled"
                    :icon="faClose"
                    bgColor="bg-transparent"
                    textColor="text-red-500"
                    @click="clear"
                  ></VButton>
                </div>
              </slot>
            </template>
          </VInputTable>
        </template>

        <template v-else-if="attr?.type == 'file'">
          <VInputFile
            v-bind="{
              attrs: { ...attr, name },
              events: {
                blur: () => {
                  validate();
                },
              },
            }"
            @update:modelValue="onInput"
            :modelValue="value"
          />
        </template>

        <template v-else>
          <VInputBase
            v-if="modelModifiers.price"
            v-bind="{
              outline,
              attrs: { ...attr, name },
              events: {
                blur: () => {
                  validate();
                },
              },
            }"
            @update:modelValue="onInput"
            :value="currency(value)"
          />
          <VInputBase
            v-else
            v-bind="{
              outline,
              attrs: { ...attr, name },
              events: {
                blur: () => {
                  validate();
                },
              },
            }"
            @update:modelValue="onInput"
            :modelValue="value"
          />
        </template>
        <slot name="after"></slot>
        <transition name="slide-right" mode="out-in">
          <ErrorMessage
            :name="name"
            as="span"
            class="absolute right-1.5 text-red-500 text-xs pointer-events-none"
            :class="
              outline
                ? 'top-1'
                : attr?.type == 'check'
                ? 'bottom-full mb-1'
                : label
                ? 'top-0 -translate-y-1/2'
                : 'top-1'
            "
          >
            {{ errorMessage }}
          </ErrorMessage>
        </transition>
      </div>
    </component>
    <template v-if="attr?.type == 'tag'">
      <VTag class="mt-2" :hideInput="true" v-model="value" />
    </template>
  </div>
</template>
<script setup>
import {
  faCheck,
  faChevronDown,
  faSearch,
  faClose,
  faArrowRightArrowLeft,
} from "@fortawesome/free-solid-svg-icons";
import { defineProps, defineEmits, ref, watch } from "vue";
import { ErrorMessage, useField } from "vee-validate";
import { currency } from "@/assets/js/filters";

import VSelect from "vue-select";
import "vue-select/dist/vue-select.css";

import VInputBase from "./VInputBase";
import VInputFile from "./VInputFile";
import VInputTable from "./VInputTable";
import VTag from "./VTags";

// import VueDatePicker from '@vuepic/vue-datepicker';
// import '@vuepic/vue-datepicker/dist/main.css'

import VCheck from "@/components/VForm/VCheck";
import VButton from "@/components/VButton";

/*Start Props*/
const props = defineProps({
  modelValue: {
    default: null,
  },
  disabledCols: {
    type: Boolean,
    default: false,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  attr: {
    type: Object,
    required: true,
  },
  label: {
    type: String,
  },
  width: {
    type: String,
    default: "",
  },
  extrasClass: {
    type: String,
    default: "",
  },
  classLabel: {
    type: String,
    default: "",
  },
  icon: {
    type: Object,
    default: () => null,
  },
  name: {
    type: String,
    required: true,
  },
  outline: {
    type: Boolean,
    default: false,
  },
  hiddeValidate: {
    type: Boolean,
    default: false,
  },
  modelModifiers: {
    default: () => ({}),
  },
});
/*End Props*/

const purifyValue = (value) => {
  const { numeric, price } = props.modelModifiers;

  let result = value.replace(/^\s/gm, "");
  result = result.replace(/\s\s+/g, " ");

  if (numeric || price) result = Number(result.replace(/[^0-9]/g, ""));

  return result;
};

/*Start State*/
const { value, handleChange, validate, errorMessage } = useField(
  props.name,
  props?.attr?.rules,
  {
    initialValue: props.modelValue,
  }
);
/*End State*/

const inputTable = ref(null);

watch(
  () => value.value,
  (a) => {
    if (inputTable.value && !a) {
      inputTable.value.clear();
    }
  }
);

/* Start Methods */
const emits = defineEmits(["update:modelValue", "onChange"]);
const onInput = async (e) => {
  const v =
    typeof e == "string"
      ? purifyValue(e)
      : Array.isArray(e) && !e.length
      ? []
      : e;
  await handleChange(v);
  emits("update:modelValue", value.value);
  emits("onChange", value.value);
};
/* End Methods */
</script>
<style lang="scss">
.v-select .vs__selected {
  @apply block overflow-hidden whitespace-nowrap overflow-ellipsis;
  max-width: calc(100% - 35px);
}
.onOutline .v-select {
  @apply m-[-1px];
  &::before,
  &::after {
    @apply hidden;
  }
}
.v-select,
.vs__dropdown-toggle {
  &::before {
    @apply content-[''] block border absolute bottom-0 left-0 w-full  border-b-stone-400;
  }
  &::after {
    @apply content-[''] block border-2 border-transparent absolute bottom-0 left-0 border-l-stone-400 border-b-stone-400;
  }
}
.v-select {
  @apply relative;
  &.vs--disabled {
    @apply bg-[#f8f8f8];
  }
  .vs__dropdown-toggle {
    @apply overflow-hidden relative bg-transparent outline-none py-2 md:py-2.5 px-3 border-0 flex w-full leading-tight;
    &::before {
      @apply transition -translate-x-full duration-500 border-b-red-400;
    }
    &::after {
      @apply transition -translate-x-full duration-500 border-l-red-400 border-b-red-400;
    }
  }
  &.vs--open {
    .vs__dropdown-toggle {
      &::before,
      &::after {
        @apply translate-x-0;
      }
    }
  }

  .vs__selected-options {
    @apply -m-1 p-0 w-1;
  }
  .vs__dropdown-menu {
    @apply rounded mt-1;
  }
  .vs__selected,
  .vs__search,
  .vs__search:focus {
    @apply text-sm m-1 border-0 leading-tight placeholder:text-gray-400;
  }

  .vs__actions {
    @apply p-0 scale-90;

    & > * {
      @apply cursor-pointer;
    }
  }
}
</style>
