<template>
	<div class="flex flex-col gap-2">
		<slot name="input" :value="reduce(modelValue)" :row="row" :open="open" :clear="clear">
			<input class="input-form-control" v-bind="attrs" type="text" :value="reduce(row)">
		</slot>
		<VModal v-model="modal.show" v-bind="{title, ...modal}">
			<component ref="table" :is="component" @rowSelected="(res) => {rowSelected = res}" v-bind="{title: titleTable, selected: true, filter}"></component>
			<template #footer>
				<div class="flex gap-3">
					<VButton :disabled="overlay || !rowSelected" text="Guardar" bgColor="bg-green-500" @click="selectRow" />
					<VButton :disabled="overlay" text="Cerrar" bgColor="bg-blue-500" @click="close" />
				</div>
			</template>
		</VModal>
	</div>
</template>
<script setup>
import VModal from "@/components/VModal"
import VButton from "@/components/VButton"
import { defineProps, defineEmits, defineExpose, ref, reactive, onMounted, watch } from "vue"

const emits = defineEmits(["update:modelValue"]);
const props = defineProps({
	attrs: {
		type: Object
	},
	reduce: {
		type: Function,
		defautl: (i) => (i)
	},
	component: {
		type: Object,
		required: true
	},
	filter: {
		type: [String, Number],
		default: ""
	},
	title: {
		type: String,
		defautl: "Seleccionar registro"
	},
	titleTable: {
		type: String,
		defautl: ""
	},
	modelValue: {
		required: true
	},
});

const overlay = ref(false);
const modal = reactive({
	show: false,
	size: 'lg'
});

const table = ref(null);
const rowSelected = ref(false);
const row = ref(null);
const selectRow = () => {
	row.value = table.value.getRow();
	emits('update:modelValue', props.reduce(row.value));
	close();
}

onMounted(() => {
	setValue();
});

watch(() => (props.modelValue), () => {
	setValue();
});

const setValue = () => {
	if(props.modelValue != null && typeof props.modelValue == 'object'){
		row.value = props.modelValue;
		emits('update:modelValue', props.reduce(row.value));
	}
}

const open = () =>{
	modal.show = true;
}

const clear = () =>{
	emits('update:modelValue', null);
	row.value = null;
}

const close = () =>{
	modal.show = false;
	rowSelected.value = false;
}

defineExpose({clear})

</script>