<template>
	<div class="flex flex-col gap-2">
		<slot name="input" :value="modelValue" :addValue="addValue">
			<input v-if="!hideInput" class="input-form-control" v-bind="attrs" type="text" @keypress="addValue">		
		</slot>
		<VueDraggable v-show="!hideTags" v-model="options" item-key="id" class="flex flex-wrap gap-2">
			<template #item="{element: value, index: i}">
				<span class="bg-gray-300 leading-none py-1 px-2 rounded cursor-pointer text-sm" @click="removeValue(i)">
					{{value}} <span class="font-bold opacity-50">x</span>
				</span>
			</template>
		</VueDraggable>
	</div>
</template>
<script setup>
	import {defineAsyncComponent, defineProps, defineEmits, ref, watch} from "vue"
	const VueDraggable = defineAsyncComponent(() => import("vuedraggable"));

	const emits = defineEmits(["update:modelValue"]);
	const props = defineProps({
		attrs: {
			type: Object,
		},
		hideInput: {
			type: Boolean,
			default: false
		},
		hideTags: {
			type: Boolean,
			default: false
		},
		modelValue: {
			required: true,
			default: () => ([])
		},
		modelModifiers: {
			default: () => ({})
		}
	});

	const options = ref(props.modelValue ?? []);

	watch(() => options.value, (a) => {
		emits("update:modelValue", a);
	}, { deep: true });

	const removeValue = (i) => {
		options.value.splice(i, 1);
	}

	const purifyValue = (value) => {
		const {capitalize} = props.modelModifiers;

		let result = value.replace(/^\s+|\s+$/gm,'');
		result = result.replace(/\s\s+/g, " ");

		if(capitalize)
			result = result.toLowerCase().split(" ").map(
				(word, index) => 
					(word.length > 3 || index == 0) ?
					word.replace(/\w/, letter => letter.toUpperCase()) :
					word
			).join(" ");
		
		return result;  
	}

	const addValue = ({keyCode, target}) => {
		if(keyCode == 13){
			let value = target.value.replace(/\t/g, ",").split(",");

			value.forEach(item => {
				let v = purifyValue(item);

				if(!options.value.includes(v))
					options.value.push(v);
			});

			target.value = null;
		}
	}

</script>