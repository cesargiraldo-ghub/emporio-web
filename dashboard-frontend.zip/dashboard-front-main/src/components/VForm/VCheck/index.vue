<template>
  <div
    class="gap-4"
    :class="[!!cols ? 'grid' : 'flex flex-wrap', {'bg-[#f8f8f8] pointer-events-none': Boolean(disabled)}]"
    :style="styles"
  >
    <template v-if="options.length">
      <template
        v-for="(option, index) in options"
        :key="`checkbox_${$.uid}_${index}`"
      >
        <VCheckItem
          :name="option[label]"
          :value="reduce(option)"
          :radio="!multiple"
          :radio-name="name ?? `radio_${$.uid}`"
          @click="onClick($event, index)"
          @change="onChange(reduce(option))"
          :checked="onChecked(reduce(option))"
        >
          <slot :option="option"></slot>
        </VCheckItem>
      </template>
    </template>
    <template v-else>
      {{ message }}
    </template>
  </div>
</template>
<script>
import VCheckItem from "./VCheckItem";
export default {
  name: "VCheckbox",
  props: {
    label: {
      type: String,
      default: "name",
    },
    message: {
      type: String,
      default: "No hay opciones registradas",
    },
    name: {
      type: String,
    },
    cols: {
      type: [Number, String],
      default: 0,
    },
    reduce: {
      type: Function,
      default: (e) => e,
    },
    options: {
      type: Array,
      default: () => [],
    },
    multiple: {
      type: Boolean,
      default: true,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    modelValue: {
      required: true,
      default: () => [],
    },
  },
  components: {
    VCheckItem,
  },
  data() {
    return {
      value: this.multiple && !this.modelValue ? [] : this.modelValue,
      currentCheck: null,
    };
  },
  computed: {
    styles() {
      let rows = Math.ceil(this.options.length / this.cols);
      return {
        gridTemplateColumns: `repeat(${this.cols}, 1fr)`,
        gridTemplateRows: `repeat(${rows}, 1fr)`,
      };
    },
    isArray() {
      return Array.isArray(this.modelValue) && this.multiple;
    },
  },
  watch: {
    modelValue(a) {
      this.value = this.multiple && !this.modelValue ? [] : a;
    },
  },
  methods: {
    values(v) {
      return {
        modelValue: this.isArray
          ? this.modelValue.map((item) => JSON.stringify(item))
          : JSON.stringify(this.modelValue),
        value: JSON.stringify(v),
      };
    },
    onChecked(v) {
      const { modelValue, value } = this.values(v);
      return this.isArray ? modelValue.includes(value) : modelValue == value;
    },
    onClick({ event }, index) {
      if (this.multiple) {
        if (event.shiftKey) {
          this.options.forEach((_, i) => {
            if (
              (i > this.currentCheck && i < index) ||
              (i < this.currentCheck && i > index)
            ) {
              this.onChangeMultiple(this.reduce(_));
            }
          });
        }
      }
      this.currentCheck = index;
    },
    onChangeMultiple(v) {
      const { modelValue, value } = this.values(v);
      if (modelValue.includes(value)) {
        let index = modelValue.indexOf(value);
        if (index > -1) {
          this.value.splice(index, 1);
        }
      } else {
        this.value.push(v);
      }
      this.value.sort();
    },
    onChange(v) {
      if (this.multiple) {
        this.onChangeMultiple(v);
      } else {
        this.value = v;
      }
      this.$emit("update:modelValue", this.value);
    },
  },
};
</script>
<!--  -->
