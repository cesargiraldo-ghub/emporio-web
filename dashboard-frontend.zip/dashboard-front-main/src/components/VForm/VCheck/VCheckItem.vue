<template>
  <label  :for="$.uid" class="flex gap-2 cursor-pointer select-none">
    <input
		@click="onClick"
      class="cursor-pointer hidden"
      :type="radio ? 'radio' : 'checkbox'"
      :name="radio ? radioName : null"
      :id="$.uid"
      :value="value"
      :checked="checked"
    />
    <span class="check-input">
      <span
        :class="radio ? 'rounded-full' : 'rounded'"
        class="align-middle inline-flex border border-stone-400 bg-white rounded w-4 aspect-square relative self-start"
      >
        <span
          v-if="radio"
          class="w-2 h-2 m-auto text-white rounded-full bg-white"
        ></span>
        <fa-icon
          v-else
          class="w-4/5 h-4/5 m-auto text-white"
          :icon="faCheck"
        ></fa-icon>
      </span>
    </span>
    <slot>
      <span v-if="showLabel" class="order-1">{{ name || value }}</span>
    </slot>
  </label>
</template>
<script setup>
import { faCheck } from "@fortawesome/free-solid-svg-icons";
import { defineProps, defineEmits } from "vue";
const emits = defineEmits(["click"]);
const props = defineProps({
  radio: {
    type: Boolean,
    default: () => false,
  },
  showLabel: {
    type: Boolean,
    default: true,
  },
  name: {
    default: null,
  },
  radioName: {
    type: String,
    default: "",
  },
  checked: {
    type: Boolean,
    default: () => false,
  },
  value: {
    default: null,
  },
});

const onClick = (event) => {
  emits("click", { event, value: props.value });
};
</script>
<style lang="scss">
.cursor-pointer {
  &:checked + span > span {
    @apply bg-red-500 border-red-500 transition-all;
  }
}
</style>
