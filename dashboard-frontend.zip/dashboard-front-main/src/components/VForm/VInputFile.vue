<template>
	<input class="hidden" type="file" v-on="events" v-bind="attrs" @change="onChange" :id="`${attrs.name}-${$.uid}`">
	<label
		:for="`${attrs.name}-${$.uid}`"
		:class="{'bg-green-100': modelValue}"
		class="py-2.5 px-3 flex rounded border border-dashed border-stone-400 items-center cursor-pointer"
	>
		<span class="font-medium">
			{{modelValue?.name || "Buscar archivo"}}
		</span>
	</label>
</template>
<script setup>
	import { defineProps, defineEmits } from "vue";

	const emits = defineEmits(['update:modelValue']);

	defineProps({
		modelValue: {
			required: true
		},
		attrs: {
			type: Object,
			default: () => ({})
		},
		events: {
			type: Object,
			default: () => ({})
		}
	});

	const onChange = ({target}) => {
		const value = target.files[0];
		emits('update:modelValue', value);
	}
</script>
