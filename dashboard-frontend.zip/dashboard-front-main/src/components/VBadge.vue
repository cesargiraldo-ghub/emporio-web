<template>
	<div class="inline-block relative">
		<button type="button" ref="badge" @click="show = !show" @blur="show = false" :class="[color || 'text-gray-600']" class="block bg-white overflow-hidden rounded py-0.5 px-2 relative leading-none font-medium !w-auto !h-auto">
			<span class="opacity-20 absolute inset-0" :class="outline ? 'border-2 border-current' : 'bg-current'"></span>
			<slot>{{label}}</slot>
		</button>
		<transition name="slide-down" mode="out-in" :duration="300">
			<div v-if="show && options.length" class="absolute top-full mt-1 z-10 flex flex-col rounded overflow-hidden whitespace-nowrap shadow" :class="[position == 'right' ? 'right-0' : 'left-0']">
				<template v-for="(option, index) in options" :key="`option-${index}-${$.uid}`">
					<span @click="onChange(option)" :class="option.color || color || 'text-gray-600'" class="block bg-white overflow-hidden py-0.5 px-2 relative leading-tight font-medium cursor-pointer">
						<span class="opacity-20 absolute inset-0" :class="outline ? 'border-2 border-current' : 'bg-current'"></span>
						{{option.label}}
					</span>
				</template>
			</div>
		</transition>
	</div>
</template>
<script setup>
	import {defineProps, defineEmits, ref} from "vue"

	const emits = defineEmits(["change"]);
	const props = defineProps({
		options: {
			type: Array,
			default: () => ([])
		},
		color: {
			type: String,
			default: ""
		},
		name: {
			type: String,
			default: ""
		},
		label: {
			type: String,
			default: ""
		},
		outline: {
			type: Boolean,
			default: false
		},
		position: {
			type: String,
			default: "left"
		}
	})
	
	const onChange = (result) => {
		let value = JSON.stringify(result);
		value = JSON.parse(value);
		
		if(props.name)
			value.key = `${props.name}.${result.key}`;

		emits('change', value);
	}
	const badge = ref(null);
	const show = ref(false);
</script>