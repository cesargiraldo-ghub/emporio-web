<template>
	<component :is="tags" :to="$attrs.to" :type="$attrs.type || 'button'" class="v-button"
		:class="[
			{hasIcon: !!icon, hasText: !!text, 'pointer-events-none grayscale': disabled},
			sizes,
			bgColor,
			textColor
		]"
	>
		<i class="block w-[0.9em] aspect-square relative" v-if="!!icon">
			<fa-icon class="absolute inset-0 w-full h-full" :icon="icon"/>
		</i>
		<span v-if="text">
			{{text}}
		</span>
	</component>
</template>
<script>
export default {
	name: 'VButton',
	props: {
		disabled: {
			type: Boolean,
			default: false
		},
		tag: {
			type: String,
			default: ''
		},
		icon: {
			type: Object,
			default: null
		},
		text: {
			type: String,
			default: ""
		},
		bgColor: {
			type: String,
			default: "bg-red-500"
		},
		textColor: {
			type: String,
			default: "text-white"
		},
		size: {
			type: String,
			default: "base"
		}
	},
	computed: {
		tags(){
			const keys = Object.keys(this.$attrs);
			return (
				this.tag ? 
					this.tag :
				keys.includes("href") ? 
					"a" :
				keys.includes("to") ?
					"router-link" :
					"button"
			)
		},
		sizes(){
			switch(this.size){
				case 'xs' :
					return 'btn-xs'
				case 'sm' :
					return 'btn-sm'
				case 'lg' :
					return 'btn-lg'
				default:
					return 'btn-base'
			}
		}
	},
}
</script>
<style lang="scss">
	.v-button{
		@apply inline-flex items-center rounded outline-none cursor-pointer p-2 gap-2 text-sm leading-tight;
		&.hasText {
			@apply py-1.5 px-2.5;
		}
		@media(min-width:768px){
			&.btn-xs{
				@apply p-1 gap-1.5 text-sm leading-none;
			}
			&.btn-sm{
				@apply p-1.5 gap-2 text-sm leading-none;
			}
			&.btn-base{
				@apply p-2 gap-3 text-base leading-none;
			}
			&.btn-lg{
				@apply p-2 gap-3 text-lg leading-none;
			}
			&.hasText {
				&.btn-xs{
					@apply px-2;
				}
				&.btn-sm{
					@apply px-2.5;
				}
				&.btn-base{
					@apply px-4;
				}
			}
		}
	}		
</style>