import { computed } from "vue";
import store from "@/store";

export const documents = computed(() => store.state["Settings"].documents);

export const getDocuments = async () => {
  await store.dispatch("getRows", {
    url: "auth/product-documents-saved",
    prop: "documents",
    modules: "Settings",
  });
};

export const createDocument = async (id) => {
  const res = await store.dispatch("createRow", {
    url: `auth/document-saved/${id}`,
    prop: "documents",
    modules: "Settings",
  });
  return res;
};

export const updateSection = async (data, id) => {
  const res = await store.dispatch("updateRow", {
    url: "auth/settings-section",
    prop: "sections",
    modules: "Settings",
    id,
    data,
  });
  return res;
};

export const deleteSection = async (id) => {
  await store.dispatch("deleteRow", {
    url: "auth/settings-section",
    prop: "sections",
    modules: "Settings",
    id,
  });
};
