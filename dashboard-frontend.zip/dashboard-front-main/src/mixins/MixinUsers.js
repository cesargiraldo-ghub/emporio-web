import {computed} from "vue"
import store from "@/store";

export const user = computed(() => store.state['Users'].user);
export const users = computed(() => store.state['Users'].users);
export const fullUsers = computed(() => [store.state['Users'].user, ...store.state['Users'].users]);

export const getUsers = async () => {
	await store.dispatch("getOptions", {
		url: "auth/users",
		prop: "users",
		modules: "Users"
	});
}

export const getUser = async (id) => {
	const res = await store.dispatch("getRow", {
		url: "auth/user",
		id
	});
	return res;
}

export const createUser = async (data) => {
	const res = await store.dispatch("createRow", {
		url: "auth/user",
		prop: "users",
		modules: "Users",
		data
	});
	return res;
};

export const updateUser = async (data, id) => {
	const res = await store.dispatch("updateRow", {
		url: "auth/user",
		prop: "users",
		modules: "Users",
		id,
		data
	});
	return res;
};

export const deleteUser = async (id) => {
	const res = await store.dispatch("deleteRow", {
		url: "auth/user",
		prop: "users",
		modules: "Users",
		id
	});
	return res;
};

export const updateProfile = async (data) => {
	const res = await store.dispatch("updateRow", {
		url: "auth/profile",
		prop: "users",
		modules: "Users",
		data
	});
	return res;
};
