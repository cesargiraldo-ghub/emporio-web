import {computed} from "vue"
import { onLeasedState, onProductState, onState } from "@/assets/js/filters"
import store from "@/store";

export const products = computed(() => store.state['Products'].products);

export const updateProductsStore = (data) => {
	store.commit("SET_STATE", {prop: "products", modules: "Products", data});
}

export const getProducts = async () => {
	await store.dispatch("getRows", {
		url: "auth/products",
		prop: "products",
		modules: "Products"
	});
}

export const getProduct = async (id) => {
	const res = await store.dispatch("getRow", {
		url: "auth/product",
		id
	});
	return res;
}

export const createProduct = async (data) => {
	const res = await store.dispatch("createRow", {
		url: "auth/products",
		prop: "products",
		modules: "Products",
		data
	});
	return res;
};

export const updateProduct = async (data, id) => {
	const res = await store.dispatch("updateRow", {
		url: "auth/product",
		prop: "products",
		modules: "Products",
		id,
		data
	});
	return res;
};

export const deleteProduct = async (id) => {
	const res = await store.dispatch("deleteRow", {
		url: "auth/product",
		prop: "products",
		modules: "Products",
		id
	});
	return res; 
};

export const state = {
	options: [
		onState("new"),
		onState("used"),
	]
};

export const leasedState = {
	options: [
		onLeasedState("draft"),
		onLeasedState("initial"),
		onLeasedState("delivery"),
		onLeasedState("leased"),
		onLeasedState("finished")
	]
};

export const productState = {
	options: [
		onProductState("new"),
		onProductState("relocation")
	]
};