import { computed } from "vue";
import store from "@/store";

export const sections = computed({
  get() {
    return store.state["Settings"].sections;
  },
  set(data) {
    store.commit("SET_STATE", { prop: "sections", modules: "Settings", data });
  },
});

export const profiles = computed(() => store.state["Settings"].profiles);

export const getSections = async () => {
  await store.dispatch("getOptions", {
    url: "auth/settings-sections",
    prop: "sections",
    modules: "Settings",
  });
};

export const createSection = async (data, index) => {
  const res = await store.dispatch("createRow", {
    url: "auth/settings-sections",
    prop: "sections",
    modules: "Settings",
    data,
    reverse: true,
    index,
    add: sections.value.length
  });
  return res;
};

export const updateSection = async (data, id) => {
  const res = await store.dispatch("updateRow", {
    url: "auth/settings-section",
    prop: "sections",
    modules: "Settings",
    id,
    data,
  });
  return res;
};

export const deleteSection = async (id) => {
  const res = await store.dispatch("deleteRow", {
    url: "auth/settings-section",
    prop: "sections",
    modules: "Settings",
    id,
  });
  return res;
};
