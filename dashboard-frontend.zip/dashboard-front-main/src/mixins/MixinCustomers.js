import {computed} from "vue"
import store from "@/store";

export const customers = computed(() => store.state['Customers'].customers);

export const proprietors = computed(() => customers.value.filter(item => item.customerType.includes(1)));
export const leaseholders = computed(() => customers.value.filter(item => item.customerType.includes(2)));
export const updateCustomersStore = (data) => {
	store.commit("SET_STATE", {prop: "customers", modules: "Customers", data});
}

export const getCustomers = async () => {
	await store.dispatch("getRows", {
		url: "auth/customers",
		prop: "customers",
		modules: "Customers"
	});
}

export const getCustomer = async (id) => {
	const res = await store.dispatch("getRow", {
		url: "auth/customers",
		id
	});
	return res;
}

export const createCustomer = async (data) => {
	const res = await store.dispatch("createRow", {
		url: "auth/customer",
		prop: "customers",
		modules: "Customers",
		data
	});
	return res;
};

export const updateCustomer = async (data, id) => {
	const res = await store.dispatch("updateRow", {
		url: "auth/customer",
		prop: "customers",
		modules: "Customers",
		id,
		data
	});
	return res;
};

export const getProprietors = async () => {
	await store.dispatch("getRows", {
		url: "auth/proprietors",
		prop: "proprietors",
		modules: "Customers"
	});
}

export const getProprietor = async (id) => {
	const res = await store.dispatch("getRow", {
		url: "auth/proprietors",
		id
	});
	return res;
}

export const createProprietor = async (data) => {
	const res = await store.dispatch("createRow", {
		url: "auth/proprietors",
		prop: "proprietors",
		modules: "Customers",
		data
	});
	return res;
};

export const updateProprietor = async (data, id) => {
	const res = await store.dispatch("updateRow", {
		url: "auth/proprietors",
		prop: "proprietors",
		modules: "Customers",
		id,
		data
	});
	return res;
};

export const deleteProprietor = async (id) => {
	await store.dispatch("deleteRow", {
		url: "auth/proprietors",
		prop: "proprietors",
		modules: "Customers",
		id
	});
};

export const getLeaseholders = async () => {
	await store.dispatch("getRows", {
		url: "auth/leaseholders",
		prop: "leaseholders",
		modules: "Customers"
	});
}

export const getLeaseholder = async (id) => {
	const res = await store.dispatch("getRow", {
		url: "auth/leaseholders",
		id
	});
	return res;
}

export const createLeaseholder = async (data) => {
	const res = await store.dispatch("createRow", {
		url: "auth/leaseholders",
		prop: "leaseholders",
		modules: "Customers",
		data
	});
	return res;
};

export const updateLeaseholder = async (data, id) => {
	const res = await store.dispatch("updateRow", {
		url: "auth/leaseholders",
		prop: "leaseholders",
		modules: "Customers",
		id,
		data
	});
	return res;
};

export const deleteLeaseholder = async (id) => {
	await store.dispatch("deleteRow", {
		url: "auth/leaseholders",
		prop: "leaseholders",
		modules: "Customers",
		id
	});
};