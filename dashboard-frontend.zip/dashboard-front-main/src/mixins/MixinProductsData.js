import { computed } from "vue";
import { onLeasedState, onProductState, onState } from "@/assets/js/filters";
import store from "@/store";

export const productsData = computed(() => store.state["Products"].productsData);

export const updateProductsDataStore = (data) => {
  store.commit("SET_STATE", { prop: "productsData", modules: "Products", data });
};

export const getProducts = async () => {
  await store.dispatch("getRows", {
    url: "auth/products-data",
    prop: "productsData",
    modules: "Products",
  });
};

export const getProduct = async (id) => {
  const res = await store.dispatch("getRow", {
    url: "auth/product-data",
    prop: "productsData",
    modules: "Products",
    id,
  });
  return res;
};

export const createProduct = async (data) => {
  const res = await store.dispatch("createRow", {
    url: "auth/products-data",
    prop: "productsData",
    modules: "Products",
    data,
  });
  return res;
};

export const updateProduct = async (data, id) => {
  const res = await store.dispatch("updateRow", {
    url: "auth/product-data",
    prop: "productsData",
    modules: "Products",
    id,
    data,
  });
  return res;
};

export const deleteProduct = async (id) => {
  const res = await store.dispatch("deleteRow", {
    url: "auth/product-data",
    prop: "productsData",
    modules: "Products",
    id,
  });
  return res;
};

export const state = {
  options: [onState("new"), onState("used")],
};

export const leasedState = {
  options: [
    onLeasedState("available"),
    onLeasedState("retired"),
  ],
};

export const productState = {
  options: [onProductState("new"), onProductState("relocation")],
};
