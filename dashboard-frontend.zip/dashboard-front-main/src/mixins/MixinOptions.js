import { computed } from "vue"
import store from "@/store";
import { sections } from "./MixinSections";

export const rols = computed(() => store.state['Rols'].rols);
export const customersTypes = computed(() => store.state.customersTypes);
export const bussinessTypes = computed(() => store.state.bussinessTypes);
export const productsTypes = computed(() => store.state.productsTypes);
export const observationsTypes = computed(() => store.state.observationsTypes);
export const atmosphere = computed({
  get() {
    return store.state.atmosphere;
  },
  set(data) {
    store.commit("SET_STATE", { prop: "atmosphere", data });
  },
});


export const getRols = async () => {
	await store.dispatch("getOptions", {
		url: "auth/rols",
		prop: "rols",
		modules: "Rols"
	});
}

export const getCustomersTypes = async () => {
	await store.dispatch("getOptions", {
		url: "auth/customers-types",
		prop: "customersTypes"
	});
}

export const getBussinessTypes = async () => {
	await store.dispatch("getOptions", {
		url: "auth/bussiness-types",
		prop: "bussinessTypes"
	});
}

export const getProductsTypes = async () => {
	await store.dispatch("getOptions", {
		url: "auth/products-types",
		prop: "productsTypes"
	});
}

export const createProductsTypes = async (data) => {
	await store.dispatch("createRow", {
		url: "auth/product-type",
		prop: "productsTypes",
		data
	});
}

export const updateProductsTypes = async ({ id, ...data }) => {
	await store.dispatch("updateRow", {
		url: "auth/product-type",
		prop: "productsTypes",
		data,
		id,
	});
}

export const deleteProductsTypes = async (id) => {
	await store.dispatch("deleteRow", {
		url: "auth/product-type",
		prop: "productsTypes",
		id,
	});
}

export const getObservationsTypes = async () => {
	await store.dispatch("getOptions", {
		url: "auth/observations-types",
		prop: "observationsTypes"
	});
}

export const createObservationsTypes = async (data) => {
	await store.dispatch("createRow", {
		url: "auth/observation-type",
		prop: "observationsTypes",
		data
	});
}

export const updateObservationsTypes = async ({ id, ...data }) => {
	await store.dispatch("updateRow", {
		url: "auth/observation-type",
		prop: "observationsTypes",
		data,
		id,
	});
}

export const deleteObservationsTypes = async (id) => {
	await store.dispatch("deleteRow", {
		url: "auth/observation-type",
		prop: "observationsTypes",
		id,
	});
}
export const getAtmosphere = async () => {
	await store.dispatch("getOptions", {
		url: "auth/atmosphere",
		prop: "atmosphere"
	});
}

export const createAtmosphere = async (data) => {
	await store.dispatch("createRow", {
		url: "auth/atmosphere",
		prop: "atmosphere",
		data
	});
}

export const updateAtmosphere = async (data) => {
	await store.dispatch("updateRows", {
		url: "auth/atmosphere",
		prop: "atmosphere",
		data,
	});
}

export const deleteAtmosphere = async (id) => {
	const res = await store.dispatch("deleteRow", {
		url: "auth/atmosphere",
		prop: "atmosphere",
		id,
	});

	if (res) {
		const data = sections.value.map(item => {
			item.atmosphere = item.atmosphere.filter(i => i != id);
			return item;
		})
		store.commit("SET_STATE", { prop: "sections", data })
	}
	return res;
}