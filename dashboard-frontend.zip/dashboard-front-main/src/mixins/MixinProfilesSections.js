import {computed} from "vue"
import store from "@/store";

export const profiles = computed(() => (store.state['Settings'].profiles));

export const getProfilesSections = async () => {
	await store.dispatch("getOptions", {
		url: "auth/settings-profile",
		prop: "profiles",
		modules: "Settings",
		map: (data) => (data.map(item => ({overlay: false, ...item})))
	});
}