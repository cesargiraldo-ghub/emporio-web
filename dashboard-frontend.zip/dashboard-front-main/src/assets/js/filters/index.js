export const clearString = (strg) => {
  return strg ? strg.normalize("NFD")
    .replace(/[\u0300-\u036f-\s]/g, "")
    .replace(/\s/, "")
    .toLowerCase() : "";
};

export const date = (value) => {
  const date = new Date(value);
  return `${date
    .getUTCDate()
    .toLocaleString("es", { minimumIntegerDigits: 2 })}/${(
      date.getUTCMonth() + 1
    ).toLocaleString("es", {
      minimumIntegerDigits: 2,
    })}/${date.getUTCFullYear()}`;
};

export const dateFormat = (d) => {
  return `${d.getUTCFullYear()}-${(d.getUTCMonth() + 1).toLocaleString("es", {
    minimumIntegerDigits: 2,
  })}-${d.getUTCDate().toLocaleString("es", { minimumIntegerDigits: 2 })}`;
};

export const code = (id, current) => {
  const value = `${id}${date(current)}`;
  return value.replace(/\//g, "");
};

export const currency = (value) => {
  const currency = value?.toLocaleString("es-CO", {
    currency: "COP",
    maximumFractionDigits: 0,
    style: "currency",
  });
  return currency;
};

export const getValueArrayJSON = (rows, prop, value) => {
  return rows.find((item) => item[prop] == value);
};

export const onLeasedState = (key) => {
  switch (key) {
    case "available":
      return { color: "text-green-500", label: "Disponible", key: "available" };
    case "draft":
      return { color: "text-orange-500", label: "Borrador", key: "draft" };
    case "initial":
      return { color: "text-sky-500", label: "Inicial", key: "initial" };
    case "delivery":
      return { color: "text-emerald-500", label: "Entrega", key: "delivery" };
    case "leased":
      return { color: "text-blue-500", label: "Alquilado", key: "leased" };
    case "finished":
      return { color: "text-gray-500", label: "Finalizado", key: "finished" };
    case "retired":
      return { color: "text-rose-500", label: "Retirado", key: "retired" };
  }
};

export const onObservationStatus = (key) => {
  switch (key) {
    case "reception":
      return { color: "text-sky-500", label: "Recepción", key: "reception" };
    case "quoting":
      return { color: "text-orange-500", label: "Cotizando", key: "quoting" };
    case "initial-work":
      return {
        color: "text-blue-500",
        label: "Obra inicial",
        key: "initial-work",
      };
    case "finish-work":
      return {
        color: "text-indigo-500",
        label: "Obra Finalizada",
        key: "finish-work",
      };
    case "solved":
      return { color: "text-green-500", label: "Solucionado", key: "solved" };
    case "finished":
      return { color: "text-slate-500", label: "Finalizado", key: "finished" };
    case "canceled":
      return { color: "text-red-500", label: "Cancelado", key: "canceled" };
  }
};

export const onResponsible = (key) => {
  switch (key) {
    case "realState":
      return {
        color: "text-indigo-600",
        label: "Inmobiliaria",
        key: "realState",
      };
    case "proprietor":
      return {
        color: "text-violet-600",
        label: "Propietario",
        key: "proprietor",
      };
    case "leaseholder":
      return {
        color: "text-rose-600",
        label: "Arrendatario",
        key: "leaseholder",
      };
  }
};

export const onState = (key) => {
  switch (key) {
    case "new":
      return { color: "text-emerald-500", label: "Nuevo", key: "new" };
    case "used":
      return { color: "text-amber-500", label: "Usado", key: "used" };
  }
};

export const onProductState = (key) => {
  switch (key) {
    case "relocation":
      return {
        color: "text-sky-500",
        label: "Recolocacion",
        key: "relocation",
      };
    case "new":
      return { color: "text-teal-500", label: "Reciente", key: "new" };
  }
};

export const setValuesForm = (fields, callback) => {
  for (let prop in fields) fields[prop].value = callback(prop);
};

export const onFilterURL = (
  { public_id, resource_type },
  transform = "c_thumb,h_350,w_350/",
  format = "jpg"
) => {
  const { VUE_APP_CLOUDINARY } = process.env;
  return `https://res.cloudinary.com/${VUE_APP_CLOUDINARY}/${resource_type}/upload/${transform}${public_id}.${format}`;
};

export const onBlobToString = (blob) => {
  return new Promise((resolve) => {
    const reader = new FileReader();

    reader.addEventListener("loadend", (e) => {
      const text = e.srcElement.result;
      resolve(JSON.parse(text));
    });

    reader.readAsText(blob);
  });
};

export const reverseString = (str) => {
  return str.split("").reduce((acc, char) => char + acc, "");
};

export const idSection = (sufix = "") => {
  const date = new Date();
  let value = date.toLocaleString("es-CO", { dateStyle: "medium" });
  value = value.split("/");
  value.reverse();
  value = value.join("");
  return Number(value + sufix);
};
