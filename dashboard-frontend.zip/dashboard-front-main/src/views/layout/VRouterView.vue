<template>
	<router-view v-slot="{ Component }">
		<transition name="slide-down" mode="out-in">
			<component :is="Component" />
		</transition>
	</router-view>
</template>