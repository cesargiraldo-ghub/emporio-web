<template>
	<div class="flex flex-col gap-4">
		<div class="flex flex-wrap justify-between">
			<div>
				<slot name="toolsBar"></slot>	
			</div>
			<div class="flex flex-wrap gap-2">
				<VButton v-if="$can('create', subject)" @click="createRow" bgColor="bg-green-500" :icon="icons.faPlus" />
				<!-- <VButton bgColor="bg-blue-500" :icon="icons.faFileArrowUp" />
				<VButton bgColor="bg-amber-500" :icon="icons.faFileArrowDown" /> -->
			</div>
		</div>
		<div class="p-4 bg-white rounded relative">
			<VLoader position="absolute" :show="overlay"></VLoader>
			<VTable v-bind="table" :rows="rows" @rowSelected="getRowTable">
				<template v-for="slot in table.columns.filter(item => item.field != 'actions')" #[slot.field]="{row, value}" :key="`slot_${slot.field}`">
					<span>
						<slot :name="slot.field" :value="value" :row="row">
							{{value}}
						</slot>
					</span>
				</template>
				<template v-slot:actions="{row}">
					<div class="inline-flex flex-wrap gap-2">
						<slot name="action" :row="row"></slot>
						<VButton v-if="$can('update', 'users')" @click="updateRow(row)" bgColor="bg-transparent" textColor="text-blue-500" :icon="icons.faPen" />
						<VButton v-if="$can('delete', 'users')" @click="deleteRow(row.id)" bgColor="bg-transparent" textColor="text-red-500" :icon="icons.faTrash" />
					</div>
				</template>
			</VTable>
		</div>
		<VModal v-model="modal.show" v-bind="modal">
			<VForm v-bind="form" @submit="onSubmit" ref="form"/>
			<template #top-tools>
				<VButton v-if="$can('delete', 'users') && modal.type == 'update'" :disabled="overlay" @click="deleteRow(modal.id)" bgColor="bg-transparent" textColor="text-red-500" :icon="icons.faTrash" />
			</template>
			<template #footer>
				<div class="flex gap-3">
					<VButton :disabled="overlay" text="Guardar" bgColor="bg-green-500" @click="sendForm" />
					<VButton :disabled="overlay" text="Cerrar" bgColor="bg-blue-500" @click="modal.show = false" />
				</div>
			</template>
		</VModal>
	</div>
</template>
<script>
import { faPen, faPlus, faTrash, faFileArrowDown, faFileArrowUp } from '@fortawesome/free-solid-svg-icons'

import VTable from "@/components/VTable"
import VButton from "@/components/VButton"
import VModal from "@/components/VModal"
import VForm from "@/components/VForm/VForm"
import VLoader from "@/components/VLoader"

export default {
	name: 'VCrud',
	components: {
		VTable,
		VButton,
		VModal,
		VForm,
		VLoader
	},
	props: {
		table: {
			type: Object,
			required: true
		},
		form: {
			type: Object,
			required: true
		},
		url: {
			type: Object,
			required: true
		},
		modules: {
			type: String,
			default: ""
		},
		prop: {
			type: String,
			required: true
		},
		subject: {
			type: String,
			required: true
		}
	},
	data() {
		return {
			icons: {
				faPen, faPlus, faTrash, faFileArrowDown, faFileArrowUp
			},
			overlay: false,
			modal: {
				show: false,
				title: null,
				size: "xs",
				aside: "right",
				overlay: false,
				type: null,
				id: null
			},
			row: null
		}
	},
	computed: {
		rows(){
			const {modules, prop} = this;
			const state = modules ? this.$store.state[modules] : this.$store.state;
			return state[prop];
		}
	},
	async mounted(){
		const {url, prop, modules} = this;
		await this.$store.dispatch("getRows", {
			url: url?.get,
			prop, modules
		});
	},
	methods: {
		getRowTable(row){
			this.row = row;
		},
		sendRowTable(){
			this.$emit("getRowTable", this.row);
			return this.row; 
		},
		sendForm(){
			this.$refs["form"].onSubmit();
		},
		async onSubmit(data){
			this.overlay = true;
			const {url, prop, modules} = this;

			let state = false;

			const { type, id } = this.modal;

			switch( type ){
				case "create" :
					state = await this.$store.dispatch("createRow", {
						url: url?.create,
						data, modules, prop
					});
					break;

				case "update" :
					state = await this.$store.dispatch("updateRow", { 
						url: url?.update,
						id, data, modules, prop
					});
					break;
			}
			this.overlay = false;
			if(state){
				Object.assign(this.modal, {
					show: false,
					type: null
				});
			}
		},
		createRow(){
			let fields = this.form.fields;

			for(let prop in fields)
				fields[prop].value = null;
			
			Object.assign(this.modal, {
				title: "Crear",
				show: true,
				type: "create",
				id: null
			});
		},
		updateRow({id, ...row}){
			let fields = this.form.fields;
			for(let prop in fields){

				if(fields[prop].attr?.type == "table")
					fields[prop].attr.row = row[prop];

				fields[prop].value = row[prop]?.id || row[prop];
			}
			
			Object.assign(this.modal, {
				title: "Actualizar",
				show: true,
				type: "update",
				id
			});
		},
		async deleteRow(id){
			this.overlay = true;
			const {url, prop, modules} = this;
			const state = await this.$store.dispatch("deleteRow", {
				url: url?.delete,
				id, modules, prop
			});
			this.overlay = false;
			if(state)
				Object.assign(this.modal, {
					show: false,
					id: null
				});
		}
	}
}
</script>