<template>
  <VFieldset :border="false" :fixed-tools="true">
    <template #tools v-if="tools">
      <VButton
        @click="onReload"
        bgColor="bg-indigo-500"
        :icon="faArrowRotateLeft"
      />
      <template v-if="!inventory">
        <VButton
          v-if="can('create', 'products')"
          :to="{ name: 'product-data-create' }"
          bgColor="bg-green-500"
          :icon="faPlus"
        />
        <VButton
          v-if="can('export', 'products')"
          @click="onExporProducts"
          bgColor="bg-orange-500"
          :icon="faFileDownload"
        />
        <VButton
          v-if="can('import', 'products')"
          @click="onModalImport"
          bgColor="bg-blue-500"
          :icon="faFileUpload"
        />
      </template>
    </template>
    <template #default>
      <VLoader :show="overlay">
        <div class="flex flex-wrap xl:flex-nowrap gap-5 xl:mt-3">
          <VInput
            class="w-24"
            v-model="pages.perPage"
            @update:modelValue="pages.current = 1"
            v-bind="pages.select"
            name="perPage"
          />
          <div
            class="flex gap-5 ml-auto xl:ml-0"
            v-if="tools && can('delete', 'products')"
          >
            <VButton
              @click="onMultiSelect"
              size="sm"
              bgColor="bg-blue-200"
              textColor="text-blue-600"
              class="font-medium"
              :text="
                multiSelect ? 'Descativar Seleccion' : 'Seleccion Multiple'
              "
            />
            <VButton
              :disabled="!values.length"
              v-if="multiSelect"
              @click="onDeleteValidate(values)"
              size="sm"
              bgColor="bg-red-200"
              textColor="text-red-600"
              class="font-medium"
              text="Eliminar Inmuebles"
            />
          </div>
          <div
            class="flex flex-col md:flex-row gap-5 w-full xl:w-auto flex-grow items-center"
          >
            <span class="my-auto xl:ml-auto font-semibold opacity-80">
              <span class="text-red-500">{{ totalItems.current }}</span> de
              {{ totalItems.total }} Inmuebles
            </span>
            <VPagination
              class="md:ml-auto"
              :pages="pagination.pages"
              v-model:current="pages.current"
            ></VPagination>
          </div>
        </div>
        <VTable class="my-4" v-bind="table">
          <template #real-state="{ row, index }">
            <div
              class="flex gap-4 w-full"
              :class="{ 'select-none': multiSelect }"
            >
              <span v-if="multiSelect" @click="onClickCheck($event, index)">
                <VCheckItem
                  @change="onChangeCheck(row.id)"
                  :value="row.id"
                  :showLabel="false"
                  :checked="onChecked(row.id)"
                />
              </span>
              <span class="self-center font-bold">
                {{ row.id }}
              </span>
              <div
                class="flex flex-col py-2 flex-grow"
                :class="
                  multiSelect
                    ? 'pointer-events-none opacity-70'
                    : 'pointer-events-auto'
                "
              >
                <div class="flex flex-col">
                  <div
                    class="flex flex-wrap items-center xl:items-stretch xl:flex-nowrap gap-4 mb-4 lg:mb-3 pb-4 lg:pb-3 border-b border-stone-200"
                  >
                    <div
                      class="flex flex-col w-full xl:w-1 flex-grow gap-1.5"
                      :class="{ 'cursor-pointer': inventory }"
                    >
                      <div
                        class="flex justify-between flex-wrap gap-2 sm:flex-nowrap sm:gap-4 items-start"
                      >
                        <h3
                          :title="row.name"
                          @click="inventory ? onProductDetail(row.id) : null"
                          class="text-sm md:text-base font-semibold flex-grow w-full sm:w-auto order-1 sm:order-first"
                        >
                          {{ row.name }}
                        </h3>
                        <VBadge v-bind="onProductState(row.product_state)" />
                        <VBadge v-bind="onState(row.state)" />
                      </div>
                      <div
                        @click="inventory ? onProductDetail(row.id) : null"
                        class="flex flex-wrap sm:flex-nowrap gap-4 opacity-80"
                      >
                        <span class="w-full sm:w-32">
                          <b class="font-medium">Code:</b> {{ row.code }}
                        </span>
                        <span class="w-full sm:w-1 font-medium flex-grow">
                          {{ row.address }}
                        </span>
                        <span class="flex-grow sm:flex-grow-0 sm:ml-auto">
                          <VBadge class="flex flex-col" color="text-indigo-600">
                            {{ row.bussiness_type?.name }}
                          </VBadge>
                        </span>
                        <span class="flex-grow sm:flex-grow-0">
                          <VBadge class="flex flex-col" color="text-purple-600">
                            {{ row.product_type?.name }}
                          </VBadge>
                        </span>
                      </div>
                    </div>
                    <div
                      class="flex xl:flex-col gap-1 xl:text-right items-center flex-grow md:flex-grow-0"
                    >
                      <span class="text-base font-semibold opacity-90 w-28">
                        {{ currency(row?.price) || "----" }}
                      </span>
                      <span class="xl:mt-auto ml-auto">
                        <VBadge
                          :options="
                            leased_state.map((item) => onLeasedState(item))
                          "
                          @change="onLeasedStateChange($event, row)"
                          position="right"
                          v-bind="onLeasedState(row.leased_state)"
                        />
                      </span>
                    </div>
                    <div
                      v-if="
                        can('read', 'observations') ||
                        can('create', 'products') ||
                        can('update', 'products') ||
                        can('delete', 'products')
                      "
                      class="ml-auto xl:ml-0 hidden md:flex flex-wrap w-28 justify-end"
                    >
                      <VTools
                        :inventory="inventory"
                        :row="row"
                        :tools="tools"
                      ></VTools>
                    </div>
                  </div>
                  <div
                    class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-7 gap-x-4 gap-y-6 md:gap-6 xl:gap-4 text-gray-600 text-left items-center"
                  >
                    <template v-if="inventory">
                      <div class="flex gap-2 items-center" title="Inventario">
                        <fa-icon
                          :class="
                            row.date_inventory
                              ? 'text-emerald-400'
                              : 'text-gray-400'
                          "
                          class="w-4 h-auto aspect-square inline-block"
                          :icon="faCalendarCheck"
                        ></fa-icon>
                        <span>
                          {{
                            row.date_inventory
                              ? date(row.date_inventory)
                              : "----"
                          }}
                        </span>
                      </div>
                      <div class="flex gap-2 items-center" title="Entrega">
                        <fa-icon
                          :class="row.date ? 'text-blue-400' : 'text-gray-400'"
                          class="w-4 h-auto aspect-square inline-block"
                          :icon="faCalendarDay"
                        ></fa-icon>
                        <span>
                          {{ row.date ? date(row.date) : "----" }}
                        </span>
                      </div>
                      <div
                        class="col-span-2 grid grid-cols-[1fr_auto_1fr] gap-4"
                      >
                        <div
                          class="flex gap-2 items-center"
                          title="Propietario"
                        >
                          <fa-icon
                            :class="
                              row.signature_proprietor
                                ? 'text-purple-400'
                                : 'text-gray-400'
                            "
                            class="w-4 h-auto aspect-square inline-block"
                            :icon="faHouse"
                          ></fa-icon>
                          <VDropdown>
                            <template #default>
                              {{
                                row.proprietor_data?.fullName ||
                                row.proprietor?.fullName ||
                                "----"
                              }}
                            </template>
                            <template #options="{ className }">
                              <template v-if="!row.signature_proprietor">
                                <router-link
                                  :class="className"
                                  class="font-medium"
                                  target="_blank"
                                  :to="{
                                    name: 'product-info',
                                    params: {
                                      id: row.id,
                                      customer: 'propietario',
                                    },
                                  }"
                                >
                                  Pagina
                                </router-link>
                                <span
                                  @click="
                                    onEmail(row.id, 'propietario', 'signature')
                                  "
                                  :class="className"
                                >
                                  Email
                                </span>
                              </template>
                              <template v-else>
                                <router-link
                                  :class="className"
                                  class="font-medium"
                                  target="_blank"
                                  :to="{
                                    name: 'product-info',
                                    params: {
                                      id: row.id,
                                      customer: 'propietario',
                                    },
                                  }"
                                >
                                  Pagina
                                </router-link>
                                <span
                                  @click="onPDF(row.id, 'propietario')"
                                  :class="className"
                                >
                                  PDF
                                </span>
                                <span
                                  @click="onEmail(row.id, 'propietario')"
                                  :class="className"
                                >
                                  Email
                                </span>
                              </template>
                            </template>
                          </VDropdown>
                        </div>
                        <VButton
                          :icon="faArrowRightArrowLeft"
                          bgColor="bg-transparent"
                          textColor="text-blue-500"
                          @click="changeCustomers(row)"
                        ></VButton>
                        <div
                          class="flex gap-2 items-center"
                          title="Arrendatario"
                        >
                          <fa-icon
                            :class="
                              row.signature ? 'text-rose-400' : 'text-gray-400'
                            "
                            class="w-4 h-auto aspect-square inline-block"
                            :icon="faUser"
                          ></fa-icon>
                          <VDropdown>
                            <template #default>
                              {{
                                row.leaseholder_data?.fullName ||
                                row.leaseholder?.fullName ||
                                "----"
                              }}
                            </template>
                            <template #options="{ className }">
                              <template v-if="!row.signature">
                                <router-link
                                  :class="className"
                                  class="font-medium"
                                  target="_blank"
                                  :to="{
                                    name: 'product-info',
                                    params: {
                                      id: row.id,
                                      customer: 'arrendatario',
                                    },
                                  }"
                                >
                                  Pagina
                                </router-link>
                                <span
                                  @click="
                                    onEmail(row.id, 'arrendatario', 'signature')
                                  "
                                  :class="className"
                                >
                                  Email
                                </span>
                              </template>
                              <template v-else>
                                <router-link
                                  :class="className"
                                  class="font-medium"
                                  target="_blank"
                                  :to="{
                                    name: 'product-info',
                                    params: {
                                      id: row.id,
                                      customer: 'arrendatario',
                                    },
                                  }"
                                >
                                  Pagina
                                </router-link>
                                <span
                                  @click="onPDF(row.id, 'arrendatario')"
                                  :class="className"
                                >
                                  PDF
                                </span>
                                <span
                                  @click="onEmail(row.id, 'arrendatario')"
                                  :class="className"
                                >
                                  Email
                                </span>
                              </template>
                            </template>
                          </VDropdown>
                        </div>
                      </div>
                      <div
                        class="flex gap-2 items-center col-span-2"
                        title="Agente"
                      >
                        <fa-icon
                          :class="row.user ? 'text-blue-400' : 'text-gray-400'"
                          class="w-4 h-auto aspect-square inline-block"
                          :icon="faUserTie"
                        ></fa-icon>
                        <span class="font-medium">
                          <span
                            :class="{
                              'bg-orange-100 text-orange-500':
                                row.user && !row.user?.signature,
                            }"
                            >{{ row.user?.fullName || "----" }}
                          </span>
                          <span
                            :class="{
                              'bg-orange-100 text-orange-500':
                                !row.second_user?.signature,
                            }"
                            v-if="row.second_user"
                            class="pl-2 ml-2 border-l border-stone-400"
                            >{{ row.second_user?.fullName }}</span
                          >
                        </span>
                      </div>
                    </template>
                    <div
                      class="flex flex-wrap gap-1 col-span-1 sm:col-span-2 xl:col-start-7 xl:col-end-8 md:justify-end md:text-right"
                    >
                      <b class="font-normal">Por:</b>
                      <span class="font-medium">
                        {{ row.created_by?.fullName || "----" }}
                      </span>
                    </div>
                    <div
                      v-if="
                        can('read', 'observations') ||
                        can('create', 'products') ||
                        can('update', 'products') ||
                        can('delete', 'products')
                      "
                      class="ml-auto xl:ml-0 flex flex-wrap w-28 justify-end md:hidden"
                    >
                      <VTools
                        :inventory="inventory"
                        :row="row"
                        :tools="tools"
                      ></VTools>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </VTable>
        <div
          class="flex flex-col items-center md:flex-row md:items-start gap-5"
        >
          <span class="md:mr-auto font-semibold opacity-80">
            <span class="text-red-500">{{ totalItems.current }}</span> de
            {{ totalItems.total }} Inmuebles
          </span>
          <VPagination
            :pages="pagination.pages"
            v-model:current="pages.current"
          ></VPagination>
        </div>
      </VLoader>
      <VModal v-model="modal.show" v-bind="modal">
        <VLoader :show="overlay">
          <ProductInfoDetail
            v-if="modal.type == 'product'"
            v-bind="{ product }"
          >
            <div class="grid md:grid-cols-2 gap-6">
              <div
                v-if="product.signature_proprietor"
                class="flex flex-col items-center"
              >
                <figure
                  class="border-2 border-dashed border-gray-300 rounded overflow-hidden"
                >
                  <img
                    class="block max-w-full"
                    :src="product.signature_proprietor"
                  />
                </figure>
                <figcaption class="mt-1 font-medium">
                  Firma del Propietario
                </figcaption>
              </div>
              <VMessage class="h-28" v-else>
                Sin firma del Propietario
              </VMessage>
              <div v-if="product.signature" class="flex flex-col items-center">
                <figure
                  class="border-2 border-dashed border-gray-300 rounded overflow-hidden"
                >
                  <img class="block max-w-full" :src="product.signature" />
                </figure>
                <figcaption class="mt-1 font-medium">
                  Firma del Arrendatario
                </figcaption>
              </div>
              <VMessage class="h-28" v-else>
                Sin firma del Arrendatario
              </VMessage>
            </div>

            <span class="flex flex-col gap-3 justify-center items-center">
              <VCheckItem
                class="pointer-events-none"
                name="Terminos y condiciones aceptados"
                :checked="product.tyc"
              />
              <VCheckItem
                class="pointer-events-none"
                name="Política de tratamientos de datos personales"
                :checked="product.policy"
              />
            </span>
          </ProductInfoDetail>
          <VForm v-else v-bind="form" @submit="onImportProducts" />
        </VLoader>
        <template #footer>
          <div class="flex gap-3 justify-between">
            <VButton
              :disabled="overlay"
              text="Cerrar"
              bgColor="bg-blue-500"
              @click="modal.show = false"
            />
          </div>
        </template>
      </VModal>
      <VModal v-model="destroy.show" v-bind="destroy">
        <VLoader :show="overlay">
          <div
            class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
          >
            <fa-icon
              class="text-red-500 text-5xl md:text-7xl"
              :icon="faCircleXmark"
            ></fa-icon>
            <p class="font-semibold text-red-500">
              {{ destroy.message }}
            </p>
            <p class="opacity-75 text-sm">
              <i
                >(Esta acción no se puede revertir despues de haberse
                ejecutado)</i
              >
            </p>
          </div>
        </VLoader>
        <template #footer>
          <div class="flex gap-3 justify-between">
            <VButton
              :disabled="overlay"
              text="Cerrar"
              bgColor="bg-gray-500"
              @click="destroy.show = false"
            />
            <VButton
              :disabled="overlay"
              text="Eliminar"
              @click="onDeletes(destroy, values)"
              bgColor="bg-red-500"
            />
          </div>
        </template>
      </VModal>
      <VModal v-model="info.show" v-bind="info">
        <VLoader :show="overlay">
          <div
            class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
          >
            <fa-icon
              class="text-5xl md:text-7xl"
              :class="info.color"
              :icon="info.icon"
            ></fa-icon>
            <div class="flex flex-col gap-4" v-html="info.message"></div>
          </div>
        </VLoader>
        <template #footer>
          <div class="flex gap-3 justify-between">
            <VButton
              :disabled="overlay"
              text="Cerrar"
              bgColor="bg-gray-500"
              @click="info.show = false"
            />
            <VButton
              v-if="info.success"
              :disabled="overlay"
              text="Continuar"
              @click="onUpdateLeasedState(info.props)"
              :bgColor="info.bg"
            />
          </div>
        </template>
      </VModal>
    </template>
  </VFieldset>
</template>
<script>
export default {
  name: "VTablePoducts",
};
</script>
<script setup>
import {
  reactive,
  ref,
  computed,
  defineProps,
  defineEmits,
  onMounted,
  watch,
  provide,
} from "vue";
import {
  faArrowRotateLeft,
  faCircleInfo,
  faPlus,
  faUserTie,
  faHouse,
  faFileDownload,
  faUser,
  faFileUpload,
  faCalendarCheck,
  faCalendarDay,
  faArrowRightArrowLeft,
} from "@fortawesome/free-solid-svg-icons";
import { faCircleXmark } from "@fortawesome/free-regular-svg-icons";
import * as MixinProductsData from "@/mixins/MixinProductsData";
import * as MixinProducts from "@/mixins/MixinProducts";

import {
  date,
  currency,
  onProductState,
  onLeasedState,
  onState,
  onBlobToString,
} from "@/assets/js/filters";

import VCheckItem from "@/components/VForm/VCheck/VCheckItem";
import VInput from "@/components/VForm/VInput";
import VTable from "@/components/VTable";
import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VLoader from "@/components/VLoader";
import VModal from "@/components/VModal";
import VPagination from "@/components/VPagination";
import VBadge from "@/components/VBadge";
import ProductInfoDetail from "@/views/layout/ProductInfoDetail";
import VForm from "@/components/VForm/VForm";
import VMessage from "@/components/VMessage";
import VDropdown from "@/components/VDropdown";
import VTools from "./VTools.vue";
// import VTooltip from "@/components/VTooltip.vue";

import axios from "@/assets/js/axios";

import { useToast } from "vue-toastification";
import { useAbility } from "@casl/vue";

const toast = useToast();

const emits = defineEmits(["reload", "load"]);
const props = defineProps({
  items: {
    type: Array,
    default: () => [],
  },
  inventory: {
    type: Boolean,
    default: false,
  },
  tools: {
    type: Boolean,
    default: true,
  },
});

const { can } = useAbility();

const overlay = ref(false);
provide("overlay", overlay);

const pages = reactive({
  current: 1,
  perPage: 9,
  select: {
    notInherit: true,
    hiddeValidate: true,
    outline: true,
    attr: {
      type: "select",
      clearable: false,
      options: [9, 18, 50],
    },
  },
});

watch(
  () => props.items,
  () => {
    pages.current = 1;
  }
);

const pagination = computed(() => {
  const start = (pages.current - 1) * pages.perPage;
  const end = start + pages.perPage;

  return {
    pages: Math.ceil(props.items.length / pages.perPage),
    start,
    end,
  };
});

const totalItems = computed(() => {
  return {
    current:
      pagination.value.start + pages.perPage > props.items.length
        ? props.items.length
        : pagination.value.start + pages.perPage,
    total: props.items.length,
  };
});

const rows = computed(() => {
  return props.items.slice(pagination.value.start, pagination.value.end);
});

const leased_state = ref(["draft", "leased", "finished"]);

const changeCustomers = async (row) => {
  console.log(row);
  if (props.inventory) {
    overlay.value = true;
    await MixinProducts.updateProduct(
      {
        proprietor: row.leaseholder.id,
        leaseholder: row.proprietor.id,
        signature: row.signature_proprietor,
        signature_proprietor: row.signature,
      },
      row.id
    );
    info.show = false;
    overlay.value = false;
  }
};

const table = reactive({
  rows: rows,
  thead: false,
  columns: [
    {
      field: "real-state",
      label: "Inmueble",
      class: "flex-grow",
      hiddenLabel: true,
    },
  ],
});

const multiSelect = ref(false);
const values = ref([]);

const onMultiSelect = () => {
  multiSelect.value = !multiSelect.value;
  values.value = [];
};

const onChangeCheck = (value) => {
  if (values.value.includes(value)) {
    let index = values.value.indexOf(value);
    if (index > -1) {
      values.value.splice(index, 1);
    }
  } else {
    values.value.push(value);
  }
  values.value.sort();
};

const currentCheck = ref(null);
const onChecked = (value) => values.value.includes(value);

const onClickCheck = (event, index) => {
  if (event.pointerId == 1) {
    if (event.shiftKey) {
      rows.value.forEach((item, i) => {
        let value = item.id;
        if (
          (i > currentCheck.value && i < index) ||
          (i < currentCheck.value && i > index)
        ) {
          if (values.value.includes(value)) {
            let index = values.value.indexOf(value);
            if (index > -1) {
              values.value.splice(index, 1);
            }
          } else {
            values.value.push(value);
          }
          values.value.sort();
        }
      });
    }
    currentCheck.value = index;
  }
};

const modal = reactive({
  show: false,
  type: "product",
  title: "",
  aside: "",
  size: "",
  component: null,
  props: {},
  footer: true,
});

const product = ref(null);
const onProductDetail = async (id) => {
  overlay.value = true;
  product.value = await MixinProducts.getProduct(id);
  overlay.value = false;
  Object.assign(modal, {
    show: true,
    title: "Detalle del Producto",
    type: "product",
    size: "",
    aside: "right",
    props: { product },
    footer: true,
    overlay: false,
  });
};
const destroy = reactive({
  show: false,
  title: "Elminar producto",
  type: "retired",
  size: "xs",
  message: "",
  footer: true,
  overlay: true,
  props: {},
});
provide("destroy", destroy);

const onDelete = async ({ id, leased_state }) => {
  if (["retired", "draft"].includes(leased_state)) {
    overlay.value = true;
    const res = props.inventory
      ? await MixinProducts.deleteProduct(id)
      : await MixinProductsData.deleteProduct(id);
    if (res)
      Object.assign(destroy, {
        show: false,
      });
    overlay.value = false;
  }
};

const onDeleteMulti = async (ids) => {
  overlay.value = true;
  await axios({
    method: "delete",
    url: props.inventory ? "auth/bulk-product" : "auth/products-data",
    data: { ids },
  })
    .then(async ({ data }) => {
      if (props.inventory) await MixinProducts.updateProductsStore(data.rows);
      else await MixinProductsData.updateProductsDataStore(data.rows);

      values.value = [];
      pages.current = 1;
      toast.success(data.message);
      Object.assign(destroy, {
        show: false,
      });
    })
    .catch(({ response }) => {
      const { data } = response;
      toast.error(data.message);
    });
  overlay.value = false;
};

const onDeleteValidate = (ids) => {
  const elements = props.items.filter(
    ({ id, leased_state }) =>
      ids.includes(id) && ["retired", "draft"].includes(leased_state)
  );
  if (elements.length) {
    Object.assign(destroy, {
      show: true,
      message:
        "Uno o mas elementos seleccionados estan retirados si continua estos elementos seran eliminados permanentemente. ¿Desea continuar?",
      type: "multi",
    });
  } else {
    onDeleteMulti(ids);
  }
};

const onDeletes = ({ type, props }, ids) => {
  if (type == "multi") onDeleteMulti(ids);
  else onDelete(props);
};

const onExporProducts = async () => {
  overlay.value = true;
  await axios
    .get("auth/products-data-documents", { responseType: "blob" })
    .then(({ data }) => {
      const href = window.URL.createObjectURL(data);

      const anchorElement = document.createElement("a");

      anchorElement.href = href;
      anchorElement.download = `${Date.now()}-inmuebles.xlsx`;

      document.body.appendChild(anchorElement);
      anchorElement.click();

      document.body.removeChild(anchorElement);
      window.URL.revokeObjectURL(href);

      toast.success("Archivo descargado");
    })
    .catch(({ response }) => {
      const { data } = response;
      onBlobToString(data).then((res) => {
        toast.error(res.message);
      });
    });
  overlay.value = false;
};

const form = reactive({
  textSubmit: "Subir",
  fields: {
    file: {
      label: "Documento",
      attr: {
        type: "file",
        accept: ".xlsx",
        rules: "required|ext:xlsx",
      },
    },
  },
});

const onModalImport = () => {
  Object.assign(modal, {
    show: true,
    title: "Importart Productos",
    type: "form",
    size: "xs",
    footer: false,
    aside: "",
    overlay: true,
  });
};

const onImportProducts = async ({ values }) => {
  overlay.value = true;
  await axios
    .post("auth/products-data-documents", values, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    })
    .then(({ data }) => {
      modal.show = false;
      MixinProductsData.updateProductsDataStore(data.rows);
      toast.success("Archivo cargado");
    })
    .catch(({ response }) => {
      const { data } = response;
      toast.error(data.message);
    });
  overlay.value = false;
};

const onEmail = async (id, customer, type) => {
  overlay.value = true;
  const { status, data } = await axios
    .post(`auth/mail-documents/${id}`, {}, { params: { customer, type } })
    .catch((e) => e.response);
  switch (status) {
    case 200:
      toast.success(data.message);
      break;
    case 406:
      toast.info(data.message);
      break;
    default:
      toast.error(data.message);
  }
  overlay.value = false;
};

const onPDF = async (id, customer) => {
  overlay.value = true;
  const { status, data } = await axios
    .get(`auth/product-document/${id}`, {
      responseType: "blob",
      params: { customer },
    })
    .catch((e) => e.response);
  let link = null;
  switch (status) {
    case 200:
      link = document.createElement("a");
      link.href = URL.createObjectURL(data);
      link.download = `certificado-${new Date().valueOf()}.pdf`;
      link.click();
      toast.success("Documento generado");
      break;
    case 406:
      onBlobToString(data).then((res) => {
        toast.info(res.message);
      });
      break;
    default:
      onBlobToString(data).then((res) => {
        toast.error(res.message);
      });
  }
  overlay.value = false;
};

const onReload = async () => {
  emits("reload", overlay);
};
const onLoad = async () => {
  emits("load", overlay);
};

const info = reactive({
  show: false,
  success: false,
  size: "xs",
  message: "",
  header: false,
  footer: true,
  overlay: true,
  props: {},
});

const onLeasedStateChange = (e, { id }) => {
  console.log(e.key);
  const data = { show: true };
  data.icon = faCircleInfo;
  info.color = "text-blue-500";
  data.success = true;
  data.message = `
  <p>Vas a cambiar el estado de este inventario <b class="text-blue-500">¿Esta seguro?</b></p>
  `;
  data.props = {
    leased_state: e.key,
    id,
  };

  Object.assign(info, data);
};

const onUpdateLeasedState = async ({ leased_state, id }) => {
  if (props.inventory) {
    overlay.value = true;
    await MixinProducts.updateProduct({ leased_state }, id);
    info.show = false;
    overlay.value = false;
  }
};

onMounted(() => {
  onLoad();
});
</script>
