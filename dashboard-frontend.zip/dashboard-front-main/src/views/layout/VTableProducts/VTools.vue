<template>
  <div
    class="flex flex-wrap gap-2 justify-end items-center"
    v-if="!row.deletedAt"
  >
    <VButton
      v-if="row.leased_state == 'retired' && can('update', 'products')"
      title="Restaurar"
      bgColor="bg-transparent"
      textColor="text-cyan-500"
      @click="onRestored(row)"
      :icon="faArrowLeftRotate"
    />
    <template v-else>
      <VButton
        title="Inventario vacio"
        v-if="
          !inventory &&
          can('create', 'products') &&
          ['available'].includes(row.leased_state)
        "
        @click="onEmptyInventary(row.id)"
        bgColor="bg-transparent"
        textColor="text-blue-500"
        :icon="faFileAlt"
      />
      <VButton
        title="Crear inventario"
        v-if="
          !inventory &&
          can('create', 'products') &&
          ['available'].includes(row.leased_state)
        "
        @click="onInventary"
        bgColor="bg-transparent"
        textColor="text-green-500"
        :icon="faFileAlt"
      />
      <span
        v-if="
          inventory &&
          can('read', 'observations') &&
          (!['draft', 'available', 'finished'].includes(row.leased_state) ||
            (row.leased_state == 'finished' && row?.observations?.length))
        "
      >
        <span v-if="row?.observations?.length"
          >({{ row?.observations.length }})</span
        >
        <VButton
          title="Observaciones"
          bgColor="bg-transparent"
          textColor="text-orange-500"
          :icon="faWrench"
          :to="{
            name: 'inventory-obervations',
            params: { id: row.id },
          }"
        />
      </span>
      <VButton
        title="Editar"
        v-if="
          can('update', 'products') &&
          !['leased', 'finished', 'retired'].includes(row.leased_state)
        "
        :to="{
          name: inventory ? 'inventory-edit' : 'product-data-edit',
          params: { id: row.id },
        }"
        bgColor="bg-transparent"
        textColor="text-blue-500"
        :icon="faPen"
      />
    </template>
    <VButton
      :title="
        row.leased_state == 'retired' || inventory ? 'Eliminar' : 'Retirar'
      "
      v-if="
        (can('update', 'products') &&
          ['available', 'draft'].includes(row.leased_state)) ||
        (can('delete', 'products') &&
          row.leased_state == 'retired' &&
          tools &&
          (!inventory || ['draft'].includes(row.leased_state)))
      "
      @click="onArchived(row)"
      bgColor="bg-transparent"
      :textColor="
        row.leased_state == 'retired' ? 'text-red-500' : 'text-rose-500'
      "
      :icon="row.leased_state == 'retired' || inventory ? faTrash : faXmark"
    />
  </div>
</template>

<script setup>
import { defineProps, inject } from "vue";
import {
  faWrench,
  faFileAlt,
  faPen,
  faTrash,
  faXmark,
  faArrowLeftRotate,
} from "@fortawesome/free-solid-svg-icons";

import { useAbility } from "@casl/vue";
const { can } = useAbility();

import { useRouter } from "vue-router";
const router = useRouter();

import { useStore } from "vuex";
const store = useStore();

import * as MixinProductsData from "@/mixins/MixinProductsData";
import * as MixinProducts from "@/mixins/MixinProducts";

import VButton from "@/components/VButton";

const props = defineProps({
  row: {
    type: Object,
    require: true,
  },
  tools: {
    type: Boolean,
    default: true,
  },
  inventory: {
    type: Boolean,
    default: false,
  },
});

const overlay = inject("overlay");
const destroy = inject("destroy");

const onInventary = () => {
  store.commit("SET_STATE", {
    prop: "current",
    modules: "Products",
    data: props.row,
  });
  router.push({ name: "inventory-create" });
};

const onEmptyInventary = (id) => {
  router.push({ name: "settings-form-document", params: { id } });
};

const onRestored = async ({ id, leased_state }) => {
  if ("retired" == leased_state) {
    overlay.value = true;
    (await props.inventory)
      ? MixinProducts.updateProduct({ leased_state: "draft" }, id)
      : MixinProductsData.updateProduct({ leased_state: "available" }, id);
    overlay.value = false;
  }
};

const onArchived = async ({ id, leased_state }) => {
  overlay.value = true;
  switch (leased_state) {
    case "finished":
      if (props.inventory) await MixinProducts.deleteProduct(id);
      break;
    case "available":
      if (!props.inventory)
        await MixinProductsData.updateProduct({ leased_state: "retired" }, id);
      break;
    case "draft":
    case "retired":
      Object.assign(destroy, {
        show: true,
        message:
          "Esta seguro que quiere eliminar este producto permanentemente.",
        type: "retired",
        props: { id, leased_state },
      });
  }

  overlay.value = false;
};
</script>
