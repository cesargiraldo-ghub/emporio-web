<template>
  <div ref="main" class="flex flex-col gap-4">
    <div
      v-if="options"
      class="flex flex-col-reverse md:flex-row gap-5 md:gap-2 pb-4 border-b border-stone-200"
    >
      <div class="flex gap-4 flex-grow font-semibold">
        <figure v-if="options.photo">
          <img class="w-24" :src="options.photo.url" alt="" />
        </figure>
        <div class="flex flex-col gap-1">
          <h1 class="uppercase">
            {{ options.name }}
          </h1>
          <ul class="opacity-70 text-xs mt-auto">
            <li v-if="options.nit">Nit: {{ options.nit }}</li>
            <li v-if="options.address">Direccion: {{ options.address }}</li>
            <li v-if="options.email">Email: {{ options.email }}</li>
            <li v-if="options.cellphone">Cel: {{ options.cellphone }}</li>
          </ul>
        </div>
      </div>
      <div class="flex flex-wrap md:flex-col md:text-right gap-2 font-semibold">
        <div class="uppercase flex flex-col md:block">
          {{ type == "arrendatario" ? "ACTA DE ENTREGA" : "INVENTARIO" }} N°
          <span>{{ code(product.id, product.date_inventory) }}</span>
        </div>
        <ul class="text-xs flex-grow text-right">
          <li v-if="type == 'arrendatario'">
            Fecha de entrega: <br />{{ date(product.date) }}
          </li>
          <li v-else>
            Fecha de inventario: <br />{{ date(product.date_inventory) }}
          </li>
        </ul>
      </div>
    </div>
    <div class="flex flex-col md:flex-row justify-between gap-4">
      <div class="flex flex-col text-left gap-2">
        <h1 class="text-red-500 font-semibold text-lg col-span-2">
          {{ product?.name }}
        </h1>
        <ul class="opacity-70 mt-auto">
          <li v-if="product?.code" class="font-bold">
            Codigo: {{ product.code }}
          </li>
          <li v-if="product?.address">{{ product.address }}</li>
        </ul>
      </div>
      <div
        v-if="product?.user"
        class="flex flex-col md:text-right gap-2 md:justify-end"
      >
        <div class="text-sm font-medium">
          {{ product?.user.fullName }}
        </div>
        <ul class="opacity-70 text-xs">
          <li
            v-if="product?.user?.nit"
            class="flex flex-row-reverse md:flex-row gap-2 items-center justify-end"
          >
            <span>
              {{ product.user?.nit }}
            </span>
            <i class="block w-3 opacity-50">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                <!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                <path
                  d="M0 96l576 0c0-35.3-28.7-64-64-64H64C28.7 32 0 60.7 0 96zm0 32V416c0 35.3 28.7 64 64 64H512c35.3 0 64-28.7 64-64V128H0zM64 405.3c0-29.5 23.9-53.3 53.3-53.3H234.7c29.5 0 53.3 23.9 53.3 53.3c0 5.9-4.8 10.7-10.7 10.7H74.7c-5.9 0-10.7-4.8-10.7-10.7zM176 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zm176 16c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16zm0 64c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16zm0 64c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16z"
                />
              </svg>
            </i>
          </li>
          <li
            v-if="product.user?.cellphone"
            class="flex flex-row-reverse md:flex-row gap-2 items-center justify-end"
          >
            <span>
              {{ product.user?.cellphone }}
            </span>
            <i class="block w-3 opacity-50">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                <path
                  d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"
                />
              </svg>
            </i>
          </li>
          <li
            v-if="product.user?.email"
            class="flex flex-row-reverse md:flex-row gap-2 items-center justify-end"
          >
            <span>
              {{ product.user?.email }}
            </span>
            <i class="block w-3 opacity-50">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                <path
                  d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z"
                />
              </svg>
            </i>
          </li>
        </ul>
      </div>
      <VMessage v-else> No se ha asignado ningun Asesor </VMessage>
    </div>
    <div
      v-if="['arrendatario', true].includes(type)"
      class="flex flex-col md:flex-row items-start border-y border-stone-200"
    >
      <table
        v-if="proprietor"
        class="table-customers text-left w-full md:w-1/2"
      >
        <thead>
          <tr>
            <th class="font-medium text-red-600">Propietario</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="font-medium bg-stone-100">
              {{ proprietor.name }} {{ proprietor.last }}
            </td>
          </tr>
          <tr>
            <td>
              <div class="flex flex-col gap-x-5 gap-y-3 opacity-75">
                <span
                  v-if="proprietor?.nit"
                  class="flex gap-2 items-center"
                >
                  <i class="block w-3 opacity-50">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 576 512"
                    >
                      <path
                        d="M0 96l576 0c0-35.3-28.7-64-64-64H64C28.7 32 0 60.7 0 96zm0 32V416c0 35.3 28.7 64 64 64H512c35.3 0 64-28.7 64-64V128H0zM64 405.3c0-29.5 23.9-53.3 53.3-53.3H234.7c29.5 0 53.3 23.9 53.3 53.3c0 5.9-4.8 10.7-10.7 10.7H74.7c-5.9 0-10.7-4.8-10.7-10.7zM176 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zm176 16c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16zm0 64c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16zm0 64c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16z"
                      />
                    </svg>
                  </i>
                  <span>
                    {{ proprietor?.nit }}
                  </span>
                </span>
                <span
                  v-if="proprietor?.email"
                  class="flex gap-2 items-center break-all"
                >
                  <i class="block w-3 opacity-50">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 512 512"
                    >
                      <path
                        d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"
                      />
                    </svg>
                  </i>
                  <span class="w-1 flex-grow">
                    {{ proprietor?.email }}
                  </span>
                </span>
                <span
                  v-if="proprietor?.cellphone"
                  class="flex gap-2 items-center"
                >
                  <i class="block w-3 opacity-50">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 512 512"
                    >
                      <path
                        d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z"
                      />
                    </svg>
                  </i>
                  <span>
                    {{ proprietor?.cellphone }}
                  </span>
                </span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <VMessage class="self-stretch w-full md:w-1 flex-grow my-4 mr-2" v-else>
        No se ha asignado ningun Propietario
      </VMessage>
      <table
        v-if="leaseholder"
        class="table-customers text-left w-full md:w-1/2"
      >
        <thead>
          <tr>
            <th class="font-medium text-red-600">Arrendatario</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="font-medium bg-stone-100">
              {{ leaseholder.name }} {{ leaseholder.last }}
            </td>
          </tr>
          <tr>
            <td>
              <div class="flex flex-col gap-x-4 gap-y-2 opacity-75">
                <span
                  v-if="leaseholder?.nit"
                  class="flex gap-2 items-center"
                >
                  <i class="block w-3 opacity-50">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 576 512"
                    >
                      <path
                        d="M0 96l576 0c0-35.3-28.7-64-64-64H64C28.7 32 0 60.7 0 96zm0 32V416c0 35.3 28.7 64 64 64H512c35.3 0 64-28.7 64-64V128H0zM64 405.3c0-29.5 23.9-53.3 53.3-53.3H234.7c29.5 0 53.3 23.9 53.3 53.3c0 5.9-4.8 10.7-10.7 10.7H74.7c-5.9 0-10.7-4.8-10.7-10.7zM176 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zm176 16c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16zm0 64c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16zm0 64c0-8.8 7.2-16 16-16H496c8.8 0 16 7.2 16 16s-7.2 16-16 16H368c-8.8 0-16-7.2-16-16z"
                      />
                    </svg>
                  </i>
                  <span>
                    {{ leaseholder?.nit }}
                  </span>
                </span>
                <span
                  v-if="leaseholder?.email"
                  class="flex gap-2 items-center break-all"
                >
                  <i class="block w-3 opacity-50">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 512 512"
                    >
                      <path
                        d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"
                      />
                    </svg>
                  </i>
                  <span class="w-1 flex-grow">
                    {{ leaseholder?.email }}
                  </span>
                </span>
                <span
                  v-if="leaseholder?.cellphone"
                  class="flex gap-2 items-center"
                >
                  <i class="block w-3 opacity-50">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 512 512"
                    >
                      <path
                        d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z"
                      />
                    </svg>
                  </i>
                  <span>
                    {{ leaseholder?.cellphone }}
                  </span>
                </span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <VMessage class="self-stretch w-full md:w-1 flex-grow my-4 ml-2" v-else>
        No se ha asignado ningun Arrendatario
      </VMessage>
    </div>
    <hr v-else class="border-t border-stone-200" />
    <template v-if="product.attrs && product.attrs.length">
      <div class="flex flex-col gap-10 relative">
        <swiper-container init="false" class="w-full slide-content">
          <template
            v-for="(attribute, index) in product.attrs"
            :key="`attribute-${attribute.id}-${index}`"
          >
            <swiper-slide>
              <VFilesUpload
                class="mb-5"
                :columns="5"
                :modelValue="attribute.images"
                :image="(img) => onFilterURL(img)"
                :fullImage="(img) => onFilterURL(img, '', img.format)"
                :tools="false"
              />
              <div class="relative">
                <div class="flex flex-col gap-3">
                  <h2 class="text-center">
                    <span class="text-red-700 font-bold text-base">{{
                      attribute.name
                    }}</span>
                  </h2>
                  <div class="flex flex-col gap-6">
                    <template
                      v-for="(section, s) in attribute.sections"
                      :key="`section-${attribute.id}-${index}-${section.id}-${s}`"
                    >
                      <div
                        class="flex flex-col border border-l-0 border-b-0 border-stone-200"
                      >
                        <h3
                          class="relative z-10 px-3 py-2 font-bold text-sm border-l border-b border-stone-200"
                        >
                          {{ section.name }}
                        </h3>
                        <div class="flex flex-col">
                          <template
                            v-for="(attr, a) in section.attrs"
                            :key="`attr-${attribute.id}-${index}-${section.id}-${s}-${attr.id}-${a}`"
                          >
                            <div class="flex flex-col">
                              <h4
                                class="text-red-500 bg-stone-100 border-l border-b border-stone-200 py-2 px-3 text-left font-bold"
                              >
                                {{ attr.name }}
                              </h4>
                              <div class="flex flex-col flex-wrap md:flex-row">
                                <template
                                  v-for="(field, f) in attr.fields"
                                  :key="`field-${attribute.id}-${index}-${section.id}-${s}-${attr.id}-${a}-${field.id}-${f}`"
                                >
                                  <div
                                    v-if="field.value"
                                    class="relative z-10 flex justify-between border-l border-b border-stone-200"
                                    :class="
                                      field.type == 'long'
                                        ? 'w-full flex-col leading-relaxed'
                                        : 'w-full md:w-1/3 flex-grow gap-4'
                                    "
                                  >
                                    <span
                                      class="pt-2 px-3"
                                      :class="
                                        field.type == 'long'
                                          ? 'font-bold'
                                          : 'pb-2'
                                      "
                                    >
                                      {{ field.name }}
                                    </span>
                                    <span
                                      class="py-2 px-3 text-black"
                                      :class="
                                        field.type == 'long'
                                          ? 'text-justify'
                                          : 'text-right font-bold'
                                      "
                                    >
                                      {{
                                        field.type == "multi" && Array.isArray(field.value)
                                          ? field.value.join(", ")
                                          : field.value
                                      }}
                                    </span>
                                  </div>
                                </template>
                              </div>
                            </div>
                          </template>
                        </div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </swiper-slide>
          </template>
        </swiper-container>
      </div>
      <div class="sticky z-10 bottom-0 p-2 backdrop-blur -mx-1">
        <swiper-container init="false" class="w-full slide-tabs">
          <template
            v-for="(attr, index) in product.attrs"
            :key="`attr-${index}`"
          >
            <swiper-slide class="group w-fit">
              <div class="p-2 inline-block">
                <span
                  class="group-[.swiper-slide-thumb-active]:border-b-2 group-[.swiper-slide-thumb-active]:text-red-500 group-[.swiper-slide-thumb-active]:bg-white text-center gap-2 py-2 px-4 bg-red-500 text-white rounded shadow cursor-pointer border-current"
                >
                  {{ attr.name }}
                </span>
              </div>
            </swiper-slide>
          </template>
        </swiper-container>
      </div>
    </template>
    <VMessage class="h-40" v-else>
      No hay ninguna caracteristica asignada
    </VMessage>
    <div
      v-if="
        product.user_observation ||
        product.proprietor_observation ||
        product.leaseholder_data_observation
      "
      class="flex flex-col border border-l-0 border-b-0 border-stone-200"
    >
      <h4
        class="text-red-500 bg-stone-100 border-l border-b border-stone-200 py-2 px-3 text-left font-bold"
      >
        Observaciones
      </h4>
      <div
        v-if="product.user_observation"
        class="leading-relaxed relative z-10 flex flex-col border-l border-b border-stone-200 w-full"
      >
        <span class="pt-2 px-3 font-bold"> Observaciones del Asesor </span>
        <span class="py-2 px-3 text-black text-justify">
          {{ product.user_observation }}
        </span>
      </div>
      <div
        v-if="product.proprietor_observation"
        class="leading-relaxed relative z-10 flex flex-col border-l border-b border-stone-200 w-full"
      >
        <span class="pt-2 px-3 font-bold"> Observaciones del Propietario </span>
        <span class="py-2 px-3 text-black text-justify">
          {{ product.proprietor_observation }}
        </span>
      </div>
      <div
        v-if="product.leaseholder_observation"
        class="leading-relaxed relative z-10 flex flex-col border-l border-b border-stone-200 w-full"
      >
        <span class="pt-2 px-3 font-bold">
          Observaciones del Arrendatario
        </span>
        <span class="py-2 px-3 text-black text-justify">
          {{ product.leaseholder_observation }}
        </span>
      </div>
    </div>
    <slot></slot>
  </div>
</template>
<script setup>
import { defineProps, ref, onMounted, computed } from "vue";
import { date, code, onFilterURL } from "@/assets/js/filters";
import { Thumbs, FreeMode } from "swiper/modules";
import "swiper/element/css/free-mode";
import "swiper/element/css/thumbs";

import VMessage from "@/components/VMessage";
import VFilesUpload from "@/components/VFilesUpload";

const props = defineProps({
  product: {
    type: Object,
    required: true,
  },
  options: {
    type: Object,
  },
  type: {
    default: true,
  },
});

const proprietor = computed(() => Object.keys(props.product.proprietor_data).length ? props.product.proprietor_data : props.product.proprietor)
const leaseholder = computed(() => Object.keys(props.product.leaseholder_data).length ? props.product.leaseholder_data : props.product.leaseholder)

const main = ref(null);

onMounted(() => {
  const tabs = main.value?.querySelector(".slide-tabs");
  if(tabs){
    const tabsParams = {
      modules: [FreeMode],
      slidesPerView: "auto",
      centerInsufficientSlides: true,
      freeMode: {
        enabled: true,
      },
    };
    Object.assign(tabs, tabsParams);
    tabs.initialize();
  }

  const content = main.value.querySelector(".slide-content");
  if(content){
    const contentParams = {
      modules: [Thumbs],
      autoHeight: true,
      thumbs: {
        swiper: tabs.swiper,
      },
    };
    Object.assign(content, contentParams);
    content.initialize();
  }
});
</script>
<style lang="scss">
.table-customers {
  tr > * {
    @apply py-2.5 px-4;
  }
  tbody tr {
    @apply odd:bg-white;
  }
}
.flicking-viewport {
  transition: height 500ms;
}
</style>
