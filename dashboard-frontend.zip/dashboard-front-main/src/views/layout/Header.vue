<template>
	<header>
		<nav class="menu-container">
			<ul class="menu-nav">
				<template v-for="item in navs">
					<li class="menu-nav-item" v-if="item.meta.nav" :key="`item_menu_${_uid}_${item.name}`">
						<router-link :to="{...item}">
							{{item.meta.title}}
						</router-link>
					</li>
				</template>
			</ul>
			<slot name="signout">
				
			</slot>
		</nav>
	</header>
</template>
<script>
export default {
	name: 'VHeader',
	props: {
		navs: {
			type: Array,
			default: () => ([])
		}
	}
}
</script>
<style lang="scss">
	.menu {
		&-container{
			@apply flex flex-wrap justify-between items-center;
		}
		&-nav{
			@apply flex flex-wrap;
			&-item {
				a{
					@apply block py-3 px-6 cursor-pointer;
					transition: all ease 0.4s;
					&:hover{
						@apply text-red-500 underline;
					}
				}
			}
		}
	}
</style>