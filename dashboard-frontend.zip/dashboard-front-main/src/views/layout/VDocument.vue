<template>
	<div class="rich-text" v-html="options?.terms"></div>
	<div class="flex flex-col mt-6">
		<slot></slot>
	</div>
</template>
<script setup>
	import {defineProps} from "vue"
	defineProps({
		options: {
			type: Object,
			required: true
		},
	});

</script>
<style lang="scss">
	.rich-text {
		@apply leading-relaxed;
		a {
			@apply text-red-500;
		}
		b, strong {
			@apply font-bold;
		}
		ul, ol {
			@apply pl-5 flex flex-col gap-2 marker:text-red-500;
		}
		ul {
			@apply list-disc;
		}
		ol {
			@apply list-decimal;
		}
		& > * + * {
			@apply mt-5;
		}
	}
</style>