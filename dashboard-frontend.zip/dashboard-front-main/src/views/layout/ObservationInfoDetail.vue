<template>
  <div class="flex flex-col gap-4">
    <div class="flex flex-wrap justify-between">
      <h2 class="text-base md:text-xl font-semibold flex flex-col md:flex-row gap-1 md:gap-2">
        {{ row.title }}
        <span class="text-red-500 text-sm md:text-lg font-semibold leading-tight">{{
          row.code || row.id
        }}</span>
      </h2>
      <div class="flex ml-auto gap-4 text-xs md:text-base">
        <VBadge v-bind="onLeasedState(row.leased_state)" />
      </div>
    </div>
    <div class="flex flex-col gap-4 p-4 rounded-lg bg-red-50">
      <div class="text-base font-bold text-red-500 flex gap-3 items-center">
        <VButton
          class="!rounded-full border border-current"
          bgColor="bg-red-500"
          textColor="text-white"
          size="sm"
          :icon="faClose"
        />
        <span>{{ date(row.date_problem) }}</span>
      </div>
      <div>
        {{ row.problem }}
      </div>
    </div>
    <template v-if="!simple">
      <VFilesUpload
        :columns="5"
        :modelValue="row['images_problem']"
        :tools="false"
        :image="(img) => onFilterURL(img)"
        :fullImage="(img) => onFilterURL(img, '', img.format)"
      />
      <template v-if="row.status == 'canceled' && row.canceled">
        <hr class="border-t border-gray-200 my-3" />
        <div class="flex flex-col gap-4 leading-relaxed">
          <h2 class="text-lg font-semibold">Motivo de cancelación</h2>
          <p>{{ row.canceled }}</p>
        </div>
      </template>
  
      <template v-else>
        <template v-if="row.observation_solved">
          <hr class="border-t border-gray-200 my-3" />
          <div class="flex flex-col gap-4 leading-relaxed">
            <h2 class="text-lg font-semibold">Observaciones de solución</h2>
            <p>{{ row.observation_solved }}</p>
          </div>
          <hr class="border-t border-gray-200 my-3" />
        </template>
        <template v-else>
          <hr class="border-t border-gray-200 my-3" />
          <div class="flex justify-between gap-4 items-center">
            <div class="font-semibold text-base">Fecha de inicio de la obra</div>
            <div
              class="text-base font-bold text-blue-500 flex gap-1 items-center"
            >
              <VButton
                bgColor="bg-transparent"
                textColor="text-blue-500"
                size="lg"
                :icon="faCalendarAlt"
              />
              <span>{{ date(row.dateWork) }}</span>
            </div>
          </div>
          <hr class="border-t border-gray-200 my-3" />
          <template v-if="row.observations?.length">
            <h2 class="text-lg font-semibold">Observaciones del proveedor</h2>
            <template
              v-for="(item, index) in row.observations"
              :key="`observations-${index}-${item.id}`"
            >
              <div class="flex flex-col gap-4 p-4 rounded-lg bg-blue-50">
                <div
                  class="text-base font-bold text-blue-500 flex gap-3 items-center"
                >
                  <VButton
                    class="!rounded-full border border-current"
                    bgColor="bg-blue-500"
                    textColor="text-white"
                    size="sm"
                    :icon="faExclamation"
                  />
                  <span>{{ date(row.date) }}</span>
                </div>
                <div>
                  {{ row.observation }}
                </div>
              </div>
            </template>
            <hr class="border-t border-gray-200 my-3" />
          </template>
        </template>
        <div class="flex flex-col gap-4 rounded-lg p-4 bg-green-50">
          <div class="text-base font-bold text-green-500 flex gap-3 items-center">
            <VButton
              class="!rounded-full border border-current"
              bgColor="bg-green-500"
              textColor="text-white"
              size="sm"
              :icon="faCheck"
            />
            <span>{{ date(row.date_solution) }}</span>
          </div>
          <div>
            {{ row.solution }}
          </div>
        </div>
        <VFilesUpload
          :columns="5"
          :modelValue="row['images_solution']"
          :image="(img) => onFilterURL(img)"
          :tools="false"
          :fullImage="(img) => onFilterURL(img, '', img.format)"
        />
        <hr class="border-t border-gray-200 my-3" />
        <div class="flex gap-4 justify-between text-base">
          Responsable de pago:
          <VBadge
            v-if="row.responsible"
            v-bind="onResponsible(row.responsible)"
          />
          <span v-else>----</span>
        </div>
      </template>
    </template>
  </div>
</template>

<script setup>
import { defineProps } from "vue";
import {
  faClose,
  faCheck,
  faExclamation,
  faCalendarAlt,
} from "@fortawesome/free-solid-svg-icons";

import VBadge from "@/components/VBadge";
import VButton from "@/components/VButton";
import VFilesUpload from "@/components/VFilesUpload";
import { date, onResponsible, onLeasedState, onFilterURL } from "@/assets/js/filters";

defineProps({
  row: {
    type: Object,
    required: true,
  },
  simple: {
    type: Boolean,
    default: false,
  },
});
</script>
