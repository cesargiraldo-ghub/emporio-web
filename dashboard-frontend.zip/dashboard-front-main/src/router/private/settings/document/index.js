export default {
  path: "documento/:id",
  name: "settings-form-document",
  meta: {
    subject: "products",
    action: "read",
  },
  component: () => import("@/page/private/Settings/VDocuments"),
};
