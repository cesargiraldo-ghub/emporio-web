<template>
  <div
    class="min-h-screen flex flex-col items-center justify-center text-center gap-10"
  >
    <fa-icon
      class="text-red-500 text-8xl md:text-[180px] leading-none font-bold"
      :icon="faCircleXmark"
    ></fa-icon>
    <p class="text-base md:text-2xl md:max-w-md leading-loose">
      Lo sentimos pero no tienes permiso para ver este contenido
    </p>
    <router-link
      :to="{ name: 'signin' }"
      class="text-xl hover:underline text-red-500"
    >
      Ir al inicio
    </router-link>
  </div>
</template>

<script>
export default {
  name: "NotAuthorized",
};
</script>
<script setup>
import { faCircleXmark } from "@fortawesome/free-solid-svg-icons";
</script>

<style lang="css" scoped></style>
