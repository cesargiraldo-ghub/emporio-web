<template>
  <div class="min-h-screen grid grid-cols-1 lg:grid-cols-2">
    <div class="relative overflow-hidden">
      <img
        class="grayscale absolute w-full h-full object-center object-cover"
        src="../../../public/bg.jpg"
        alt=""
      />
      <figure
        v-if="bussiness?.photo?.url"
        class="flex h-full w-full bg-white/40 p-3 relative z-10"
      >
        <img
          class="m-auto max-w-[220px] block w-full h-auto"
          :src="bussiness?.photo?.url"
          alt=""
        />
      </figure>
    </div>
    <div
      class="relative flex flex-col bg-gray-100 p-10 shadow-[inset_10px_0_10px_-10px_#00000026]"
    >
      <div class="max-w-sm w-full m-auto p-10 flex flex-col gap-5">
        <VLoader position="absolute" :show="overlay"></VLoader>
        <VForm v-bind="form" @submit="onSubmit">
          <template #default="{ fields }">
            <VInput
              v-model="fields.email.value"
              name="email"
              v-bind="fields.email"
            />
            <VInput
              v-model="fields.keyword.value"
              name="keyword"
              v-bind="fields.keyword"
            >
              <template #after>
                <VButton
                  class="absolute right-0 top-1/2 -translate-y-1/2"
                  @click="
                    fields.keyword.attr.type =
                      fields.keyword.attr.type == 'text' ? 'password' : 'text'
                  "
                  size="lg"
                  :icon="
                    fields.keyword.attr.type == 'text' ? faEyeSlash : faEye
                  "
                  bgColor="bg-transparent"
                  textColor="text-gray-500"
                />
              </template>
            </VInput>
          </template>
        </VForm>
        <div class="text-center text-sm">
          <router-link
            :to="{ name: 'reset-password' }"
            class="text-red-500 underline"
          >
            Recuperar contraseña
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref, reactive, defineAsyncComponent } from "vue";
import axios from "@/assets/js/axios";
import Jwt from "@/assets/js/jwt";
import router from "@/router";
import { bussiness } from "@/mixins/MixinSettings";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import VButton from "@/components/VButton.vue";

import { useToast } from "vue-toastification";
const toast = useToast();

/*Start Components*/
const VForm = defineAsyncComponent(() => import("@/components/VForm/VForm"));
const VInput = defineAsyncComponent(() => import("@/components/VForm/VInput"));
const VLoader = defineAsyncComponent(() => import("@/components/VLoader"));
/*End Components*/

/*Start States*/
const overlay = ref(false);
const form = reactive({
  textSubmit: "Iniciar Sesión",
  center: true,
  fields: {
    email: {
      label: "E-mail",
      notInherit: true,
      attr: {
        type: "email",
        rules: "required|email",
      },
      value: null,
    },
    keyword: {
      label: "Contraseña",
      notInherit: true,
      attr: {
        type: "password",
        rules: "required",
      },
      value: null,
    },
  },
});
/*End States*/

/*Start Methods*/
const onSubmit = async ({ values: data }) => {
  overlay.value = true;
  const { status, data: res } = await axios({
    method: "post",
    url: "public/signin",
    data,
  })
    .then()
    .catch((e) => e.response);
  overlay.value = false;
  switch (status) {
    case 200:
      Jwt.setSignin({ tokens: res.tokens });
      router.push({ name: "application" });
      toast.success(res.message);
      break;
    default:
      toast.error(res.message);
  }
};
/*End Methods*/
</script>
