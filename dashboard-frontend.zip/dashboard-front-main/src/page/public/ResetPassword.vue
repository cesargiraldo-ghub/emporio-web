<template>
  <div class="min-h-screen grid grid-cols-1 lg:grid-cols-2">
    <div class="relative overflow-hidden">
      <img
        class="grayscale absolute w-full h-full object-center object-cover"
        src="../../../public/bg.jpg"
        alt=""
      />
      <figure
        v-if="bussiness?.photo?.url"
        class="flex h-full w-full bg-white/40 p-3 relative z-10"
      >
        <img
          class="m-auto max-w-[220px] block w-full h-auto"
          :src="bussiness?.photo?.url"
          alt=""
        />
      </figure>
    </div>
    <div
      class="relative flex flex-col bg-gray-100 p-10 shadow-[inset_10px_0_10px_-10px_#00000026]"
    >
      <VLoader position="absolute" :show="overlay"></VLoader>
      <div class="max-w-sm w-full m-auto p-10 flex flex-col gap-5">
        <h1 class="text-xl font-medium">
          {{ $route.meta.title }}
        </h1>

        <transition name="fade" mode="out-in">
          <template v-if="!send">
            <div class="flex flex-col gap-5">
              <p>Ingresa tu correo para recuperar tu contraseña</p>
              <VForm v-bind="form" @submit="onSubmit" />
            </div>
          </template>
          <template v-else>
            <p class="text-base">
              Hemos enviado un correo de confirmacion a tu correo electrónico para que puedas
              recuperar tu contraseña.
            </p>
          </template>
        </transition>

        <div class="text-sm">
          <router-link :to="{ name: 'signin' }" class="text-red-500 underline">
            Iniciar sesión
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import VForm from "@/components/VForm/VForm";
import { defineAsyncComponent, ref, reactive } from "vue";
import { bussiness } from "@/mixins/MixinSettings";
const VLoader = defineAsyncComponent(() => import("@/components/VLoader"));
import axios from "@/assets/js/axios";

import { useToast } from "vue-toastification";
const toast = useToast();

const overlay = ref(false);
const send = ref(false);
const form = reactive({
  textSubmit: "Recuperar contraseña",
  fields: {
    email: {
      label: "E-mail",
      attr: {
        type: "email",
        rules: "required|email",
      },
    },
  },
});

const onSubmit = async ({ values: data }) => {
  overlay.value = true;

  const { status, ...res } = await axios({
    method: "post",
    url: "public/reset-password",
    data,
  })
    .then()
    .catch((e) => e.response);

  overlay.value = false;

  switch (status) {
    case 200:
      toast.success(res.data.message);
      send.value = true;
      break;
    default:
      toast.error(res.data.message);
  }
};
</script>
<style lang="css" scoped></style>
