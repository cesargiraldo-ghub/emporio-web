<template>
  <div class="min-h-screen grid grid-cols-1 lg:grid-cols-2">
    <div class="relative overflow-hidden">
      <img
        class="grayscale absolute w-full h-full object-center object-cover"
        src="../../../public/bg.jpg"
        alt=""
      />
      <figure
        v-if="bussiness?.photo?.url"
        class="flex h-full w-full bg-white/40 p-3 relative z-10"
      >
        <img
          class="m-auto max-w-[220px] block w-full h-auto"
          :src="bussiness?.photo?.url"
          alt=""
        />
      </figure>
    </div>
    <div
      class="relative flex flex-col bg-gray-100 p-10 shadow-[inset_10px_0_10px_-10px_#00000026]"
    >
      <VLoader position="absolute" :show="overlay"></VLoader>
      <transition name="fade" mode="out-in">
        <div
          v-if="show"
          class="max-w-sm w-full m-auto p-10 flex flex-col gap-5"
        >
          <h1 class="text-xl font-medium">
            {{ validate ? $route.meta.title : "Link Caducate" }}
          </h1>

          <transition name="fade" mode="out-in">
            <template v-if="validate">
              <div class="flex flex-col gap-5">
                <p class="text-base">Ingresa una nueva contraseña</p>
                <VForm v-bind="form" @submit="onSubmit">
                  <template #default="{ onSubmit }">
                    <div class="col-span-10 flex flex-col gap-5 items-start">
                      <VCheckItem
                        name="Mostrar contraseña"
                        @change="check = !check"
                        :checked="check"
                      />
                      <VButton @click="onSubmit" text="Restablecer contraseña" />
                    </div>
                  </template>
                </VForm>
              </div>
            </template>
            <template v-else>
              <div class="flex flex-col gap-5">
                <p class="text-base">Lo sentimos este enlace a caducado</p>
                <router-link
                  :to="{ name: 'signin' }"
                  class="text-red-500 underline"
                >
                  Ir al inicio
                </router-link>
              </div>
            </template>
          </transition>
        </div>
      </transition>
    </div>
  </div>
</template>
<script setup>
import { defineAsyncComponent, ref, reactive, onMounted, watch } from "vue";
import VForm from "@/components/VForm/VForm";
import VCheckItem from "@/components/VForm/VCheck/VCheckItem.vue";
import VButton from "@/components/VButton.vue";

import { bussiness } from "@/mixins/MixinSettings";
const VLoader = defineAsyncComponent(() => import("@/components/VLoader"));
import { useRoute, useRouter } from "vue-router";
import axios from "@/assets/js/axios";

import { useToast } from "vue-toastification";
const toast = useToast();

const route = useRoute();
const router = useRouter();

const overlay = ref(true);
const show = ref(false);
const validate = ref(null);
const check = ref(false)
const form = reactive({
  textSubmit: "Restablecer contraseña",
  showSubmit: false,
  fields: {
    keyword: {
      label: "Nueva contraseña",
      value: null,
      attr: {
        type: "password",
        rules: "required",
      },
    },
    confirmedkeyword: {
      label: "Confirmar contraseña",
      value: null,
      attr: {
        type: "password",
        rules: "required|confirmed:@keyword",
      },
    },
  },
});

watch(() => check.value, (v) => {
  form.fields.keyword.attr.type = v ? 'text' : 'password'
  form.fields.confirmedkeyword.attr.type = v ? 'text' : 'password'
});

const validateToken = async () => {
  const { id, token } = route.params;
  overlay.value = true;
  const { status } = await axios({
    method: "get",
    url: `public/reset-password/${id}/${token}`,
  })
    .then()
    .catch((e) => e.response);

  overlay.value = false;

  switch (status) {
    case 200:
      validate.value = true;
      break;
    default:
      validate.value = false;
  }
  show.value = true;
};
const onSubmit = async ({ values: data }) => {
  const { id, token } = route.params;
  overlay.value = true;
  const { status, ...res } = await axios({
    method: "patch",
    url: `public/reset-password/${id}/${token}`,
    data,
  })
    .then()
    .catch((e) => e.response);

  overlay.value = false;

  switch (status) {
    case 200:
      toast.success(res.data.message);
      router.push({ name: "signin" });
      break;
    default:
      toast.error("Ocurrio un error inesperado intentalo mas tarde");
  }
};

onMounted(() => {
  validateToken();
});
</script>
<style lang="css" scoped></style>
