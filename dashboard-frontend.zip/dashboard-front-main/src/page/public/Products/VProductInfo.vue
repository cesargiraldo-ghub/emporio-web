<template>
  <div class="max-w-3xl mx-auto p-4">
    <VLoader :show="overlay" position="fixed" />
    <template v-if="product">
      <ProductInfoDetail :type="false" :options="options" :product="product" />
      <template v-if="observations?.length">
        <div class="flex flex-col gap-5 mt-5">
          <h2 class="text-red-500 font-semibold text-lg col-span-2">
            Observaciones
          </h2>
          <ObservationInfoDetail
            v-for="(item, index) in observations"
            :key="`obs-${index}-${item.id}`"
            :row="item"
            :simple="true"
          ></ObservationInfoDetail>
        </div>
      </template>
      <template
        v-if="
          customer == 'arrendatario' &&
          !product.signature &&
          product.leased_state == 'draft'
        "
      >
        <div class="my-5 text-center">
          <VButton
            @click="onDocument"
            text="Leer terminos y condiciones"
            bgColor="bg-red-500"
          />
        </div>
      </template>
      <div
        v-if="
          customer == 'propietario' &&
          !product.signature_proprietor &&
          product.leased_state == 'draft'
        "
        class="flex flex-col gap-4"
      >
        <h3 class="text-base font-semibold uppercase text-center mt-10">
          Firma del propietario
        </h3>
        <VSignature
          align="center"
          @change="onChangeSignature('signature_proprietor', $event)"
        ></VSignature>
        <VButton
          class="mx-auto"
          :disabled="overlay || !pad.signature_proprietor"
          @click="onUpdateState"
          text="Acepto"
          bgColor="bg-red-500"
        />
      </div>
    </template>
    <VModal v-bind="modal" v-model="modal.show">
      <VLoader :show="overlay">
        <template v-if="message">
          <div
            :class="styleMessage"
            class="p-5 -m-5 relative font-semibold text-center text-lg"
          >
            <span
              class="block absolute inset-0 z-0 bg-current opacity-10"
            ></span>
            <span>{{ message }}</span>
          </div>
        </template>
        <template v-else>
          <VForm
            v-if="!product"
            v-bind="formFields"
            ref="form"
            @submit="onSubmitState"
          ></VForm>
          <VDocument v-else-if="customer == 'arrendatario'" :options="options">
            <h3 class="text-base font-semibold uppercase text-center mb-5">
              Firma del arrendatario
            </h3>
            <VSignature
              align="center"
              @change="onChangeSignature('signature', $event)"
            ></VSignature>
            <VCheckItem
              class="mx-auto"
              name="He leido y acepto los terminos y condiciones del contrato"
              @change="onChecked('tyc', $event)"
              :checked="doc.tyc"
            />
            <VCheckItem
              class="mx-auto mt-3"
              @change="onChecked('policy', $event)"
              :checked="doc.policy"
            >
              Acepto
              <components v-bind="tycTag"
                >Política de tratamientos de datos perosnales</components
              >
            </VCheckItem>
          </VDocument>
        </template>
      </VLoader>
      <template #footer>
        <div class="flex gap-3">
          <template v-if="!product">
            <VButton
              :disabled="overlay"
              text="Ingresar"
              bgColor="bg-green-500"
              @click="form.onSubmit()"
            />
          </template>
          <template v-else>
            <VButton
              class="ml-auto"
              :disabled="overlay || !doc.tyc || !doc.policy || !pad.signature"
              @click="onUpdateState"
              text="Acepto"
              bgColor="bg-red-500"
            />
            <VButton
              class="mr-auto"
              :disabled="overlay"
              @click="modal.show = false"
              text="Cancelar"
              bgColor="bg-gray-300"
              textColor="text-gray-600"
            />
          </template>
        </div>
      </template>
    </VModal>
  </div>
</template>
<script setup>
import { onMounted, ref, reactive, computed } from "vue";
import $axios from "@/assets/js/axios";

import VForm from "@/components/VForm/VForm";
import VLoader from "@/components/VLoader";
import VButton from "@/components/VButton";
import VModal from "@/components/VModal";
import ProductInfoDetail from "@/views/layout/ProductInfoDetail";
import VDocument from "@/views/layout/VDocument";
import VCheckItem from "@/components/VForm/VCheck/VCheckItem";
import VSignature from "@/components/VSignature";
import { onFilterURL } from "@/assets/js/filters";
import ObservationInfoDetail from "@/views/layout/ObservationInfoDetail.vue";

import { useToast } from "vue-toastification";
const toast = useToast();

import { useRoute, useRouter } from "vue-router";
const router = useRouter();
const route = useRoute();

const { id, customer } = route.params;
const overlay = ref(false);
const product = ref(null);
const options = ref(null);
const message = ref(null);
const password = ref(null);
const pad = reactive({
  signature: null,
  signature_proprietor: null,
});
const statusState = ref(false);

const styleMessage = computed(() => {
  switch (statusState.value) {
    case 210:
      return "text-blue-500";
    case 211:
      return "text-orange-500";
    case 403:
      return "text-amber-500";
    default:
      return "";
  }
});

const observations = computed(() => {
  return product.value.observations.filter((item) => {
    return item.leased_state == "delivery" && customer == "arrendatario";
  });
});

const modal = reactive({
  show: false,
  hideClose: true,
  title: "Ingresar clave",
  size: "xs",
});

const form = ref(null);
const formFields = reactive({
  showSubmit: false,
  fields: {
    keyword: {
      attr: {
        type: "password",
        rules: "required",
      },
    },
  },
});

const doc = reactive({
  tyc: false,
  policy: false,
});
const onChecked = (key, { target: { checked } }) => {
  doc[key] = checked;
};

const onChangeSignature = (prop, value) => {
  pad[prop] = value;
};

const onSubmitState = async ({ values }) => {
  overlay.value = true;
  const { keyword } = values;
  const { status, data } = await $axios({
    method: "post",
    url: `public/product-state/${id}`,
    data: { keyword },
    params: { customer },
  }).catch((e) => e.response);
  switch (status) {
    case 200:
      modal.show = false;
      product.value = data.row;
      options.value = data.options;
      password.value = keyword;
      break;
    default:
      Object.assign(modal, {
        show: true,
        hideClose: true,
        header: false,
        footer: false,
        size: "xs",
      });
      message.value = data.message;
  }
  overlay.value = false;
};

const onDocument = () => {
  Object.assign(modal, {
    show: true,
    hideClose: true,
    title: "Terminso y Condiciones",
    size: "md",
  });
};

const onUpdateState = async () => {
  overlay.value = true;
  const keyword = password.value;
  const signature = pad.signature || pad.signature_proprietor;
  const { status, data } = await $axios({
    method: "patch",
    url: `public/product-state-lease/${id}`,
    data: { keyword, signature, tyc: doc.tyc, policy: doc.policy },
    params: { customer },
  }).catch((e) => e.response);
  statusState.value = status;
  switch (status) {
    case 210:
    case 211:
      Object.assign(modal, {
        show: true,
        hideClose: true,
        header: false,
        footer: false,
        size: "xs",
      });
      product.value = null;
      options.value = null;
      password.value = null;
      message.value = data.message;
      break;
    default:
      toast.error(data.message);
  }
  overlay.value = false;
};

const tycTag = computed(() => {
  if (options.value && options.value.policy) {
    return {
      is: "a",
      href: onFilterURL(options.value.policy[0], "", "pdf"),
      target: "_blank",
      class: "text-red-500 underline",
    };
  } else {
    return {
      is: "span",
    };
  }
});

onMounted(async () => {
  if (["arrendatario", "propietario"].includes(customer)) {
    const { status, data } = await $axios({
      method: "get",
      url: `public/product-state/${id}`,
      params: { customer },
    }).catch((e) => e.response);
    statusState.value = status;
    switch (status) {
      case 200:
        if (data.auth) {
          onSubmitState({ values: { keyword: null } });
        } else {
          modal.show = true;
        }
        break;
      case 210:
      case 211:
      case 403:
        message.value = data.message;
        Object.assign(modal, {
          show: true,
          hideClose: true,
          header: false,
          footer: false,
        });
        break;
      case 404:
        router.push({ name: "not-found" });
        break;
    }
  } else {
    router.push({ name: "not-found" });
  }
});
</script>
<style lang="scss">
.rich-text {
  @apply leading-relaxed;

  a {
    @apply text-red-500;
  }

  b,
  strong {
    @apply font-bold;
  }

  ul,
  ol {
    @apply pl-5 flex flex-col gap-2 marker:text-red-500;
  }

  ul {
    @apply list-disc;
  }

  ol {
    @apply list-decimal;
  }

  & > * + * {
    @apply mt-5;
  }
}
</style>
