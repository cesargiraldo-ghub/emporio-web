<template>
  <div class="max-w-3xl mx-auto p-4">
    <template v-if="row">
      <VLoader :show="overlay" position="fixed" />
      <ObservationInfoDetail :row="row"></ObservationInfoDetail>
      <hr class="my-6" />
      <div v-if="row.status == 'solved' && show" class="flex flex-col">
        <VForm
          class="max-w-sm w-full mb-5 mx-auto"
          v-if="customer == 'encargado-autorizado'"
          ref="formTenant"
          v-bind="formTenantConfig"
        >
        </VForm>
        <VSignature
          align="center"
          @change="onChangeSignature('signature', $event)"
        ></VSignature>
        <VButton
          class="mx-auto"
          :disabled="overlay || !pad.signature"
          @click="onUpdateState"
          text="Acepto"
          bgColor="bg-red-500"
        />
      </div>
    </template>
    <VModal v-bind="modal" v-model="modal.show">
      <VLoader :show="overlay">
        <template v-if="message">
          <div
            :class="styleMessage"
            class="p-5 -m-5 relative font-semibold text-center text-lg"
          >
            <span
              class="block absolute inset-0 z-0 bg-current opacity-10"
            ></span>
            <span>{{ message }}</span>
          </div>
        </template>
        <VForm
          v-else
          v-bind="formFields"
          ref="form"
          @submit="onSubmitState"
        ></VForm>
      </VLoader>
      <template #footer>
        <div class="flex gap-3">
          <VButton
            :disabled="overlay"
            text="Ingresar"
            bgColor="bg-green-500"
            @click="form.onSubmit()"
          />
        </div>
      </template>
    </VModal>
  </div>
</template>
<script setup>
import { onMounted, ref, reactive, computed } from "vue";
import $axios from "@/assets/js/axios";

import VForm from "@/components/VForm/VForm";
import VLoader from "@/components/VLoader";
import VButton from "@/components/VButton";
import VModal from "@/components/VModal";
import VSignature from "@/components/VSignature";
import ObservationInfoDetail from "@/views/layout/ObservationInfoDetail.vue";

import { useToast } from "vue-toastification";
const toast = useToast();

import { useRoute, useRouter } from "vue-router";
const router = useRouter();
const route = useRoute();

const { id, customer, obs } = route.params;
const overlay = ref(false);
const message = ref(null);
const password = ref(null);
const pad = reactive({
  signature: null,
});
const statusState = ref(false);

const styleMessage = computed(() => {
  switch (statusState.value) {
    case 210:
      return "text-blue-500";
    case 211:
      return "text-orange-500";
    case 403:
      return "text-amber-500";
    default:
      return "";
  }
});

const modal = reactive({
  show: false,
  hideClose: true,
  title: "Ingresar clave",
  size: "xs",
});

const form = ref(null);
const formFields = reactive({
  showSubmit: false,
  fields: {
    keyword: {
      attr: {
        type: "password",
        rules: "required",
      },
    },
  },
});

const formTenant = ref(null);
const formTenantConfig = reactive({
  showSubmit: false,
  fields: {
    name: {
      label: "Nombre",
      outline: true,
      width: "col-span-10",
      hiddeValidate: true,
      modifires: {
				capitalize: true
			},
      attr: {
        type: "text",
        rules: "required",
      },
    },
    nit: {
      label: "CC",
      outline: true,
      width: "col-span-10",
      hiddeValidate: true,
      attr: {
        type: "number",
        rules: "required",
      },
    },
    cellphone: {
      label: "Teléfono",
      outline: true,
      width: "col-span-10",
      hiddeValidate: true,
      attr: {
        type: "number",
        rules: "required",
      },
    },
  },
});

const onChangeSignature = (prop, value) => {
  pad[prop] = value;
};

const row = ref(null);

const onSubmitState = async ({ values }) => {
  overlay.value = true;
  const { keyword } = values;
  const { status, data } = await $axios({
    method: "post",
    url: `public/observation-state/${id}/${obs}`,
    data: { keyword },
    params: { customer },
  }).catch((e) => e.response);
  switch (status) {
    case 200:
      modal.show = false;
      password.value = keyword;
      row.value = data.row;
      break;
    default:
      Object.assign(modal, {
        show: true,
        hideClose: true,
        header: false,
        footer: false,
        size: "xs",
      });
      message.value = data.message;
  }
  overlay.value = false;
};

const onUpdateState = async () => {
  let tenant = null;
  if (formTenant.value) {
    const { valid } = await formTenant.value.validate();
    console.log(formTenant.value.values);
    if (!valid) {
      toast.error("Datos incompletos");
      return;
    }
    tenant = formTenant.value.values;
  }

  const keyword = password.value;
  const signature = pad.signature;
  overlay.value = true;
  const { status, data } = await $axios({
    method: "patch",
    url: `public/observation-state/${id}/${obs}`,
    data: { keyword, signature, tenant },
    params: { customer },
  }).catch((e) => e.response);
  statusState.value = status;
  switch (status) {
    case 210:
    case 211:
      Object.assign(modal, {
        show: true,
        hideClose: true,
        header: false,
        footer: false,
        size: "xs",
      });
      row.value = null;
      password.value = null;
      message.value = data.message;
      break;
    default:
      toast.error(data.message);
  }
  overlay.value = false;
};

const show = computed(() => {
  switch (customer) {
    case "propietario":
      return !row.value.proprietorSignature;
    case "proveedor":
      return !row.value.supplierSignature;
    case "encargado-autorizado":
      return !row.value.tenantSignature;
    default:
      return false;
  }
})

onMounted(async () => {
  if (["propietario", "proveedor", "encargado-autorizado"].includes(customer)) {
    const { status, data } = await $axios({
      method: "get",
      url: `public/observation-state/${id}/${obs}`,
      params: { customer },
    }).catch((e) => e.response);
    statusState.value = status;
    switch (status) {
      case 200:
        if (data.auth) {
          onSubmitState({ values: { keyword: null } });
        } else {
          modal.show = true;
        }
        break;
      case 210:
      case 211:
      case 403:
        message.value = data.message;
        Object.assign(modal, {
          show: true,
          hideClose: true,
          header: false,
          footer: false,
        });
        break;
      case 404:
        router.push({ name: "not-found" });
        break;
    }
  } else {
    router.push({ name: "not-found" });
  }
});
</script>
<style lang="scss">
.rich-text {
  @apply leading-relaxed;

  a {
    @apply text-red-500;
  }

  b,
  strong {
    @apply font-bold;
  }

  ul,
  ol {
    @apply pl-5 flex flex-col gap-2 marker:text-red-500;
  }

  ul {
    @apply list-disc;
  }

  ol {
    @apply list-decimal;
  }

  & > * + * {
    @apply mt-5;
  }
}
</style>
