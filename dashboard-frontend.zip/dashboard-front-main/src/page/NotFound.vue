<template>
	<div class="min-h-screen flex flex-col items-center justify-center text-center gap-10">
		<h1 class="text-red-500 text-8xl md:text-[200px] leading-none font-bold">404</h1>
		<p class="text-base md:text-2xl md:max-w-md leading-loose">
			¡Ups!... lo sentimos pero el contenido al que intentas ingresar no existe
		</p>
		<router-link :to="{name: 'signin'}" class="text-xl hover:underline text-red-500">
			Ir al inicio
		</router-link>
	</div>
</template>
<script>
export default {

	name: 'NotFound',

	data() {
		return {

		}
	}
}
</script>
<style lang="css" scoped>
</style>