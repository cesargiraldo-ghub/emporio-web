<template>
	<GridIcons :icons="fas" source="@fortawesome/free-solid-svg-icons"></GridIcons>
</template>
<script>
import { fas } from '@fortawesome/free-solid-svg-icons'
import GridIcons from "@/components/GridIcons"

export default {
	name: 'VSolid',
	components: {
		GridIcons
	},
	data(){
		return {
			fas
		}
	}
}
</script>