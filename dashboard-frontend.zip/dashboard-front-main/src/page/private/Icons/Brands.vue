<template>
	<GridIcons :icons="fab"></GridIcons>
</template>
<script>
import { fab } from '@fortawesome/free-brands-svg-icons'
import GridIcons from "@/components/GridIcons"

export default {
	name: 'VSolid',
	components: {
		GridIcons
	},
	data(){
		return {
			fab
		}
	}
}
</script>