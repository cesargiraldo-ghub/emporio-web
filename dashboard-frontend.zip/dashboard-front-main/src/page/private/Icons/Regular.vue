<template>
	<GridIcons :icons="far"></GridIcons>
</template>
<script>
import { far } from '@fortawesome/free-regular-svg-icons'
import GridIcons from "@/components/GridIcons"

export default {
	name: 'VSolid',
	components: {
		GridIcons
	},
	data(){
		return {
			far
		}
	}
}
</script>