<template>
  <VLoader :show="overlay">
    <VForm ref="createForm" v-bind="form" @submit="onCreateRol">
      <template #default="{ onSubmit, fields }">
        <VFieldset class="col-span-10" :border="false">
          <template #legend>
            <template v-for="(input, prop) in fields" :key="`input-${prop}`">
              <VInput
                v-if="$can('create', 'rols')"
                extrasClass="text-base bg-white"
                v-model.first="input.value"
                :name="prop"
                v-bind="input"
              />
            </template>
          </template>
          <template #tools>
            <VButton
              v-if="$can('create', 'rols')"
              type="submit"
              @click="onSubmit"
              bgColor="bg-green-500"
              :icon="faPlus"
            />
          </template>
          <template #default>
            <VTable v-bind="table" :rows="stateRols.rols">
              <template v-slot:actions="{ row }">
                <template
                  v-if="
                    user.rol.alias == 'super_admin'
                      ? row.ranking > 0
                      : row.ranking > 1
                  "
                >
                  <VButton
                    v-if="$can('update', 'rols')"
                    @click="updateRol(row.id)"
                    bgColor="bg-transparent"
                    textColor="text-blue-500"
                    :icon="faPen"
                  />
                  <VButton
                    v-if="$can('delete', 'rols') && row.ranking > 1"
                    @click="onDelete(row.id)"
                    bgColor="bg-transparent"
                    textColor="text-red-500"
                    :icon="faTrash"
                  />
                </template>
              </template>
            </VTable>
          </template>
        </VFieldset>
      </template>
    </VForm>
    <VModal v-model="modal.show" :title="modal.title" size="sm">
      <VLoader :show="overlay">
        <div class="flex flex-col -my-4 divide-y divide-gray-200">
          <template
            v-for="m in stateRols.modules"
            :key="`modules${$.uid}_${m.id}`"
          >
            <div class="py-4">
              <h3 class="text-lg font-semibold mb-2 leading-normal">
                {{ m.name }}
              </h3>
              <VCheck
                v-bind="{
                  label: 'name',
                  reduce: ({ id }) => ({ id }),
                }"
                :options="m.permissions"
                v-model="m.value"
              />
            </div>
          </template>
        </div>
      </VLoader>
      <template v-slot:footer>
        <div class="flex gap-3">
          <VButton
            :disabled="overlay"
            text="Guardar"
            bgColor="bg-green-500"
            @click="onSubmit"
          />
          <VButton
            :disabled="overlay"
            text="Cerrar"
            bgColor="bg-blue-500"
            @click="modal.show = false"
          />
        </div>
      </template>
    </VModal>
    <VModal v-model="destroy.show" v-bind="destroy">
      <VLoader :show="overlay">
        <div
          class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
        >
          <fa-icon
            class="text-red-500 text-5xl md:text-7xl"
            :icon="faCircleXmark"
          ></fa-icon>
          <p class="font-semibold text-red-500">
            {{ destroy.message }}
          </p>
          <p class="opacity-75 text-sm">
            <i
              >(Esta acción no se puede revertir despues de haberse
              ejecutado)</i
            >
          </p>
        </div>
      </VLoader>
      <template #footer>
        <div class="flex gap-3 justify-between">
          <VButton
            :disabled="overlay"
            text="Cerrar"
            bgColor="bg-gray-500"
            @click="destroy.show = false"
          />
          <VButton
            :disabled="overlay"
            text="Eliminar"
            @click="deleteRol(destroy.props)"
            bgColor="bg-red-500"
          />
        </div>
      </template>
    </VModal>
  </VLoader>
</template>
<script setup>
import { ref, reactive, onMounted, computed, watch } from "vue";
import { faPen, faTrash, faPlus, faCircleXmark, } from "@fortawesome/free-solid-svg-icons";
import { useStore } from "vuex";
const store = useStore();

import VFieldset from "@/components/VFieldset";
import VForm from "@/components/VForm/VForm";
import VLoader from "@/components/VLoader";
import VInput from "@/components/VForm/VInput";
import VTable from "@/components/VTable";
import VButton from "@/components/VButton";
import VCheck from "@/components/VForm/VCheck";
import VModal from "@/components/VModal";

const overlay = ref(false);
const modal = reactive({
  show: false,
  title: "Actualizar permisos",
  id: null,
});
const table = reactive({
  columns: [
    // {field: "id", label: "ID"},
    { field: "name", label: "Nombre" },
    {
      field: "actions",
      label: "Acciones",
      class: "text-right items-end justify-end",
      hiddenLabel: true,
    },
  ],
});
const form = reactive({
  showSubmit: false,
  fields: {
    name: {
      outline: true,
      notInherit: true,
      attr: {
        type: "text",
        placeholder: "Crear rol",
        rules: "required",
      },
      value: null,
    },
  },
});

const stateRols = computed(() => {
  return store.state["Rols"];
});
const user = computed(() => {
  return store.state["Users"].user;
});

const createForm = ref(null);
const onCreateRol = async ({ fields: data }) => {
  overlay.value = true;
  const result = await store.dispatch("createRow", {
    url: "auth/rol",
    prop: "rols",
    modules: "Rols",
    data,
  });

  if (result) createForm.value.onResetForm();

  overlay.value = false;
};

const destroy = reactive({
  show: false,
  title: "Elminar sección",
  type: "retired",
  size: "xs",
  message: "",
  footer: true,
  overlay: true,
  props: {},
});

const deleteRol = async ({id}) => {
  overlay.value = true;
  const res = await store.dispatch("deleteRow", {
    url: "auth/rol",
    prop: "rols",
    modules: "Rols",
    id,
  });
  if (res) {
    Object.assign(destroy, {
      show: false,
    });
  }
  overlay.value = false;
};

const onDelete = async (id) => {
  Object.assign(destroy, {
    show: true,
    message: "Esta seguro que quiere eliminar este rol.",
    props: { id },
  });
};

const onSubmit = async () => {
  overlay.value = true;
  const modules = [];
  const { id } = modal;
  stateRols.value.modules.forEach(({ value, id }) => {
    if (value.length) modules.push({ id, permissions: value });
  });

  const status = await store.dispatch("Rols/updateRolPermission", {
    id,
    modules,
  });

  if (status == 200)
    Object.assign(modal, {
      show: false,
      id: null
    });
  overlay.value = false;
};
const updateRol = async (id) => {
  Object.assign(modal, {
    show: true,
    id,
  });
  await store.dispatch("Rols/getPermissionRols", { id });
};

watch(() => stateRols.value, (a) => {
	console.log(a);
})

onMounted(async () => {
  overlay.value = true;
  await store.dispatch("getOptions", {
    url: "auth/rols",
    prop: "rols",
    modules: "Rols",
  });
  await store.dispatch("getOptions", {
    url: "auth/modules",
    prop: "modules",
    modules: "Rols",
    map: (res) => res.map((item) => {
			let permissions = item.permissions;
			switch(item.alias){
				case 'rols':
				case 'settings':
				case 'users':
					permissions = permissions.filter(f => !['import', 'export'].includes(f.alias))
					break;
				case 'observations':
					permissions = permissions.filter(f => !['delete', 'import', 'export'].includes(f.alias))
					break;
				case 'customers':
					permissions = permissions.filter(f => !['delete'].includes(f.alias))
					break;
				case 'profile':
					permissions = permissions.filter(f => ['read', 'update'].includes(f.alias))
					break;
	
			}
			return { ...item, permissions, value: [] }
		}),
  });
  overlay.value = false;
});
</script>
