<template>
  <div class="flex flex-col gap-4 md:gap-10">
    <VFieldset :border="false" class="relative shadow">
      <template #legend>
        <span class="text-xl font-medium text-red-600">Filtros</span>
      </template>
      <template #default>
        <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
          <template
            v-for="(field, prop) in filters"
            :key="`field-filter-${prop}-${$.uid}`"
          >
            <VInput
              classLabel="!text-sm font-semibold"
              v-model="field.value"
              v-bind="field"
              :name="`${prop}-${$.uid}`"
            />
          </template>
        </div>
      </template>
    </VFieldset>
    <VFieldset :border="false" :fixed-tools="true">
      <template #legend>
        <span v-if="title" class="text-xl font-medium text-red-600">{{
          title
        }}</span>
      </template>
      <template #tools>
        <VButton
          v-if="can('create', 'users')"
          @click="createRow"
          bgColor="bg-green-500"
          :icon="faPlus"
        />
      </template>
      <template #default>
        <VLoader :show="overlay">
          <div class="flex flex-wrap xl:flex-nowrap gap-5 xl:mt-3">
            <VInput
              class="w-24"
              v-model="pages.perPage"
              @update:modelValue="pages.current = 1"
              v-bind="pages.select"
              name="perPage"
            />
            <div
              class="flex flex-col md:flex-row gap-5 w-full xl:w-auto flex-grow items-center"
            >
              <span class="my-auto xl:ml-auto font-semibold opacity-80">
                <span class="text-red-500">{{ totalItems.current }}</span> de
                {{ totalItems.total }} Inmuebles
              </span>
              <VPagination
                class="md:ml-auto"
                :pages="pagination.pages"
                v-model:current="pages.current"
              ></VPagination>
            </div>
          </div>
          <VTable
            class="my-4"
            v-bind="{ ...table, selected }"
            @rowSelected="rowSelected"
          >
            <template #rol="{ value }">
              {{ value?.name }}
            </template>
            <template #actions="{ row }">
              <div class="inline-flex flex-wrap gap-2">
                <VButton
                  v-if="can('read', 'users')"
                  :to="{ name: 'profile-user', params: { id: row.id } }"
                  bgColor="bg-transparent"
                  textColor="text-indigo-500"
                  :icon="faUser"
                />
                <VButton
                  v-if="can('update', 'users')"
                  @click="updateRow(row)"
                  bgColor="bg-transparent"
                  textColor="text-blue-500"
                  :icon="faPen"
                />
                <VButton
                  v-if="can('delete', 'users')"
                  @click="onDelete(row.id)"
                  bgColor="bg-transparent"
                  textColor="text-red-500"
                  :icon="faTrash"
                />
              </div>
            </template>
          </VTable>
          <div
            class="flex flex-col items-center md:flex-row md:items-start gap-5"
          >
            <span class="md:mr-auto font-semibold opacity-80">
              <span class="text-red-500">{{ totalItems.current }}</span> de
              {{ totalItems.total }} Inmuebles
            </span>
            <VPagination
              :pages="pagination.pages"
              v-model:current="pages.current"
            ></VPagination>
          </div>
        </VLoader>
        <VModal v-model="modal.show" v-bind="modal">
          <VLoader :show="overlay">
            <VForm v-bind="formFields" @submit="onSubmit" ref="form">
              <template #default="{ fields }">
                <template
                  v-for="(input, prop) in fields"
                  :key="`field_${prop}_${$.uid}`"
                >
                  <VInput
                    :disabled="
                      modal.id ? ['nit', 'email'].includes(prop) : false
                    "
                    v-model="input.value"
                    :name="prop"
                    v-bind="input"
                    :modelModifiers="input.modifires"
                  />
                </template>
              </template>
            </VForm>
          </VLoader>
          <template #top-tools>
            <VButton
              v-if="can('delete', 'users') && modal.type == 'update'"
              :disabled="overlay"
              @click="onDelete(modal.id)"
              bgColor="bg-transparent"
              textColor="text-red-500"
              :icon="faTrash"
            />
          </template>
          <template #footer>
            <div class="flex gap-3">
              <VButton
                :disabled="overlay"
                :text="modal.type == 'update' ? 'Guardar' : 'Crear'"
                bgColor="bg-green-500"
                @click="form.onSubmit()"
              />
              <VButton
                :disabled="overlay"
                text="Cerrar"
                bgColor="bg-blue-500"
                @click="modal.show = false"
              />
            </div>
          </template>
        </VModal>
        <VModal v-model="destroy.show" v-bind="destroy">
          <VLoader :show="overlay">
            <div
              class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
            >
              <fa-icon
                class="text-red-500 text-5xl md:text-7xl"
                :icon="faCircleXmark"
              ></fa-icon>
              <p class="font-semibold text-red-500">
                {{ destroy.message }}
              </p>
              <p class="opacity-75 text-sm">
                <i
                  >(Esta acción no se puede revertir despues de haberse
                  ejecutado)</i
                >
              </p>
            </div>
          </VLoader>
          <template #footer>
            <div class="flex gap-3 justify-between">
              <VButton
                :disabled="overlay"
                text="Cerrar"
                bgColor="bg-gray-500"
                @click="destroy.show = false"
              />
              <VButton
                :disabled="overlay"
                text="Eliminar"
                @click="deleteRow(destroy.props)"
                bgColor="bg-red-500"
              />
            </div>
          </template>
        </VModal>
      </template>
    </VFieldset>
  </div>
</template>
<script>
export default {
  name: "VUsers",
};
</script>
<script setup>
import { useAbility } from "@casl/vue";
import {
  faPlus,
  faPen,
  faTrash,
  faUser,
  faCircleXmark,
} from "@fortawesome/free-solid-svg-icons";
import {
  reactive,
  onMounted,
  ref,
  defineProps,
  defineEmits,
  defineExpose,
  computed,
  watch,
} from "vue";
import {
  users,
  fullUsers,
  getUsers,
  createUser,
  updateUser,
  deleteUser,
} from "@/mixins/MixinUsers";
import { rols, getRols } from "@/mixins/MixinOptions";

import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VTable from "@/components/VTable";
import VLoader from "@/components/VLoader";
import VModal from "@/components/VModal";
import VForm from "@/components/VForm/VForm";
import VInput from "@/components/VForm/VInput";
import VPagination from "@/components/VPagination";
import { clearString } from "@/assets/js/filters";

const { can } = useAbility();

const emits = defineEmits(["rowSelected"]);
const props = defineProps({
  selected: {
    type: Boolean,
    default: false,
  },
  title: {
    type: String,
    default: "",
  },
});

const overlay = ref(false);
const modal = reactive({
  show: false,
  title: null,
  size: "xs",
  aside: "right",
  overlay: true,
  type: null,
  id: null,
});

const filters = reactive({
  name: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-12",
    label: "Nombre",
    attr: {
      type: "text",
    },
    value: null,
  },
});

const items = computed(() => {
  const rows = props.selected ? fullUsers : users;
  return rows.value.filter((user) => {
    const res = [];

    for (let f in filters) {
      let value = filters[f].value;
      if (value) {
        if (f == "name") {
          res.push(clearString(user["name"]).includes(clearString(value)));
        }
      }
    }

    return !res.includes(false);
  });
});

const pages = reactive({
  current: 1,
  perPage: 9,
  select: {
    notInherit: true,
    hiddeValidate: true,
    outline: true,
    attr: {
      type: "select",
      clearable: false,
      options: [9, 18, 50],
    },
  },
});

watch(
  () => items.value,
  () => {
    pages.current = 1;
  }
);

const pagination = computed(() => {
  const start = (pages.current - 1) * pages.perPage;
  const end = start + pages.perPage;

  return {
    pages: Math.ceil(items.value.length / pages.perPage),
    start,
    end,
  };
});

const totalItems = computed(() => {
  return {
    current:
      pagination.value.start + pages.perPage > items.value.length
        ? items.value.length
        : pagination.value.start + pages.perPage,
    total: items.value.length,
  };
});

const rows = computed(() => {
  return items.value.slice(pagination.value.start, pagination.value.end);
});

const table = reactive({
  rows,
  columns: [
    { field: "rol", label: "Rol" },
    { field: "name", label: "Nombre" },
    { field: "last", label: "Apellido" },
    { field: "nit", label: "Nit" },
    { field: "email", label: "E-mail" },
    {
      field: "actions",
      label: "Acciones",
      class: "text-right items-end justify-end",
      hiddenLabel: true,
      can: [can("update", "users"), can("delete", "users")],
    },
  ],
});
const form = ref(null);
const formFields = reactive({
  showSubmit: false,
  fields: {
    rol: {
      notInherit: true,
      label: "Rol",
      attr: {
        type: "select",
        reduce: ({ id }) => id,
        clearable: false,
        options: rols,
        label: "name",
        rules: "required",
      },
    },
    nit: {
      notInherit: true,
      label: "Numero de identificación",
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        numeric: true,
      },
    },
    name: {
      notInherit: true,
      label: "Nombres",
      width: "col-span-5",
      modifires: {
        capitalize: true,
      },
      attr: {
        type: "text",
        rules: "required",
      },
    },
    last: {
      notInherit: true,
      label: "Apellidos",
      modifires: {
        capitalize: true,
      },
      width: "col-span-5",
      attr: {
        type: "text",
        rules: "required",
      },
    },
    email: {
      notInherit: true,
      label: "E-mail",
      width: "col-span-5",
      attr: {
        type: "email",
        rules: "required|email",
      },
    },
    cellphone: {
      notInherit: true,
      label: "Celular",
      width: "col-span-5",
      attr: {
        type: "text",
        rules: "numeric",
      },
      modifires: {
        numeric: true,
      },
    },
  },
});

const onSubmit = async ({ values }) => {
  overlay.value = true;

  let state = false;

  const { type, id } = modal;

  switch (type) {
    case "create":
      state = await createUser(values);
      break;

    case "update":
      state = await updateUser(values, id);
      break;
  }

  overlay.value = false;
  if (state) {
    Object.assign(modal, {
      show: false,
      type: null,
    });
  }
};

const createRow = () => {
  setValuesForm(() => null);
  Object.assign(modal, {
    title: "Crear",
    show: true,
    type: "create",
    id: null,
  });
};

const updateRow = ({ id, ...row }) => {
  setValuesForm((prop) => row[prop]?.id || row[prop]);
  Object.assign(modal, {
    title: "Actualizar",
    show: true,
    type: "update",
    id,
  });
};

const destroy = reactive({
  show: false,
  title: "Elminar usuario",
  type: "retired",
  size: "xs",
  message: "",
  footer: true,
  overlay: true,
  props: {},
});

const deleteRow = async ({ id }) => {
  overlay.value = true;
  const res = await deleteUser(id);
  if (res) {
    Object.assign(destroy, {
      show: false,
    });
  }
  overlay.value = false;
};

const onDelete = async (id) => {
  Object.assign(destroy, {
    show: true,
    message: "Esta seguro que quiere eliminar esta usuario.",
    props: { id },
  });
};

const setValuesForm = (callback) => {
  const inputsForm = formFields.fields;
  for (let prop in inputsForm) inputsForm[prop].value = callback(prop);
};

onMounted(async () => {
  overlay.value = true;
  await getUsers();
  await getRols();
  overlay.value = false;
});

const row = ref(null);
const rowSelected = (data) => {
  row.value = data;
  emits("rowSelected", Boolean(data));
};

const getRow = () => {
  return row.value;
};

defineExpose({ getRow });
</script>
