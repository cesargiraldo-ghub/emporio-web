<template>
  <div class="flex flex-col gap-4 md:gap-10">
    <span
      class="md:hidden z-40 fixed backdrop-blur inset-0 w-full h-full transition duration-500 cursor-pointer"
      @click="onToggleFilters"
      :class="
        filterState ? 'pointer-events-auto' : 'opacity-0 pointer-events-none'
      "
    ></span>
    <VFieldset
      :border="false"
      class="!fixed max-h-[80vh] overflow-y-auto inset-x-0 bottom-0 md:!relative z-50 md:z-30 transition duration-500 md:translate-y-0 shadow"
      :class="{ 'translate-y-full': !filterState }"
    >
      <template #legend>
        <span class="text-xl font-medium text-red-600">Filtros</span>
        <VButton
          class="md:!hidden absolute left-5 bottom-full mb-5 z-50"
          bgColor="bg-violet-500"
          @click="onToggleFilters"
          title="Limpiar filtros"
          :icon="faSort"
        />
      </template>
      <template #tools>
        <VButton
          bgColor="bg-blue-500"
          @click="onClearFilters"
          title="Limpiar filtros"
          :icon="faBroom"
        />
      </template>
      <template #default>
        <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
          <template
            v-for="(input, prop) in filtersProducts"
            :key="`input-filter-${prop}-${$.uid}`"
          >
            <VInput
              classLabel="!text-sm font-semibold"
              v-model="input.value"
              v-bind="input"
              :name="prop"
            />
          </template>
        </div>
      </template>
    </VFieldset>
    <ul class="flex flex-wrap divide-x divide-gray-400">
      <li
        v-for="(item, index) in menu"
        :key="`menu-item-${item.to?.query?.leased_state}-${index}`"
        class="text-xs md:text-sm flex-grow md:flex-grow-0"
      >
        <RouterLink
          :to="item.to"
          :class="[
            'px-4 py-2 font-semibold',
            (!leased_state.includes(route.query.leased_state) &&
              !item.to.query?.leased_state) ||
            (item.to.query?.leased_state == route.query.leased_state &&
              leased_state.includes(route.query.leased_state))
              ? 'text-red-500'
              : 'opacity-80',
          ]"
          >{{ item.name }}</RouterLink
        >
      </li>
    </ul>
    <VTableProducts
      ref="tableProducts"
      :inventory="true"
      @reload="onReload"
      @load="initProducts"
      :items="items"
    ></VTableProducts>
  </div>
</template>
<script setup>
import { faBroom, faSort } from "@fortawesome/free-solid-svg-icons";
import { reactive, ref, computed } from "vue";
import { users, getUsers } from "@/mixins/MixinUsers";
import { proprietors, leaseholders, getCustomers } from "@/mixins/MixinCustomers";
import { products, leasedState, getProducts } from "@/mixins/MixinProducts";
import {
  bussinessTypes,
  productsTypes,
  getBussinessTypes,
  getProductsTypes,
} from "@/mixins/MixinOptions";

import VInput from "@/components/VForm/VInput";
import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VTableProducts from "@/views/layout/VTableProducts";

import { clearString } from "@/assets/js/filters";
import { withPopper } from "@/assets/js/utils";

import { useRoute } from "vue-router";
const route = useRoute();

const filtersProducts = reactive({
  id: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-2",
    label: "ID",
    attr: {
      type: "text",
    },
    value: null,
  },
  code: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-2",
    label: "Codígo",
    attr: {
      type: "text",
    },
    value: null,
  },
  address: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-8",
    label: "Nombre o Dirección",
    attr: {
      type: "text",
    },
    value: null,
  },
  bussiness_type: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Tipo de establecimiento",
    attr: {
      label: "name",
      type: "select",
      options: bussinessTypes,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  product_type: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Tipo de inmueble",
    attr: {
      label: "name",
      type: "select",
      options: productsTypes,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  leased_state: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Estado de arriendo",
    attr: {
      label: "label",
      type: "select",
      options: leasedState.options,
      reduce: (i) => i.key,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  proprietor: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Propietario",
    attr: {
      label: "fullName",
      type: "select",
      options: proprietors,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  leaseholder: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Arrendatario",
    attr: {
      label: "fullName",
      type: "select",
      options: leaseholders,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  user: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Agente",
    attr: {
      label: "fullName",
      type: "select",
      options: users,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  date_inventory_from: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-3",
    label: "Inventario desde",
    attr: {
      type: "date",
    },
    value: null,
  },
  date_inventory_to: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-3",
    label: "Inventario hasta",
    attr: {
      type: "date",
    },
    value: null,
  },
  date_from: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-3",
    label: "Entrega desde",
    attr: {
      type: "date",
    },
    value: null,
  },
  date_to: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-3",
    label: "Entrega hasta",
    attr: {
      type: "date",
    },
    value: null,
  },
});

const items = computed(() =>
  products.value.filter((product) => {
    const res = [];

    if (route.query.leased_state == "trasher")
      res.push(Boolean(product.deletedAt));
    else if (product.deletedAt) res.push(false);
    else if (!route?.query?.leased_state) res.push(true);
    else if (leased_state.value.includes(route.query.leased_state))
      res.push(product.leased_state == route.query.leased_state);

    for (let f in filtersProducts) {
      let value = filtersProducts[f].value;
      let prop = null;
      if (value) {
        switch (f) {
          case "address":
            res.push(
              clearString(product[f]).includes(clearString(value)) ||
                clearString(product["name"]).includes(clearString(value))
            );
            break;
          case "proprietor":
            res.push(
              [product["proprietor"]?.id, product["proprietor_data"]?.id].includes(value)
            );
            break;
          case "leaseholder":
            res.push(
              [product["leaseholder"]?.id, product["leaseholder_data"]?.id].includes(value)
            );
            break;
          case "user":
            res.push(
              [product["second_user"]?.id, product["user"]?.id].includes(value)
            );
            break;
          case "date_from":
          case "date_inventory_from":
            prop = f.replace("_from", "");
            res.push(Date.parse(product[prop]) >= Date.parse(value));
            break;
          case "date_to":
          case "date_inventory_to":
            prop = f.replace("_to", "");
            res.push(Date.parse(product[prop]) <= Date.parse(value));
            break;
          default:
            res.push((product[f]?.id || product[f]) == value);
        }
      }
    }

    return !res.includes(false);
  })
);

const leased_state = ref([
  "draft",
  "initial",
  "delivery",
  "leased",
  "finished",
  "trasher",
]);

const menu = reactive([
  { name: "Todos", to: { name: "inventory" } },
  {
    name: "Borrador",
    to: { name: "inventory", query: { leased_state: "draft" } },
  },
  {
    name: "Inicial",
    to: { name: "inventory", query: { leased_state: "initial" } },
  },
  {
    name: "Entrega",
    to: { name: "inventory", query: { leased_state: "delivery" } },
  },
  {
    name: "Alquilado",
    to: { name: "inventory", query: { leased_state: "leased" } },
  },
  {
    name: "Finalizado",
    to: { name: "inventory", query: { leased_state: "finished" } },
  },
  {
    name: "Papelera",
    to: { name: "inventory", query: { leased_state: "trasher" } },
  },
]);

const filterState = ref(false);
const onToggleFilters = () => {
  filterState.value = !filterState.value;
};

const onClearFilters = () => {
  for (let prop in filtersProducts) {
    filtersProducts[prop].value = null;
  }
};

const onReload = async (overlay) => {
  overlay.value = true;
  await getProducts();
  overlay.value = false;
};

const initProducts = async (overlay) => {
  overlay.value = true;
  await getUsers();
  await getCustomers();
  await getBussinessTypes();
  await getProductsTypes();
  await getProducts();
  overlay.value = false;
};
</script>
