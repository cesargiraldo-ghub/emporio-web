<template>
  <VLoader :show="overlay">
    <transition name="fade" mode="out-in">
      <template v-if="product || !routeId">
        <VForm
          v-bind="form"
          @submit="onSaveProduct"
          :key="routeId"
          ref="formEl"
        >
          <template #default="{ onSubmit, fields }">
            <VFieldset class="col-span-2 md:col-span-10" :border="false">
              <template #legend>
                <VInput
                  v-model="fields.name.value"
                  name="name"
                  v-bind="fields.name"
                  extrasClass="text-base md:text-xl font-medium text-red-600 bg-white w-full"
                />
              </template>
              <template #default>
                <div
                  class="px-3 pb-3 grid md:grid-cols-12 gap-10 md:gap-x-6 md:gap-y-12 mt-4"
                >
                  <template
                    v-for="(input, prop) in fields"
                    :key="`field_${prop}_${$.uid}`"
                  >
                    <div
                      v-if="!input.notLoop"
                      class="flex flex-col gap-2"
                      :class="input.width"
                    >
                      <VInput
                        :disabled="prop == 'second_user' ? !check : false"
                        v-model="input.value"
                        :name="prop"
                        v-bind="input"
                        :modelModifiers="input.modifires"
                      />
                      <VCheckItem
                        v-if="prop == 'second_user'"
                        name="Asignar segundo asesor"
                        @change="onChecked(input, $event)"
                        :checked="check"
                      />
                    </div>
                  </template>
                </div>
              </template>
            </VFieldset>
            <VWrapperStikcyBtn class="col-span-2 md:col-span-10">
              <VButton
                class="text-lg font-medium"
                :bgColor="routeId ? 'bg-blue-500' : 'bg-green-500'"
                :text="routeId ? 'Guardar' : 'Crear'"
                @click="onSavePublishProduct(onSubmit, false)"
              ></VButton>
              <VButton
                v-if="routeId"
                class="text-lg font-medium"
                bgColor="bg-green-500"
                text="Guardar y salir"
                @click="onSavePublishProduct(onSubmit, true)"
              ></VButton>
            </VWrapperStikcyBtn>
          </template>
        </VForm>
      </template>
    </transition>
  </VLoader>
</template>
<script setup>
import { reactive, onMounted, ref, computed, watch } from "vue";
import {
  productsData,
  state,
  leasedState,
  productState,
  getProduct,
  createProduct,
  updateProduct,
} from "@/mixins/MixinProductsData";
import {
  bussinessTypes,
  productsTypes,
  getBussinessTypes,
  getProductsTypes,
} from "@/mixins/MixinOptions";

import { setValuesForm } from "@/assets/js/filters";

import VFieldset from "@/components/VFieldset";
import VForm from "@/components/VForm/VForm";
import VButton from "@/components/VButton";

import VInput from "@/components/VForm/VInput";
import VLoader from "@/components/VLoader";

import VCheckItem from "@/components/VForm/VCheck/VCheckItem";
import VWrapperStikcyBtn from "@/components/VWrapperStikcyBtn";

import { useToast } from "vue-toastification";
const toast = useToast();

import { useRoute } from "vue-router";
import router from "@/router";

const route = useRoute();
const routeId = computed(() => route.params.id);

const product = ref(null);
const overlay = ref(false);

const form = reactive({
  showSubmit: false,
  fields: {
    name: {
      notInherit: true,
      notLoop: true,
      outline: true,
      width: "w-full",
      attr: {
        type: "text",
        rules: "required",
      },
    },
    code: {
      notInherit: true,
      label: "Codigo",
      width: "md:col-span-3 lg:col-span-2",
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        numeric: true,
      },
      value: null,
    },
    address: {
      notInherit: true,
      label: "Dirección",
      width: "md:col-span-6 lg:col-span-4",
      attr: {
        type: "text",
        rules: "required",
      },
    },
    price: {
      notInherit: true,
      label: "Precio",
      width: "md:col-span-3",
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        price: true,
      },
      value: null,
    },
    bussiness_type: {
      notInherit: true,
      label: "Tipo de negocio",
      width: "md:col-span-6 lg:col-span-3",
      attr: {
        label: "name",
        type: "select",
        options: bussinessTypes,
        reduce: (i) => i.id,
        rules: "required",
      },
    },
    product_type: {
      notInherit: true,
      label: "Tipo de Inmueble",
      width: "md:col-span-6 lg:col-span-3",
      attr: {
        label: "name",
        type: "select",
        options: productsTypes,
        reduce: (i) => i.id,
        rules: "required",
      },
    },
    state: {
      notInherit: true,
      label: "Estado de fisico",
      width: "md:col-span-4 lg:col-span-3",
      attr: {
        label: "label",
        type: "select",
        options: state.options,
        reduce: (i) => i?.key,
        rules: "required",
      },
    },
    product_state: {
      notInherit: true,
      label: "Clasificación",
      width: "md:col-span-4 lg:col-span-3",
      attr: {
        label: "label",
        type: "select",
        options: productState.options,
        reduce: (i) => i?.key,
        rules: "required",
      },
    },
    leased_state: {
      notInherit: true,
      label: "Estado de inventario",
      width: "md:col-span-4 lg:col-span-3",
      attr: {
        label: "label",
        type: "select",
        options: leasedState.options,
        reduce: (i) => i?.key,
        rules: "required",
      },
    },
  },
});

const check = ref(false);
const onChecked = (input, { target }) => {
  check.value = target.checked;
  input.value = null;
};

watch(
  () => form.fields.product_type.value,
  (a, b) => {
    if (b) form.fields.attrs.value = [];
  }
);

watch(
  () => route.params,
  async ({ id }) => {
    if (id && route.name == "product-edit") await setProduct();
  },
  { deep: true }
);

const setProduct = async () => {
  let result = null;
  if (routeId.value) {
    if (!productsData.value.length) result = await getProduct(routeId.value);
    else result = productsData.value.find((item) => item.id == routeId.value);

    if (!result) {
      await router.push({ name: "not-found" });
      return;
    }

    setValuesForm(form.fields, (prop) =>
      ["bussiness_type", "product_type"].includes(prop)
        ? result[prop]?.id
        : result[prop]
    );

    product.value = result;
  }
};

const exit = ref(false);
const save = ref(false);
const onSavePublishProduct = (callback, e) => {
  exit.value = e;
  save.value = true;
  callback();
};

const onSaveProduct = async ({ fields }) => {
  overlay.value = true;

  try {
    let result = null;
    if (routeId.value) {
      const { data: res } = await updateProduct(
        {
          ...fields,
        },
        routeId.value
      ).catch((e) => e.response);
      result = res;
    } else {
      const { status, data: res } = await createProduct({
        ...fields,
      }).catch((e) => e.response);
      result = res;

      if (status == 200) router.push({ name: "products-data" });
    }

    setValuesForm(form.fields, (prop) =>
      ["bussiness_type", "product_type"].includes(prop)
        ? result[prop]?.id
        : result[prop]
    );

    product.value = result;
  } catch (e) {
    console.error(e);
  }

  overlay.value = false;

  if (exit.value) {
    router.push({ name: "products-data" });
    return;
  }
};

const formEl = ref(false);
const errors = computed(() => formEl.value.errors);

onMounted(async () => {
  await getBussinessTypes();
  await getProductsTypes();
  await setProduct();
  watch(
    () => errors.value,
    (a) => {
      if (Object.keys(a).length && save.value) {
        toast.error("Faltan campos por registrar");
        save.value = false;
      }
    }
  );
});
</script>
