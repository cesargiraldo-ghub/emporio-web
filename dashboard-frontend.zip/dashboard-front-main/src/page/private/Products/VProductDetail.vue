<template>
  <VLoader :show="overlay">
    <transition name="fade" mode="out-in">
      <template v-if="product || !routeId">
        <VForm
          v-bind="form"
          @submit="onSaveProduct"
          :key="routeId"
          ref="formEl"
        >
          <template #default="{ onSubmit, fields, errors }">
            <template v-if="fields.attrs.value?.length">
              <div
                v-if="onErrorInputs(errors).length"
                class="col-span-2 md:col-span-10 bg-red-100 text-red-500 p-5 border border-current rounded text-base"
              >
                <p>Hay camplos incompletos en:</p>
                <ul class="flex flex-wrap gap-3">
                  <li
                    v-for="error in onErrorInputs(errors)"
                    :key="`error-input-${error}`"
                    class="font-medium"
                  >
                    {{ fields.attrs.value[error]?.name }}
                  </li>
                </ul>
              </div>
            </template>
            <template v-if="!atmosphere.length">
              <div
                class="col-span-2 md:col-span-10 bg-amber-100 text-amber-500 p-5 border border-current rounded font-medium text-base text-center"
              >
                No hay ambinetes registrados.
                <router-link
                  class="underline"
                  :to="{ name: 'settings-form-atmosphere' }"
                  >Crear Ambiente</router-link
                >
              </div>
            </template>
            <VFieldset class="col-span-2 md:col-span-10" :border="false">
              <template #legend>
                <VInput
                  v-model="fields.name.value"
                  name="name"
                  v-bind="fields.name"
                  extrasClass="text-base md:text-xl font-medium text-red-600 bg-white"
                />
              </template>
              <template #default>
                <div
                  class="px-3 pb-3 grid md:grid-cols-12 gap-10 md:gap-x-6 md:gap-y-12 mt-4"
                >
                  <template
                    v-for="(input, prop) in fields"
                    :key="`field_${prop}_${$.uid}`"
                  >
                    <div
                      v-if="!input.notLoop"
                      class="flex flex-col gap-2"
                      :class="input.width"
                    >
                      <VInput
                        :disabled="prop == 'second_user' ? !check : false"
                        v-model="input.value"
                        :name="prop"
                        v-bind="input"
                        :modelModifiers="input.modifires"
                      />
                      <VButton
                        v-if="prop == 'leaseholder'"
                        :icon="faArrowRightArrowLeft"
                        bgColor="bg-transparent"
                        textColor="text-blue-500"
                        @click="
                          changeCustomers(() =>
                            onSavePublishProduct(onSubmit, false)
                          )
                        "
                      ></VButton>
                      <VCheckItem
                        v-if="prop == 'second_user'"
                        name="Asignar segundo asesor"
                        @change="onChecked(input, $event)"
                        :checked="check"
                      />
                    </div>
                  </template>
                </div>
              </template>
            </VFieldset>
            <template v-if="routeId">
              <template v-if="product?.leased_state == 'draft'">
                <div
                  v-if="atmosphere.length"
                  class="flex flex-wrap gap-1 col-span-2 md:col-span-10"
                >
                  <template
                    v-for="(panel, i) in panels"
                    :key="`panel_${i}_${panel.id}_${$.uid}`"
                  >
                    <VButton
                      @click="addAtmosphereSections(fields.attrs.value, panel)"
                      :text="panel.name"
                      bgColor="bg-emerald-500"
                      :icon="faPlus"
                      size="xs"
                    />
                  </template>
                </div>
                <template v-else>
                  <div
                    class="col-span-2 md:col-span-10 bg-amber-100 text-amber-500 p-5 border border-current rounded font-medium text-base text-center"
                  >
                    No hay ambinetes registrados.
                    <router-link
                      class="underline"
                      :to="{ name: 'settings-form-atmosphere' }"
                      >Crear Ambiente</router-link
                    >
                  </div>
                </template>
              </template>
              <template v-if="fields.attrs.value?.length">
                <div
                  v-if="onErrorInputs(errors).length"
                  class="col-span-2 md:col-span-10 bg-red-100 text-red-500 p-5 border border-current rounded text-base"
                >
                  <p>Hay camplos incompletos en:</p>
                  <ul class="flex flex-wrap gap-3">
                    <li
                      v-for="error in onErrorInputs(errors)"
                      :key="`error-input-${error}`"
                      class="font-medium"
                    >
                      {{ fields.attrs.value[error]?.name }}
                    </li>
                  </ul>
                </div>
                <div class="col-span-2 md:col-span-10 flex flex-col gap-8">
                  <VueDraggable
                    v-model="fields.attrs.value"
                    :item-key="itemKey"
                    class="flex flex-wrap gap-2"
                    handle=".handle"
                  >
                    <template #item="{ element: profile, index }">
                      <span
                        class="relative flex items-center gap-2 p-2 bg-white rounded shadow cursor-pointer max-sm:grow"
                        :class="{
                          'border-b border-red-500': currentTab == index,
                        }"
                      >
                        <span
                          @click="currentProfileSections(index)"
                          class="p-2 -m-2 flex items-center gap-2"
                        >
                          <VButton
                            v-if="product?.leased_state == 'draft'"
                            class="handle !cursor-move"
                            bgColor="bg-transparent"
                            textColor="text-gray-500"
                            :icon="faArrows"
                            size="sm"
                          />
                          <span>
                            {{ profile.name }}
                          </span>
                        </span>
                        <VButton
                          v-if="product?.leased_state == 'draft'"
                          @click="onDelete(fields.attrs.value, index)"
                          bgColor="bg-transparent"
                          textColor="text-red-500"
                          :icon="faClose"
                          size="sm"
                          class="ml-auto"
                        />
                        <i
                          v-if="onErrorInputs(errors).includes(index)"
                          class="absolute right-0 top-0 w-[1.6em] text-xs aspect-square flex bg-red-500 rounded-full text-white translate-x-1/2 -translate-y-1/2"
                        >
                          <fa-icon
                            class="block m-auto"
                            :icon="faExclamation"
                          ></fa-icon>
                        </i>
                      </span>
                    </template>
                  </VueDraggable>
                  <VFieldset :border="false">
                    <VLoader :show="mediaOverlay" class="flex">
                      <div class="w-1 flex-grow">
                        <VFilesUpload
                          class="p-3"
                          :modelValue="fields.attrs.value[currentTab].images"
                          :pendint="pendint"
                          :progress="progress"
                          :image="(img) => onFilterURL(img)"
                          :fullImage="(img) => onFilterURL(img, '', img.format)"
                          :tools="product?.leased_state == 'draft'"
                          @onChange="
                            onUploadFiles(
                              $event,
                              fields.attrs.value[currentTab].idPanel
                            )
                          "
                          @onDelete="
                            onDeleteImage(
                              $event,
                              fields.attrs.value[currentTab].idPanel
                            )
                          "
                          @onDeleteMulti="
                            onDeleteImages(
                              $event,
                              fields.attrs.value[currentTab].idPanel
                            )
                          "
                        />
                      </div>
                    </VLoader>
                  </VFieldset>
                  <div ref="anchor" class="-mb-8"></div>
                  <template
                    v-for="(attribute, index) in fields.attrs.value"
                    :key="`attribute-${attribute.idPanel}-${index}`"
                  >
                    <VFieldset v-if="index == currentTab" :border="false">
                      <template #legend>
                        <VInput
                          v-model="attribute.name"
                          :name="`name-${attribute.idPanel}-${index}`"
                          v-bind="{
                            ...fieldAttr.name,
                            attr: {
                              ...fieldAttr.name.attr,
                            },
                          }"
                          extrasClass="text-lg font-medium text-red-500 bg-white"
                        />
                      </template>
                      <template #default>
                        <div class="flex flex-col gap-6 relative">
                          <div
                            class="flex flex-wrap gap-2 rounded bg-zinc-100 shadow-inner p-2"
                          >
                            <template
                              v-for="(section, s) in attribute.sections"
                              :key="`tab-section-${attribute.idPanel}-${index}-${section.id}-${s}`"
                            >
                              <span
                                @click="currentAttribute(s)"
                                class="relative flex items-center gap-2 p-2 bg-white rounded shadow cursor-pointer max-sm:grow"
                                :class="{
                                  'border-b border-red-500': attrCurrent == s,
                                }"
                              >
                                <span class="p-2 -m-2 flex items-center gap-2">
                                  <span>
                                    {{ section.name }}
                                  </span>
                                </span>
                              </span>
                            </template>
                          </div>
                          <template
                            v-for="(section, s) in attribute.sections"
                            :key="`section-${attribute.idPanel}-${index}-${section.id}-${s}`"
                          >
                            <div
                              v-if="attrCurrent == s"
                              class="flex flex-col gap-6 px-3"
                            >
                              <div class="flex gap-4">
                                <h2
                                  class="w-1 grow text-lg font-semibold text-red-700 pb-3 border-b border-gray-300"
                                >
                                  {{ section.name }}
                                </h2>
                              </div>
                              <template
                                v-for="(attr, a) in section.attrs"
                                :key="`attr-${attribute.idPanel}-${index}-${section.id}-${s}-${attr.id}-${a}`"
                              >
                                <VFieldset border="border border-red-200">
                                  <template #legend>
                                    <span class="text-base font-medium px-2">
                                      {{ attr.name }}
                                    </span>
                                  </template>
                                  <template #default>
                                    <div class="grid grid-cols-1 gap-6">
                                      <template
                                        v-for="(field, f) in attr.fields"
                                        :key="`field-${attribute.idPanel}-${index}-${section.id}-${s}-${attr.id}-${a}-${field.id}-${f}`"
                                      >
                                        <VFieldset
                                          :class="{
                                            'pointer-events-none opacity-30':
                                              !rulesInput(attr.fields, field),
                                          }"
                                        >
                                          <template #legend>
                                            <span class="font-medium px-2">
                                              {{ field.name }}
                                            </span>
                                          </template>
                                          <template #default>
                                            <span
                                              class="opacity-75"
                                              v-if="field.description"
                                              >{{ field.description }}</span
                                            >
                                            <template
                                              v-if="
                                                rulesInput(attr.fields, field)
                                              "
                                            >
                                              <VInput
                                                :name="`field-${attribute.idPanel}-${index}-${section.id}-${s}-${attr.id}-${a}-${field.id}-${f}`"
                                                v-model="field.value"
                                                v-bind="{
                                                  hiddeValidate: true,
                                                  attr: {
                                                    ...typeInput(field),
                                                  },
                                                }"
                                              />
                                            </template>
                                            <template v-else>
                                              <VInput
                                                :name="`field-${attribute.idPanel}-${index}-${section.id}-${s}-${attr.id}-${a}-${field.id}-${f}`"
                                                v-model="field.value"
                                                v-bind="{
                                                  hiddeValidate: true,
                                                  attr: { ...typeInput(field) },
                                                }"
                                              />
                                            </template>
                                          </template>
                                        </VFieldset>
                                      </template>
                                    </div>
                                  </template>
                                </VFieldset>
                              </template>
                            </div>
                          </template>
                          <div class="sticky bottom-14 md:bottom-5">
                            <VButton
                              @click="onAnchor"
                              class="shadow absolute bottom-0 left-0"
                              bgColor="bg-red-500"
                              textColor="text-white"
                              :icon="faChevronUp"
                            />
                          </div>
                        </div>
                      </template>
                    </VFieldset>
                  </template>
                </div>
              </template>
              <template v-else>
                <div
                  class="col-span-2 md:col-span-10 bg-blue-100 text-blue-500 p-5 border border-current rounded font-medium text-base text-center"
                >
                  No hay paneles registrados
                </div>
              </template>
            </template>
            <VFieldset class="col-span-2 md:col-span-10" :border="false">
              <template #legend>
                <span class="text-xl font-medium text-red-600"
                  >Observaciones</span
                >
              </template>
              <template #default>
                <div class="grid md:grid-cols-2 gap-5">
                  <VInput
                    v-model="fields.user_observation.value"
                    name="user_observation"
                    v-bind="fields.user_observation"
                  />
                  <VInput
                    v-model="fields.proprietor_observation.value"
                    name="proprietor_observation"
                    v-bind="fields.proprietor_observation"
                  />
                  <VInput
                    v-model="fields.leaseholder_observation.value"
                    name="leaseholder_observation"
                    v-bind="fields.leaseholder_observation"
                  />
                </div>
              </template>
            </VFieldset>
            <template v-if="atmosphere.length">
              <VWrapperStikcyBtn class="col-span-2 md:col-span-10">
                <VButton
                  class="text-lg font-medium"
                  bgColor="bg-green-500"
                  :text="routeId ? 'Guardar' : 'Crear'"
                  @click="onSavePublishProduct(onSubmit, false)"
                ></VButton>
                <VButton
                  v-if="routeId"
                  class="text-lg font-medium"
                  bgColor="bg-blue-500"
                  text="Guardar y salir"
                  @click="onSavePublishProduct(onSubmit, true)"
                ></VButton>
                <VButton
                  v-else
                  class="text-lg font-medium"
                  bgColor="bg-blue-500"
                  text="Salir"
                  :to="{ name: 'products-data' }"
                ></VButton>
              </VWrapperStikcyBtn>
            </template>
          </template>
        </VForm>
      </template>
    </transition>
    <VModal v-model="destroy.show" v-bind="destroy">
      <VLoader :show="overlay">
        <div
          class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
        >
          <fa-icon
            class="text-red-500 text-5xl md:text-7xl"
            :icon="faCircleXmark"
          ></fa-icon>
          <p class="font-semibold text-red-500">
            {{ destroy.message }}
          </p>
          <p class="opacity-75 text-sm">
            <i
              >(Esta acción no se puede revertir despues de haberse
              ejecutado)</i
            >
          </p>
        </div>
      </VLoader>
      <template #footer>
        <div class="flex gap-3 justify-between">
          <VButton
            :disabled="overlay"
            text="Cerrar"
            bgColor="bg-gray-500"
            @click="destroy.show = false"
          />
          <VButton
            :disabled="overlay"
            text="Eliminar"
            @click="deleteRow(destroy.props)"
            bgColor="bg-red-500"
          />
        </div>
      </template>
    </VModal>
  </VLoader>
</template>
<script setup>
import {
  faPlus,
  faClose,
  faArrows,
  faExclamation,
  faChevronUp,
  faCircleXmark,
  faArrowRightArrowLeft,
} from "@fortawesome/free-solid-svg-icons";
import {
  reactive,
  onMounted,
  ref,
  computed,
  watch,
  shallowReactive,
} from "vue";
import { sections, getSections } from "@/mixins/MixinSections";
import {
  state,
  // leasedState,
  productState,
  getProduct,
  createProduct,
  updateProduct,
} from "@/mixins/MixinProducts";
import {
  bussinessTypes,
  productsTypes,
  getBussinessTypes,
  getProductsTypes,
  atmosphere,
  getAtmosphere,
} from "@/mixins/MixinOptions";
import { setValuesForm, onFilterURL, dateFormat } from "@/assets/js/filters";

import $axios from "@/assets/js/axios";
import axios from "axios";

import VFieldset from "@/components/VFieldset";
import VForm from "@/components/VForm/VForm";
import VButton from "@/components/VButton";
import VueDraggable from "vuedraggable";
import VInput from "@/components/VForm/VInput";
import VLoader from "@/components/VLoader";
import VFilesUpload from "@/components/VFilesUpload";
import VUsers from "@/page/private/VUsers";
import VCustomers from "@/page/private/Customers/VCustomers";
import VCheckItem from "@/components/VForm/VCheck/VCheckItem";
import VWrapperStikcyBtn from "@/components/VWrapperStikcyBtn";
import VModal from "@/components/VModal";

import { useToast } from "vue-toastification";
const toast = useToast();

import { useRoute } from "vue-router";
import router from "@/router";
import { useStore } from "vuex";

const store = useStore();
const productCurrent = computed(() => store.state["Products"].current);

const route = useRoute();
const routeId = computed(() => route.params.id);

const currentTab = ref(0);
const product = reactive({});
const overlay = ref(false);

const formEl = ref(null);

const destroy = reactive({
  show: false,
  title: "Elminar sección",
  type: "retired",
  size: "xs",
  message: "",
  footer: true,
  overlay: true,
  props: {},
});

const onDelete = async (values, index) => {
  Object.assign(destroy, {
    show: true,
    message: "Esta seguro que quiere eliminar esta sección.",
    props: { values, index },
  });
};

const deleteRow = async ({ values, index }) => {
  overlay.value = true;
  await removeAtmosphereSections(values, index);
  Object.assign(destroy, {
    show: false,
  });

  overlay.value = false;
};

const form = reactive({
  showSubmit: false,
  fields: {
    name: {
      notInherit: true,
      notLoop: true,
      outline: true,
      width: "w-full",
      hiddeValidate: true,
      attr: {
        type: "text",
        rules: "required",
      },
    },
    code: {
      notInherit: true,
      label: "Codigo",
      width: "md:col-span-3 lg:col-span-2",
      hiddeValidate: true,
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        numeric: true,
      },
      value: null,
    },
    address: {
      notInherit: true,
      label: "Dirección",
      width: "md:col-span-6 lg:col-span-4",
      hiddeValidate: true,
      attr: {
        type: "text",
        rules: "required",
      },
    },
    price: {
      notInherit: true,
      label: "Precio",
      width: "md:col-span-3",
      hiddeValidate: true,
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        price: true,
      },
      value: null,
    },
    bussiness_type: {
      notInherit: true,
      label: "Tipo de negocio",
      width: "md:col-span-6 lg:col-span-3",
      hiddeValidate: true,
      attr: {
        label: "name",
        type: "select",
        options: bussinessTypes,
        reduce: (i) => i.id,
        rules: "required",
      },
    },
    product_type: {
      notInherit: true,
      label: "Tipo de Inmueble",
      width: "md:col-span-6 lg:col-span-4",
      hiddeValidate: true,
      attr: {
        label: "name",
        type: "select",
        options: productsTypes,
        reduce: (i) => i.id,
        rules: "required",
      },
    },
    state: {
      notInherit: true,
      label: "Estado de fisico",
      width: "md:col-span-6 lg:col-span-4",
      hiddeValidate: true,
      attr: {
        label: "label",
        type: "select",
        options: state.options,
        reduce: (i) => i?.key,
        rules: "required",
      },
    },
    product_state: {
      notInherit: true,
      label: "Clasificación",
      width: "md:col-span-6 lg:col-span-4",
      hiddeValidate: true,
      attr: {
        label: "label",
        type: "select",
        options: productState.options,
        reduce: (i) => i?.key,
        rules: "required",
      },
    },
    // leased_state: {
    //   notInherit: true,
    //   label: "Estado de inventario",
    //   width: "md:col-span-4 lg:col-span-3",
    //   hiddeValidate: true,
    //   attr: {
    //     label: "label",
    //     type: "select",
    //     options: leasedState.options,
    //     reduce: (i) => i?.key,
    //     rules: "required",
    //   },
    // },
    date_catchment: {
      notInherit: true,
      hiddeValidate: true,
      label: "Fecha de captación",
      width: "md:col-span-4",
      attr: {
        type: "date",
        min: dateFormat(new Date()),
        locale: "es",
        enableTimePicker: false,
      },
    },
    date_inventory: {
      notInherit: true,
      hiddeValidate: true,
      label: "Fecha de inventario",
      width: "md:col-span-4",
      attr: {
        type: "date",
        min: dateFormat(new Date()),
        locale: "es",
        enableTimePicker: false,
      },
    },
    date: {
      notInherit: true,
      hiddeValidate: true,
      label: "Fecha de entrega",
      width: "md:col-span-4",
      attr: {
        type: "date",
        min: dateFormat(new Date()),
        locale: "es",
        enableTimePicker: false,
      },
    },
    proprietor: shallowReactive({
      notInherit: true,
      hiddeValidate: true,
      label: "Propietario",
      width: "md:col-span-6 lg:col-span-3",
      attr: {
        type: "table",
        reduce: (v) => v?.id,
        component: VCustomers,
        filter: 1,
        result: (r) => r?.fullName,
        title: "Seleccionar Propietario",
        titleTable: "Propietarios",
      },
    }),
    leaseholder: shallowReactive({
      notInherit: true,
      hiddeValidate: true,
      label: "Arrendatario",
      width: "md:col-span-6 lg:col-span-3",
      attr: {
        type: "table",
        reduce: (v) => v?.id,
        component: VCustomers,
        filter: 2,
        result: (r) => r?.fullName,
        title: "Seleccionar Arrendatario",
        titleTable: "Arrendatarios",
      },
    }),
    user: shallowReactive({
      notInherit: true,
      hiddeValidate: true,
      label: "Primer Asesor",
      width: "md:col-span-6 lg:col-span-3",
      attr: {
        type: "table",
        reduce: (v) => v?.id,
        component: VUsers,
        result: (r) => r?.fullName,
        title: "Seleccionar Usuario",
        titleTable: "Usuarios",
      },
    }),
    second_user: shallowReactive({
      notInherit: true,
      hiddeValidate: true,
      label: "Segundo Asesor",
      width: "md:col-span-6 lg:col-span-3",
      attr: {
        type: "table",
        reduce: (v) => v?.id,
        component: VUsers,
        result: (r) => r?.fullName,
        title: "Seleccionar Usuario",
        titleTable: "Usuarios",
      },
    }),
    user_observation: {
      notInherit: true,
      hiddeValidate: true,
      notLoop: true,
      outline: true,
      width: "md:col-span-2",
      label: "Observaciones del Asesor",
      attr: {
        type: "textarea",
        rows: "5",
      },
      value: null,
    },
    proprietor_observation: {
      notInherit: true,
      hiddeValidate: true,
      notLoop: true,
      outline: true,
      width: "col-span-1",
      label: "Observaciones del Propietario",
      attr: {
        type: "textarea",
        rows: "5",
      },
      value: null,
    },
    leaseholder_observation: {
      notInherit: true,
      hiddeValidate: true,
      notLoop: true,
      outline: true,
      width: "col-span-1",
      label: "Observaciones del Arrendatario",
      attr: {
        type: "textarea",
        rows: "5",
      },
      value: null,
    },
    signature: {
      notInherit: true,
      hiddeValidate: true,
      notLoop: true,
      value: null,
    },
    signature_proprietor: {
      notInherit: true,
      hiddeValidate: true,
      notLoop: true,
      value: null,
    },
    images: {
      notInherit: true,
      notLoop: true,
      value: [],
    },
    attrs: {
      notInherit: true,
      notLoop: true,
      value: [],
    },
  },
});

const changeCustomers = (fn) => {
  const proprietor = form.fields.proprietor.value;
  const leaseholder = form.fields.leaseholder.value;

  form.fields.proprietor.value = leaseholder;
  form.fields.leaseholder.value = proprietor;

  const signature = form.fields.signature.value;
  const signature_proprietor = form.fields.signature_proprietor.value;

  form.fields.signature.value = signature_proprietor;
  form.fields.signature_proprietor.value = signature;

  fn();
};

const attrCurrent = ref(0);

const panels = computed(() =>
  atmosphere.value.filter((a) =>
    a.productTypes.includes(form.fields.product_type.value)
  )
);

const check = ref(false);
const onChecked = (input, { target }) => {
  check.value = target.checked;
  input.value = null;
};

watch(
  () => form.fields.product_type.value,
  (a, b) => {
    if (b) form.fields.attrs.value = [];
  }
);

const fieldAttr = reactive({
  name: {
    outline: true,
    hiddeValidate: true,
    attr: {
      type: "text",
      rules: "required",
    },
  },
});

const currentProfileSections = (index) => {
  currentTab.value = index;
  attrCurrent.value = 0;
};

const currentAttribute = (index) => {
  attrCurrent.value = index;
};

const anchor = ref(null);
const onAnchor = () => {
  window.scrollTo(0, anchor.value.offsetTop);
};

const addAtmosphereSections = (attrs, panel) => {
  let result = sections.value.filter((section) =>
    section.atmosphere.includes(panel.id)
  );
  result.sort((a, b) =>
    a.position > b.position ? 1 : a.position < b.position ? -1 : 0
  );
  result = JSON.parse(JSON.stringify(result));

  attrs.push({
    sections: result,
    name: panel.name,
    id: panel.id,
    idPanel: Date.now(),
    images: [],
    position: attrs.length,
  });

  onSaveDraft();
};

const removeAtmosphereSections = async (field, index) => {
  currentTab.value = 0;
  const attr = field.splice(index, 1);
  try {
    let images = attr[0].images;
    if (images.length) {
      await onDeleteImages(images, attr[0].idPanel, false);
    }
  } catch (e) {
    console.error(e);
  }

  onSaveDraft();
};

const onSaveDraft = () => {
  const fields = {};
  for (let key in form.fields) {
    fields[key] = form.fields[key].value;
  }
  onSaveProduct({ fields });
};

const itemKey = ({ id, position }) => {
  return `${id}-${position}`;
};

const typeInput = ({ type, options }) => {
  switch (type) {
    case "unique":
      return {
        type: "check",
        multiple: false,
        options,
      };

    case "multi":
      return {
        type: "check",
        options,
      };

    case "number":
      return {
        type: "number",
      };

    case "long":
      return {
        type: "textarea",
      };

    default:
      return {
        type: "text",
      };
  }
};

const rulesInput = (attrs, attr) => {
  const value = attrs.filter((item) => item.id == attr.parent)[0]?.value;
  const result = value == attr.conditional;
  if (!result) attr.value = null;

  return result;
};

const mapDetail = (result) => {
  const res = [];
  result.attrs.forEach((attribute) => {
    const filter = atmosphere.value.find(
      (item) =>
        item.id == attribute.id &&
        item.productTypes.includes(result.product_type.id)
    );
    if (filter) {
      const resS = [];
      const sectionsClone = JSON.parse(JSON.stringify(sections.value));
      sectionsClone.forEach((section) => {
        const filterS = sectionsClone.find(
          (item) =>
            item.id == section.id && item.atmosphere.includes(attribute.id)
        );
        const valueS = attribute.sections.find(
          (item) =>
            item.id == section.id && item.atmosphere.includes(attribute.id)
        );
        if (filterS) {
          const resA = [];
          filterS.attrs.forEach((attr) => {
            const filterA = filterS.attrs.find((item) => item.id == attr.id);
            const valueA = valueS?.attrs?.find((item) => item.id == attr.id);

            if (filterA) {
              const resF = [];
              filterA.fields.forEach((field) => {
                const filterF = filterA.fields.find(
                  (item) => item.id == field.id
                );
                const valueF = valueA?.fields?.find(
                  (item) => item.id == field.id
                );

                if (filterF) {
                  if (valueF) {
                    Object.assign(field, {
                      value:
                        field.type == "unique" && valueF.value
                          ? field.options.includes(valueF.value)
                            ? valueF.value
                            : ""
                          : field.type == "multi" && Array.isArray(valueF.value)
                          ? valueF.value?.find((item) =>
                              field.options.includes(item)
                            )
                            ? valueF.value
                            : ""
                          : valueF.value,
                    });
                  }
                  resF.push(field);
                }
              });
              resA.push(attr);
              attr.fields = resF;
            }
          });
          resS.push(section);
          section.attrs = resA;
        }
      });
      attribute.sections = resS;
      res.push(attribute);
    }
  });
  res.forEach((item) => {
    item.sections.sort((a, b) =>
      a["position"] > b["position"] ? 1 : a["position"] < b["position"] ? -1 : 0
    );
  });
  result.attrs = res;
};

const mediaOverlay = ref(false);
const count = ref(0);
const progress = ref(0);
const pendint = ref(0);
const total = ref([]);
const loading = ref(false);

const onUploadFiles = async ({ values, target }, id) => {
  pendint.value += values.length;
  total.value = [...total.value, ...values];
  mediaOverlay.value = true;

  if (!loading.value) {
    count.value = 0;
    loading.value = true;
    do {
      try {
        const { data: sing } = await $axios.get(
          `auth/product-media/${routeId.value}/${id}`
        );

        const { cloud_name } = sing;

        const data = new FormData();
        const formData = { file: total.value[count.value], ...sing };
        for (let key in formData) data.append(key, formData[key]);

        const url = `https://api.cloudinary.com/v1_1/${cloud_name}/auto/upload`;

        const {
          data: { public_id, resource_type, format },
        } = await axios({
          method: "post",
          url,
          data,
          onUploadProgress: ({ progress: pgss }) => {
            progress.value = pgss;
          },
        });

        const {
          data: { attrs },
        } = await $axios({
          method: "patch",
          url: `auth/product-media/${routeId.value}/${id}`,
          data: { public_id, resource_type, format },
        });
        mediaOverlay.value = false;

        form.fields.attrs.value = attrs;

        progress.value = 0;
        count.value++;
        pendint.value--;
      } catch (e) {
        console.error(e);
        const { data } = e.response;
        progress.value = 0;
        pendint.value = 0;
        count.value++;

        if (data) toast.error(data.message);

        break;
      }
    } while (count.value < total.value.length);
    target.value = null;
    total.value = [];
    loading.value = false;
  }
};

const onDeleteImage = async (image, id) => {
  mediaOverlay.value = true;
  try {
    const {
      data: { attrs, message },
    } = await $axios({
      method: "delete",
      url: `auth/product-media/${routeId.value}/${id}`,
      data: { image },
    });

    form.fields.attrs.value = attrs;

    toast.success(message);
  } catch (e) {
    const { data } = e.response;
    toast.error(data.message);
  }
  mediaOverlay.value = false;
};

const onDeleteImages = async (images, id, write = true) => {
  mediaOverlay.value = true;
  try {
    const {
      data: { attrs, message },
    } = await $axios({
      method: "delete",
      url: `auth/product-medias/${routeId.value}/${id}`,
      data: images,
    });

    if (write) {
      form.fields.attrs.value = attrs;
      toast.success(message);
    }
  } catch (e) {
    const { data } = e.response;
    toast.error(data.message);
  }
  mediaOverlay.value = false;
};

const onErrorInputs = (errors) => {
  const result = [];
  for (let input in errors) {
    const index = Number(input.split("-")[2]);
    if (!result.includes(index)) {
      result.push(index);
    }
  }
  return result;
};

watch(
  () => route.params,
  async ({ id }) => {
    if (id && route.name == "product-edit") await setProduct();
  },
  { deep: true }
);

const setProduct = async () => {
  let result = null;
  if (!routeId.value && productCurrent.value) {
    result = JSON.parse(JSON.stringify(productCurrent.value));
    result.attrs = [];
    result.leased_state = "draft";
  }

  if (routeId.value) {
    result = await getProduct(routeId.value);

    if (!result) {
      await router.push({ name: "not-found" });
      return;
    }

    if (["leased", "finished"].includes(result.leased_state)) {
      router.push({ name: "inventory" });
      return;
    }

    if (result.leased_state == "draft") mapDetail(result);

    // const fields = [
    //   "bussiness_type",
    //   "product_type",
    //   "state",
    //   "product_state",
    //   "date_catchment",
    //   "date_inventory",
    //   "proprietor",
    //   "user",
    //   "user_observation",
    //   "proprietor_observation",
    // ];

    // if (!["draft"].includes(result.leased_state))
    //   fields.forEach((key) => {
    //     form.fields[key].attr.disabled = true;
    //     form.fields[key].attr.rules = false;
    //   });

    if (result?.second_user) check.value = true;
  }
  if (result)
    setValuesForm(form.fields, (prop) =>
      ["bussiness_type", "product_type"].includes(prop)
        ? result[prop]?.id
        : result[prop]
    );
  Object.assign(product, result);
  // product.value = result;
};

const exit = ref(false);
const save = ref(false);
const onSavePublishProduct = (callback, e) => {
  exit.value = e;
  save.value = true;
  callback();
};

const onSaveProduct = async () => {
  overlay.value = true;
  const fields = {};
  for (let prop in form.fields) {
    fields[prop] = form.fields[prop].value;
  }
  console.log(fields);
  try {
    let result = null;
    if (routeId.value) {
      const { data: res } = await updateProduct(
        {
          ...fields,
        },
        routeId.value
      ).catch((e) => e.response);
      result = res;
    } else {
      const { status, data: res } = await createProduct({
        ...fields,
      }).catch((e) => e.response);

      store.commit("SET_STATE", {
        prop: "current",
        modules: "Products",
        data: null,
      });
      result = res;

      if (status == 200)
        router.push({ name: "inventory-edit", params: { id: res.id } });
    }

    if (exit.value) {
      router.push({ name: "inventory" });
      return;
    }

    if (result.leased_state == "draft") mapDetail(result);

    setValuesForm(form.fields, (prop) =>
      ["bussiness_type", "product_type"].includes(prop)
        ? result[prop]?.id
        : result[prop]
    );

    if (result?.second_user) check.value = true;

    Object.assign(product, result);
    // product.value = result;
  } catch (e) {
    console.error(e);
  }

  overlay.value = false;
};

const errors = computed(() => formEl.value?.errors || []);
// onBeforeRouteLeave(async () => {
//   const attrs = form.fields.attrs.value;
//   if (attrs.length) {
//     const { valid } = await formEl.value.validate();
//     if (!valid) {
//       alert(
//         "Faltan campos registrar porfavor verificar antes de cambiar de página"
//       );
//       toast.error("Faltan campos por registrar");
//     }
//     return valid;
//   }
//   return true;
// });

onMounted(async () => {
  if (!routeId.value && !productCurrent.value) {
    await router.push({ name: "products-data" });
    return;
  }

  await getBussinessTypes();
  await getProductsTypes();
  await getAtmosphere();
  await getSections();
  await setProduct();
  watch(
    () => errors.value,
    (a) => {
      if (Object.keys(a).length && save.value) {
        toast.error("Faltan campos por registrar");
        save.value = false;
      }
    }
  );
});
</script>
