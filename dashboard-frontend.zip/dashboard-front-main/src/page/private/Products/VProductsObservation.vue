<template>
  <div class="flex flex-col gap-4 md:gap-10">
    <VLoader
      v-if="leasedState != 'finished' && can('create', 'observations')"
      :show="overlay"
    >
      <VForm
        v-bind="problem"
        ref="formObservations"
        @submit="onCreateObservation"
      >
        <template #default="{ onSubmit, fields }">
          <VFieldset :border="false" class="shadow col-span-2 md:col-span-10">
            <template #legend>
              <span class="text-xl font-medium text-red-600"
                >Crear observación</span
              >
            </template>
            <template #tools>
              <VButton
                @click="onSubmit"
                bgColor="bg-green-500"
                title="Crear observación"
                :icon="faPlus"
              />
            </template>
            <template #default>
              <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <template
                  v-for="(input, prop) in fields"
                  :key="`input-filter-${prop}-${$.uid}`"
                >
                  <VInput
                    classLabel="!text-sm font-semibold"
                    v-model.first="input.value"
                    v-bind="input"
                    :name="prop"
                  />
                  <VInput
                    modelValue="progress"
                    :attr="{ type: 'hidden' }"
                    name="status"
                  />
                </template>
              </div>
            </template>
          </VFieldset>
        </template>
      </VForm>
    </VLoader>
    <span
      class="md:hidden z-40 fixed backdrop-blur inset-0 w-full h-full transition duration-500 cursor-pointer"
      @click="onToggleFilters"
      :class="
        filterState ? 'pointer-events-auto' : 'opacity-0 pointer-events-none'
      "
    ></span>
    <VFieldset
      :border="false"
      class="!fixed max-h-[80vh] overflow-y-auto inset-x-0 bottom-0 md:!relative z-50 md:z-30 transition duration-500 md:translate-y-0 shadow"
      :class="{ 'translate-y-full': !filterState }"
    >
      <template #legend>
        <span class="text-xl font-medium text-red-600">Filtros</span>
        <VButton
          class="md:!hidden absolute left-5 bottom-full mb-5 z-50"
          bgColor="bg-violet-500"
          @click="onToggleFilters"
          title="Limpiar filtros"
          :icon="faSort"
        />
      </template>
      <template #tools>
        <VButton
          bgColor="bg-blue-500"
          @click="onClearFilters"
          title="Limpiar filtros"
          :icon="faBroom"
        />
      </template>
      <template #default>
        <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
          <template
            v-for="(input, prop) in filtersProducts"
            :key="`input-filter-${prop}-${$.uid}`"
          >
            <VInput
              classLabel="!text-sm font-semibold"
              v-model="input.value"
              v-bind="input"
              :name="prop"
            />
          </template>
        </div>
      </template>
    </VFieldset>
    <ul class="flex flex-wrap divide-x divide-gray-400">
      <li
        v-for="(item, index) in menu"
        :key="`menu-item-${item.to?.query?.leased_state}-${index}`"
        class="text-xs md:text-sm flex-grow md:flex-grow-0"
      >
        <RouterLink
          :to="item.to"
          :class="[
            'px-4 py-2 font-semibold',
            (!leased_state.includes(route.query.leased_state) &&
              !item.to.query?.leased_state) ||
            (item.to.query?.leased_state == route.query.leased_state &&
              leased_state.includes(route.query.leased_state))
              ? 'text-red-500'
              : 'opacity-80',
          ]"
          >{{ item.name }}</RouterLink
        >
      </li>
    </ul>
    <VFieldset :border="false">
      <template #default>
        <VLoader :show="overlay">
          <div class="flex flex-wrap xl:flex-nowrap gap-5 xl:mt-3">
            <VInput
              class="w-24"
              v-model="pages.perPage"
              @update:modelValue="pages.current = 1"
              v-bind="pages.select"
              name="perPage"
            />
            <div
              class="flex flex-col md:flex-row gap-5 w-full xl:w-auto flex-grow items-center"
            >
              <span class="my-auto xl:ml-auto font-semibold opacity-80">
                <span class="text-red-500">{{ totalItems.current }}</span> de
                {{ totalItems.total }} Registros
              </span>
              <VPagination
                class="md:ml-auto"
                :pages="pagination.pages"
                v-model:current="pages.current"
              ></VPagination>
            </div>
          </div>
          <VTable class="my-4" v-bind="table">
            <template #real-state="{ row }">
              <div
                @click="onObservationDetail(row)"
                class="grid md:grid-cols-[1fr_550px] gap-4 items-center cursor-pointer py-2.5 w-full"
              >
                <h2 class="flex justify-between w-full md:flex-col gap-1">
                  <span class="font-semibold text-sm md:text-base">{{
                    row.title
                  }}</span>
                  <span class="opacity-70 text-sm italic">{{
                    row.code || row.id
                  }}</span>
                </h2>
                <div
                  class="grid grid-cols-2 md:grid-cols-4 gap-y-2 gap-x-4 items-center"
                >
                  <span
                    class="text-red-500 flex items-center font-semibold -ml-2"
                  >
                    <VButton
                      bgColor="bg-transparent"
                      textColor="text-red-500"
                      :icon="faClose"
                    />
                    <span>{{ date(row.date_problem) }}</span>
                  </span>
                  <span
                    class="text-green-500 flex items-center font-semibold justify-end md:justify-start"
                  >
                    <VButton
                      bgColor="bg-transparent"
                      textColor="text-green-500"
                      :icon="faCheck"
                    />
                    <span>{{
                      row.date_solution ? date(row.date_solution) : "----"
                    }}</span>
                  </span>
                  <span class="md:justify-self-end">
                    <VBadge v-bind="onObservationStatus(row.status)" />
                  </span>
                  <span class="justify-self-end">
                    <VBadge v-bind="onLeasedState(row.leased_state)" />
                  </span>
                </div>
              </div>
            </template>
          </VTable>
          <div
            class="flex flex-col items-center md:flex-row md:items-start gap-5"
          >
            <span class="md:mr-auto font-semibold opacity-80">
              <span class="text-red-500">{{ totalItems.current }}</span> de
              {{ totalItems.total }} Registros
            </span>
            <VPagination
              :pages="pagination.pages"
              v-model:current="pages.current"
            ></VPagination>
          </div>
        </VLoader>
      </template>
    </VFieldset>
    <VModal v-model="modal.show" v-bind="modal">
      <template #top-tools>
        <div class="flex flex-wrap md:flex-row flex-grow items-center gap-4">
          <h2 class="text-base md:text-xl font-semibold flex flex-col md:flex-row gap-1 md:gap-2">
            {{ row.title }}
            <span
              class="text-red-500 text-sm md:text-lg font-semibold leading-tight"
              >{{ row.code || row.id }}</span
            >
          </h2>
          <div class="flex ml-auto gap-4 text-xs md:text-base">
            <VBadge v-bind="onObservationStatus(row.status)" />
            <VBadge v-bind="onLeasedState(row.leased_state)" />
          </div>
        </div>
      </template>
      <VLoader :show="overlay">
        <div class="flex flex-col gap-4">
          <div class="flex flex-col gap-4 p-4 rounded-lg bg-red-50">
            <div
              class="text-base font-bold text-red-500 flex gap-3 items-center"
            >
              <VButton
                class="!rounded-full border border-current"
                bgColor="bg-red-500"
                textColor="text-white"
                size="sm"
                :icon="faClose"
              />
              <span>{{ date(row.date_problem) }}</span>
            </div>
            <div>
              {{ row.problem }}
            </div>
          </div>
          <VLoader :show="mediaOverlay" class="flex">
            <div class="w-1 flex-grow">
              <VFilesUpload
                :tools="
                  !(row.date_solution && row.solution) &&
                  ['reception', 'quoting'].includes(row.status)
                "
                :hideDelete="!can('delete', 'observations')"
                :hideUpload="!can('update', 'observations')"
                :hideSelect="!can('delete', 'observations')"
                :columns="5"
                :modelValue="row['images_problem']"
                :pendint="images['problem'].pendint"
                :progress="images['problem'].progress"
                :image="(img) => onFilterURL(img)"
                :fullImage="(img) => onFilterURL(img, '', img.format)"
                @onChange="onUploadFiles($event, row, 'problem')"
                @onDelete="onDeleteImage($event, row.id, 'problem')"
                @onDeleteMulti="onDeleteImages($event, row.id, 'problem')"
              />
            </div>
          </VLoader>
          <template v-if="row.status == 'canceled' && row.canceled">
            <hr class="border-t border-gray-200 my-3" />
            <div class="flex flex-col gap-4 leading-relaxed">
              <h2 class="text-lg font-semibold">Motivo de cancelación</h2>
              <p>{{ row.canceled }}</p>
            </div>
          </template>
          <template
            v-if="'quoting' == row.status && !can('update', 'observations')"
          >
            <hr class="border-t border-gray-200 my-3" />
            <div
              class="flex flex-col gap-4 leading-relaxed text-base font-semibold"
            >
              <p>No hay proveedores registrados</p>
            </div>
          </template>
          <template
            v-if="'quoting' == row.status && can('update', 'observations')"
          >
            <hr class="border-t border-gray-200 my-3" />
            <h2 class="text-lg font-semibold">Crear proveedor</h2>
            <VForm
              class="col-span-2"
              ref="supplier-form"
              v-bind="supplier"
              @submit="
                async ({ values }) => {
                  await onSaveSolution(row, values, 'supplier');
                  $refs['supplier-form'].onResetForm();
                }
              "
            >
              <template #default="{ onSubmit, fields }">
                <VInput
                  classLabel="!text-sm font-semibold"
                  v-bind="fields.name"
                  name="name"
                />
                <VInput
                  classLabel="!text-sm font-semibold"
                  v-bind="fields.phone"
                  name="phone"
                />
                <div class="flex gap-5 col-span-10">
                  <VInput
                    class="w-1 flex-grow"
                    classLabel="!text-sm font-semibold"
                    v-bind="fields.date"
                    name="date"
                  />
                  <VButton
                    @click="onSubmit"
                    class="mt-2.5"
                    bgColor="bg-green-500"
                    size="lg"
                    title="Guardar"
                    :icon="faSave"
                  />
                </div>
              </template>
            </VForm>
          </template>
          <template v-if="row.supplier && row.supplier.length">
            <hr class="border-t border-gray-200 my-3" />
            <h2 class="text-lg font-semibold">Proveedores</h2>
            <template
              v-for="(item, index) in row.supplier"
              :key="`supplier-${index}-${item.id}`"
            >
              <div
                class="grid grid-cols-4 gap-5 p-5 rounded-lg shadow-md"
                :class="
                  row.supplierCurrent == item.id ? 'bg-green-200' : 'bg-white'
                "
              >
                <VFilesUpload
                  message="Cotización"
                  :tools="['quoting'].includes(row.status)"
                  :hideSelect="true"
                  :hideUpload="
                    item.doc.length && !can('update', 'observations')
                      ? true
                      : false
                  "
                  :hideDelete="!can('delete', 'observations')"
                  :columns="1"
                  :modelValue="item.doc"
                  :pendint="item.pendint"
                  :multiple="false"
                  :progress="item.progress"
                  :image="(img) => onFilterURL(img)"
                  :fullImage="(img) => onFilterURL(img, '', img.format)"
                  @onChange="onUploadDocs($event, row, item)"
                  @onDelete="onDeleteImage($event, row.id, 'supplier', item.id)"
                />
                <table
                  class="col-span-3 [&_td:first-child]:font-semibold [&_td:last-child]:text-right [&_td:last-child]:font-semibold [&_td:last-child]:text-base"
                >
                  <tbody>
                    <tr>
                      <td>Nombre</td>
                      <td>{{ item.name }}</td>
                    </tr>
                    <tr>
                      <td>Teléfono</td>
                      <td>{{ item.phone }}</td>
                    </tr>
                    <tr>
                      <td>Fecha de visita</td>
                      <td>{{ date(item.date) }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </template>
            <hr class="border-t border-gray-200 my-3" />
            <VForm
              v-if="row.status == 'quoting' && can('update', 'observations')"
              v-bind="supplierCurrent"
              @submit="
                ({ values }) =>
                  onSaveSolution(row, { ...values, status: 'initial-work' })
              "
            >
              <template
                #default="{
                  onSubmit,
                  fields: { supplierCurrent: current, dateWork },
                }"
              >
                <div class="col-span-2 md:col-span-10 flex flex-col gap-4">
                  <VInput
                    classLabel="!text-sm font-semibold"
                    :modelValue="row.supplierCurrent"
                    v-bind="{
                      ...current,
                      attr: {
                        label: 'name',
                        type: 'select',
                        options: row.supplier,
                        reduce: (i) => i.id,
                        rules: 'required',
                      },
                      calculatePosition: withPopper,
                    }"
                    name="supplierCurrent"
                  />
                  <div class="flex gap-4">
                    <VInput
                      class="flex-grow"
                      classLabel="!text-sm font-semibold"
                      :modelValue="row.dateWork"
                      v-bind="dateWork"
                      name="dateWork"
                    />
                    <VTooltip
                      class="flex whitespace-nowrap"
                      text="Faltan cotizaciones por cargar"
                      :show="validSuppler"
                    >
                      <VButton
                        :disabled="validSuppler"
                        @click="onSubmit"
                        class="mt-2.5 font-semibold"
                        bgColor="bg-blue-500"
                        text="Inicar obra"
                      />
                    </VTooltip>
                  </div>
                </div>
              </template>
            </VForm>
            <div
              v-if="row.status == 'quoting' && !can('update', 'observations')"
              class="flex flex-col gap-4 leading-relaxed text-base font-semibold"
            >
              <p>No se ha asigando una fecha de inicio de obra</p>
            </div>
          </template>
          <template
            v-if="
              ['initial-work', 'finish-work', 'solved', 'finished'].includes(
                row.status
              )
            "
          >
            <template v-if="!row.observation_solved">
              <div class="flex justify-between gap-4 items-center">
                <div class="font-semibold text-base">
                  Fecha de inicio de la obra
                </div>
                <div
                  class="text-base font-bold text-blue-500 flex gap-1 items-center"
                >
                  <VButton
                    bgColor="bg-transparent"
                    textColor="text-blue-500"
                    size="lg"
                    :icon="faCalendarAlt"
                  />
                  <span>{{ date(row.dateWork) }}</span>
                </div>
              </div>
              <hr class="border-t border-gray-200 my-3" />
              <h2 class="text-lg font-semibold">Observaciones del proveedor</h2>
              <template v-if="row.observations && row.observations.length">
                <template
                  v-for="(item, index) in row.observations"
                  :key="`observations-${index}-${item.id}`"
                >
                  <div class="flex flex-col gap-4 p-4 rounded-lg bg-blue-50">
                    <div
                      class="text-base font-bold text-blue-500 flex gap-3 items-center"
                    >
                      <VButton
                        class="!rounded-full border border-current"
                        bgColor="bg-blue-500"
                        textColor="text-white"
                        size="sm"
                        :icon="faExclamation"
                      />
                      <span>{{ date(row.date) }}</span>
                    </div>
                    <div>
                      {{ row.observation }}
                    </div>
                  </div>
                </template>
              </template>
              <div v-else>
                <div class="flex flex-col gap-4 p-4 rounded-lg bg-gray-50">
                  <div>No hay observaciones registradas</div>
                </div>
              </div>
              <hr class="border-t border-gray-200 my-3" />
              <VForm
                v-if="
                  'initial-work' == row.status && can('update', 'observations')
                "
                class="col-span-2"
                ref="supplier-observations"
                v-bind="observationSupplier"
                @submit="
                  async ({ values }) => {
                    await onSaveSolution(row, values, 'observations');
                    $refs['supplier-observations'].onResetForm();
                  }
                "
              >
                <template #default="{ onSubmit, fields }">
                  <div class="flex gap-5 col-span-10">
                    <VInput
                      class="w-1 flex-grow"
                      classLabel="!text-sm font-semibold"
                      v-bind="fields.date"
                      name="date"
                    />
                    <VButton
                      @click="onSubmit"
                      class="mt-2.5"
                      bgColor="bg-green-500"
                      size="lg"
                      title="Guardar"
                      :icon="faSave"
                    />
                  </div>
                  <VInput
                    classLabel="!text-sm font-semibold"
                    v-bind="fields.observation"
                    name="observation"
                  />
                </template>
              </VForm>
            </template>
            <template v-else>
              <hr class="border-t border-gray-200 my-3" />
              <div class="flex flex-col gap-4 leading-relaxed">
                <h2 class="text-lg font-semibold">Observacione</h2>
                <p>{{ row.observation_solved }}</p>
              </div>
              <hr class="border-t border-gray-200 my-3" />
            </template>
            <VForm
              v-if="
                row.status == 'finish-work' && can('update', 'observations')
              "
              v-bind="solution"
              @submit="
                ({ values }) =>
                  onSaveSolution(row, { ...values, status: 'solved' })
              "
            >
              <template #default="{ onSubmit, fields }">
                <div class="col-span-2 md:col-span-10 flex flex-col gap-4">
                  <div class="flex gap-4">
                    <VInput
                      classLabel="!text-sm font-semibold"
                      v-bind="{
                        ...fields.date_solution,
                        width: 'flex-grow',
                        attr: {
                          ...fields.date_solution.attr,
                          min: row.date_problem,
                        },
                      }"
                      name="date_solution"
                    />
                    <VButton
                      @click="onSubmit"
                      class="mt-2.5"
                      bgColor="bg-green-500"
                      size="lg"
                      title="Guardar"
                      :icon="faSave"
                    />
                  </div>
                  <VInput
                    classLabel="!text-sm font-semibold"
                    v-bind="fields.solution"
                    name="solution"
                  />
                </div>
              </template>
            </VForm>
            <div
              v-if="
                row.status == 'finish-work' && !can('update', 'observations')
              "
              class="flex flex-col gap-4 rounded-lg p-4 bg-green-50"
            >
              <div class="text-green-500 font-semibold text-base">
                Aun no se ha registrado una fecha y descripción de la solución
                realizada
              </div>
            </div>
            <div
              v-if="row.date_solution && row.solution"
              class="flex flex-col gap-4 rounded-lg p-4 bg-green-50"
            >
              <div
                class="text-base font-bold text-green-500 flex gap-3 items-center"
              >
                <VButton
                  class="!rounded-full border border-current"
                  bgColor="bg-green-500"
                  textColor="text-white"
                  size="sm"
                  :icon="faCheck"
                />
                <span>{{
                  row.date_solution ? date(row.date_solution) : "----"
                }}</span>
              </div>
              <div>
                {{ row.solution || "----" }}
              </div>
            </div>

            <VLoader
              v-if="row.status != 'initial-work'"
              :show="mediaOverlay"
              class="flex"
            >
              <div class="w-1 flex-grow">
                <VFilesUpload
                  :columns="5"
                  :hideDelete="!can('delete', 'observations')"
                  :hideUpload="!can('update', 'observations')"
                  :hideSelect="!can('delete', 'observations')"
                  :modelValue="row['images_solution']"
                  :pendint="images['solution'].pendint"
                  :progress="images['solution'].progress"
                  :image="(img) => onFilterURL(img)"
                  :tools="['finish-work', 'solved'].includes(row.status)"
                  :fullImage="(img) => onFilterURL(img, '', img.format)"
                  @onChange="onUploadFiles($event, row, 'solution')"
                  @onDelete="onDeleteImage($event, row.id, 'solution')"
                  @onDeleteMulti="onDeleteImages($event, row.id, 'solution')"
                />
              </div>
            </VLoader>
            <template v-if="['solved', 'finished'].includes(row.status)">
              <hr class="border-t border-gray-200 my-3" />
              <VForm
                v-if="row.status != 'finished' && can('update', 'observations')"
                v-bind="responsible"
                @submit="({ values }) => onSaveSolution(row, values)"
              >
                <template #default="{ onSubmit, fields: { responsible } }">
                  <div class="col-span-2 md:col-span-10 flex flex-col gap-4">
                    <div class="flex gap-4">
                      <VInput
                        classLabel="!text-sm font-semibold"
                        :modelValue="row.responsible"
                        v-bind="responsible"
                        name="responsible"
                      />
                      <VButton
                        @click="onSubmit"
                        class="mt-2.5"
                        bgColor="bg-green-500"
                        size="lg"
                        title="Guardar"
                        :icon="faSave"
                      />
                    </div>
                  </div>
                </template>
              </VForm>
              <div v-else class="flex gap-4 justify-between md:text-base">
                Responsable de pago:
                <VBadge
                  v-if="row.responsible"
                  v-bind="onResponsible(row.responsible)"
                />
                <span v-else>----</span>
              </div>
              <template v-if="row.responsible && customers[row.responsible]">
                <hr class="border-t border-gray-200 my-3" />
                <h2 class="text-lg font-semibold">Propietario</h2>
                <div class="grid md:grid-cols-5 gap-4">
                  <figure
                    v-if="row.proprietorSignature"
                    class="md:col-span-2 relative bg-white border-2 border-dashed border-gray-200 rounded"
                  >
                    <img
                      :src="row.proprietorSignature"
                      class="mx-auto aspect-[250/150] object-contain object-center"
                    />
                  </figure>
                  <VMessage class="md:col-span-2" v-else> Sin firma </VMessage>
                  <div class="flex flex-col gap-1 md:col-span-3">
                    <div class="text-lg font-semibold mb-2">
                      {{ customers[row.responsible]?.fullName }}
                    </div>
                    <ul class="flex flex-col gap-1">
                      <li><b>Nit:</b> {{ customers[row.responsible]?.nit }}</li>
                      <li>
                        <b>Cel:</b> {{ customers[row.responsible]?.cellphone }}
                      </li>
                      <li>
                        <b>Email:</b> {{ customers[row.responsible]?.email }}
                      </li>
                    </ul>
                  </div>
                </div>
                <template v-if="!row.observation_solved">
                  <hr class="border-t border-gray-200 my-3" />
                  <h2 class="text-lg font-semibold">Proveedor</h2>
                  <div class="grid md:grid-cols-5 gap-4" v-if="supplierRow">
                    <figure
                      v-if="row.supplierSignature"
                      class="md:col-span-2 relative bg-white border-2 border-dashed border-gray-200 rounded"
                    >
                      <img
                        :src="row.supplierSignature"
                        class="mx-auto aspect-[250/150] object-contain object-center"
                        alt=""
                      />
                    </figure>
                    <VMessage class="md:col-span-2" v-else>
                      Sin firma
                    </VMessage>
                    <div class="flex flex-col gap-1 md:col-span-3">
                      <div class="text-lg font-semibold mb-2">
                        {{ supplierRow.name }}
                      </div>
                      <ul class="flex flex-col gap-1">
                        <li><b>Cel:</b> {{ supplierRow.phone }}</li>
                      </ul>
                    </div>
                  </div>
                  <template v-if="row.leased_state == 'leased'">
                    <hr class="border-t border-gray-200 my-3" />
                    <h2 class="text-lg font-semibold">Encargado autorizado</h2>
                    <div class="grid md:grid-cols-5 gap-4">
                      <figure
                        v-if="row.tenantSignature"
                        class="md:col-span-2 relative bg-white border-2 border-dashed border-gray-200 rounded"
                      >
                        <img
                          :src="row.tenantSignature"
                          class="mx-auto aspect-[250/150] object-contain object-center"
                        />
                      </figure>
                      <VMessage class="md:col-span-2" v-else>
                        Sin firma
                      </VMessage>
                      <div
                        v-if="row.tenant"
                        class="flex flex-col gap-1 md:col-span-3"
                      >
                        <div class="text-lg font-semibold mb-2">
                          {{ row.tenant.name }}
                        </div>
                        <ul class="flex flex-col gap-1">
                          <li><b>Nit:</b> {{ row.tenant.nit }}</li>
                          <li><b>Cel:</b> {{ row.tenant.cellphone }}</li>
                        </ul>
                      </div>
                      <VMessage class="col-span-3" v-else>
                        Encargado autorizado
                      </VMessage>
                    </div>
                  </template>
                </template>
              </template>
            </template>
          </template>
        </div>
      </VLoader>
      <template #footer>
        <div class="flex gap-3 justify-between">
          <div class="flex gap-2">
            <VButton
              :disabled="overlay"
              text="Cerrar"
              bgColor="bg-blue-500"
              textColor="text-white"
              size="sm"
              @click="modal.show = false"
            />
            <VButton
              v-if="
                ['reception', 'quoting'].includes(row.status) &&
                can('update', 'observations')
              "
              :disabled="overlay"
              text="Cancelar"
              @click="onCanceled"
              bgColor="bg-transparent"
              textColor="text-red-500"
              class="border-2 border-current font-semibold"
              size="sm"
            />
          </div>
          <template v-if="row.status != 'canceled'">
            <template
              v-if="
                ['finished', 'solved'].includes(row.status) &&
                row.responsible &&
                row.solution &&
                row.date_solution
              "
            >
              <div class="flex gap-4">
                <VDropdown
                  position="top"
                  :blurClose="false"
                  :disabled="
                    overlay || !row.responsible || !row.images_solution?.length
                  "
                >
                  <template #default>
                    <VButton
                      tag="span"
                      :disabled="
                        overlay ||
                        !row.responsible ||
                        !row.images_solution?.length
                      "
                      text="Generar enlaces"
                      bgColor="bg-teal-500"
                    />
                  </template>
                  <template #options="{ className }">
                    <VCopyClipboard
                      :class="className"
                      title="Generar enlace de propietaro"
                      :textCopy="
                        onLinkGenerate(
                          {
                            id: route.params.id,
                            obs: row.id,
                            customer: 'propietario',
                          },
                          row
                        )
                      "
                    >
                      Propietario
                    </VCopyClipboard>
                    <template v-if="!row.observation_solved">
                      <VCopyClipboard
                        :class="className"
                        title="Generar enlace de proveedor"
                        :textCopy="
                          onLinkGenerate(
                            {
                              id: route.params.id,
                              obs: row.id,
                              customer: 'proveedor',
                            },
                            row
                          )
                        "
                      >
                        Proveedor
                      </VCopyClipboard>
                      <VCopyClipboard
                        :class="className"
                        v-if="row.leased_state == 'leased'"
                        title="Generar enlace de enrcargado autorizado"
                        :textCopy="
                          onLinkGenerate(
                            {
                              id: route.params.id,
                              obs: row.id,
                              customer: 'encargado-autorizado',
                            },
                            row
                          )
                        "
                      >
                        Encargado autorizado
                      </VCopyClipboard>
                    </template>
                  </template>
                </VDropdown>
              </div>
            </template>

            <template v-if="can('update', 'observations')">
              <VTooltip
                class="flex whitespace-nowrap"
                v-if="'reception' == row.status"
                text="Debes cargar los documentos de evidencia"
                :show="!row['images_problem']?.length"
              >
                <VButton
                  :disabled="overlay || !row['images_problem']?.length"
                  text="Cotizar"
                  @click="onStatus(row, { status: 'quoting' })"
                  bgColor="bg-orange-500"
                  textColor="text-white"
                  size="sm"
                />
              </VTooltip>
              <VButton
                v-if="['reception'].includes(row.status)"
                :disabled="overlay || !row['images_problem']?.length"
                text="Solucionado"
                @click="onSolved"
                bgColor="bg-teal-500"
                size="sm"
              />
              <VButton
                v-if="'initial-work' == row.status"
                :disabled="overlay"
                text="Obra finalizada"
                @click="onStatus(row, { status: 'finish-work' })"
                bgColor="bg-indigo-500"
                textColor="text-white"
                size="sm"
              />
            </template>
          </template>
        </div>
      </template>
    </VModal>
    <VForm :showSubmit="false" :disabledCols="true" @submit="status.submit">
      <template #default="{ onSubmit }">
        <VModal v-model="status.show" v-bind="status">
          <VLoader :show="overlay">
            <div
              class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
            >
              <fa-icon
                class="text-5xl md:text-7xl"
                :class="status.style"
                :icon="status.icon"
              ></fa-icon>
              <p class="font-semibold" :class="status.style">
                {{ status.message }}
              </p>
              <div>
                <VInput
                  classLabel="!text-sm font-semibold"
                  v-bind="{
                    label: 'Observación',
                    outline: true,
                    attr: {
                      type: 'textarea',
                      rules: 'required',
                    },
                  }"
                  v-model="status.input"
                  :name="status.field"
                />
              </div>
              <p class="opacity-75 text-sm">
                <i
                  >(Esta acción no se puede revertir despues de haberse
                  ejecutado)</i
                >
              </p>
            </div>
          </VLoader>
          <template #footer>
            <div class="flex gap-3 justify-between">
              <VButton
                :disabled="overlay"
                text="Cerrar"
                bgColor="bg-red-500"
                @click="status.show = false"
              />
              <VButton
                :disabled="overlay"
                text="Continuar"
                @click="onSubmit"
                bgColor="bg-blue-500"
              />
            </div>
          </template>
        </VModal>
      </template>
    </VForm>
  </div>
</template>
<script setup>
import {
  faPlus,
  faCalendarAlt,
  faSave,
  faClose,
  faCheckCircle,
  faCircleXmark,
  faCheck,
  faBroom,
  faSort,
  faExclamation,
} from "@fortawesome/free-solid-svg-icons";
import { reactive, ref, computed, watch, onMounted, inject } from "vue";
import { getProduct, updateProduct } from "@/mixins/MixinProducts";
import { getObservationsTypes, observationsTypes } from "@/mixins/MixinOptions";
import { onFilterURL } from "@/assets/js/filters";

import VMessage from "@/components/VMessage.vue";
import VInput from "@/components/VForm/VInput";
import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VTable from "@/components/VTable";
import VForm from "@/components/VForm/VForm";
import VLoader from "@/components/VLoader";
import VPagination from "@/components/VPagination";
import VBadge from "@/components/VBadge";
import VFilesUpload from "@/components/VFilesUpload";
import VModal from "@/components/VModal";
import VTooltip from "@/components/VTooltip.vue";
import VDropdown from "@/components/VDropdown.vue";
import VCopyClipboard from "@/components/VCopyClipboard.vue";

// import { clearString } from "@/assets/js/filters";
import { withPopper } from "@/assets/js/utils";
import { useAbility } from "@casl/vue";
const { can } = useAbility();

import { useRoute, useRouter } from "vue-router";
const route = useRoute();
const router = useRouter();

import {
  date,
  onLeasedState,
  onObservationStatus,
  onResponsible,
} from "@/assets/js/filters";

import $axios from "@/assets/js/axios";
import axios from "axios";

import { useToast } from "vue-toastification";
const toast = useToast();

const observations = ref([]);
const customers = reactive({
  proprietor: null,
  leaseholder: null,
});
const overlay = ref(false);
const formObservations = ref(null);
const items = ref([]);

const current = ref(null);
const row = computed(() =>
  observations.value.find(({ id }) => id == current.value)
);
const supplierRow = computed(() =>
  row.value.supplier.find((item) => item.id == row.value.supplierCurrent)
);

const modal = reactive({
  show: false,
  aside: "right",
  footer: true,
  overlay: false,
});

const onObservationDetail = async ({ id }) => {
  current.value = id;
  Object.assign(modal, {
    show: true,
  });
};

const leased_state = ref(["initial", "delivery", "leased", "finished"]);
const menu = reactive([
  { name: "Todos", to: { name: "inventory-obervations" } },
  {
    name: "Inicial",
    to: { name: "inventory-obervations", query: { leased_state: "initial" } },
  },
  {
    name: "Entrega",
    to: { name: "inventory-obervations", query: { leased_state: "delivery" } },
  },
  {
    name: "Alquilado",
    to: { name: "inventory-obervations", query: { leased_state: "leased" } },
  },
]);

const pages = reactive({
  current: 1,
  perPage: 9,
  select: {
    notInherit: true,
    hiddeValidate: true,
    outline: true,
    attr: {
      type: "select",
      clearable: false,
      options: [9, 18, 50],
    },
  },
});

watch(
  () => items.value,
  () => {
    pages.current = 1;
  }
);

const pagination = computed(() => {
  const start = (pages.current - 1) * pages.perPage;
  const end = start + pages.perPage;

  return {
    pages: Math.ceil(items.value.length / pages.perPage),
    start,
    end,
  };
});

const totalItems = computed(() => {
  return {
    current:
      pagination.value.start + pages.perPage > items.value.length
        ? items.value.length
        : pagination.value.start + pages.perPage,
    total: items.value.length,
  };
});

const rows = computed(() => {
  return items.value.slice(pagination.value.start, pagination.value.end);
});

const table = reactive({
  rows: rows,
  thead: false,
  columns: [
    {
      field: "real-state",
      label: "Inmueble",
      class: "flex-grow",
      hiddenLabel: true,
    },
  ],
});

const leasedState = ref(null);

const problem = reactive({
  showSubmit: false,
  fields: {
    title: {
      notInherit: true,
      outline: true,
      width: "col-span-1 md:col-span-3",
      label: "Titulo",
      attr: {
        label: "name",
        type: "select",
        options: observationsTypes,
        reduce: (i) => i.name,
        rules: "required",
      },
      value: null,
    },
    code: {
      notInherit: true,
      outline: true,
      width: "col-span-1",
      label: "Código",
      attr: {
        type: "text",
      },
      value: null,
    },
    date_problem: {
      notInherit: true,
      outline: true,
      width: "col-span-1",
      label: "Fecha del problema",
      attr: {
        type: "date",
        rules: "required",
      },
      value: null,
    },
    problem: {
      notInherit: true,
      outline: true,
      width: "md:col-end-4 md:col-start-2 md:row-start-2 md:row-end-4 ",
      label: "Problema",
      attr: {
        rows: 5,
        type: "textarea",
        rules: "required",
      },
      value: null,
    },
  },
});

const supplier = reactive({
  showSubmit: false,
  fields: {
    name: {
      notInherit: true,
      outline: true,
      label: "Nombre",
      attr: {
        type: "text",
        rules: "required",
      },
      modifires: {
        capitalize: true,
      },
      value: null,
    },
    phone: {
      notInherit: true,
      outline: true,
      label: "Teléfono",
      attr: {
        type: "text",
        rules: "required",
      },
      value: null,
    },
    date: {
      notInherit: true,
      outline: true,
      label: "Fecha de revisión",
      attr: {
        type: "date",
        rules: "required",
      },
      value: null,
    },
  },
});

const supplierCurrent = reactive({
  showSubmit: false,
  fields: {
    supplierCurrent: {
      notInherit: true,
      outline: true,
      width: "flex-grow",
      label: "Proveedor",
      value: null,
    },
    dateWork: {
      notInherit: true,
      outline: true,
      label: "Fecha de inicio",
      attr: {
        type: "date",
        rules: "required",
      },
      value: null,
    },
  },
});

const validSuppler = computed(() =>
  row.value.supplier.map((item) => Boolean(item.doc?.length)).includes(false)
);

const observationSupplier = reactive({
  showSubmit: false,
  fields: {
    date: {
      notInherit: true,
      outline: true,
      label: "Fecha",
      attr: {
        type: "date",
        rules: "required",
      },
      value: null,
    },
    observation: {
      notInherit: true,
      outline: true,
      label: "Observacíon",
      attr: {
        type: "textarea",
        rules: "required",
      },
      value: null,
    },
  },
});

const solution = reactive({
  showSubmit: false,
  fields: {
    date_solution: {
      notInherit: true,
      outline: true,
      width: "cols-span-1",
      label: "Fecha del solución",
      attr: {
        type: "date",
        rules: "required",
      },
      value: null,
    },
    solution: {
      notInherit: true,
      outline: true,
      width: "col-end-4 col-start-2 row-start-1 row-end-3 ",
      label: "Solución",
      attr: {
        rows: 5,
        type: "textarea",
        rules: "required",
      },
      value: null,
    },
  },
});

const options = computed(() => {
  let result = [];
  if (row.value) {
    result = [
      {
        name: "Inmobiliaria",
        value: "realState",
      },
      {
        name: "Propietario",
        value: "proprietor",
      },
    ];

    if (row.value.leased_state == "leased")
      result.push({
        name: "Arrendatario",
        value: "leaseholder",
      });
  }

  return result;
});

const responsible = reactive({
  showSubmit: false,
  fields: {
    responsible: {
      notInherit: true,
      outline: true,
      width: "flex-grow",
      label: "Responsable de pago",
      attr: {
        label: "name",
        type: "select",
        clearable: false,
        options,
        reduce: (i) => i.value,
        calculatePosition: withPopper,
        rules: "required",
      },
      value: null,
    },
  },
});

const filtersProducts = reactive({
  code: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Código",
    attr: {
      type: "text",
    },
    value: null,
  },
  title: {
    notInherit: true,
    outline: true,
    width: "md:col-span-4",
    label: "Titulo",
    attr: {
      label: "name",
      type: "select",
      options: observationsTypes,
      reduce: (i) => i.name,
    },
    value: null,
  },
  status: {
    notInherit: true,
    outline: true,
    width: "md:col-span-4",
    label: "Estado",
    attr: {
      label: "label",
      type: "select",
      options: [
        { label: "Recepción", key: "reception" },
        { label: "Cotizando", key: "quoting" },
        { label: "Obra inicial", key: "initial-work" },
        {
          label: "Obra Finalizada",
          key: "finish-work",
        },
        { label: "Solucionado", key: "solved" },
        { label: "Finalizado", key: "finished" },
        { label: "Cancelado", key: "canceled" },
      ],
      reduce: (i) => i.key,
    },
    value: null,
  },
  date_problem_from: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-6 lg:col-span-3",
    label: "Problema desde",
    attr: {
      type: "date",
    },
    value: null,
  },
  date_problem_to: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-6 lg:col-span-3",
    label: "Problema hasta",
    attr: {
      type: "date",
    },
    value: null,
  },
  date_solution_from: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-6 lg:col-span-3",
    label: "Solución desde",
    attr: {
      type: "date",
    },
    value: null,
  },
  date_solution_to: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-6 lg:col-span-3",
    label: "Solución hasta",
    attr: {
      type: "date",
    },
    value: null,
  },
});

const filterState = ref(false);
const onToggleFilters = () => {
  filterState.value = !filterState.value;
};

const onClearFilters = () => {
  for (let prop in filtersProducts) {
    filtersProducts[prop].value = null;
  }
};

const onSetFilters = () => {
  return observations.value.filter((item) => {
    const res = [];
    let prop = "";
    if (!route?.query?.leased_state) res.push(true);
    else if (leased_state.value.includes(route.query.leased_state))
      res.push(item.leased_state == route.query.leased_state);

    for (let f in filtersProducts) {
      let value = filtersProducts[f].value;
      if (value) {
        switch (f) {
          case "code":
            res.push(item[f].includes(value));
            break;
          case "date_problem_from":
          case "date_solution_from":
            prop = f.replace("_from", "");
            res.push(Date.parse(item[prop]) >= Date.parse(value));
            break;
          case "date_problem_to":
          case "date_solution_to":
            prop = f.replace("_to", "");
            res.push(Date.parse(item[prop]) <= Date.parse(value));
            break;
          default:
            res.push(item[f] == value);
        }
      }
    }

    return !res.includes(false);
  });
};

for (let prop in filtersProducts) {
  watch([() => filtersProducts[prop].value, () => route.query], () => {
    items.value = onSetFilters();
  });
}

watch(
  [() => observations.value, () => route.query],
  () => {
    items.value = onSetFilters();
  },
  { deep: true }
);

const onCreateObservation = async ({ values }) => {
  overlay.value = true;

  const result = await updateProduct(
    {
      observations: {
        ...values,
        leased_state: leasedState.value,
        id: Date.now(),
      },
    },
    route.params.id
  );

  if (result) {
    result.data.observations.sort((a, b) =>
      a.id > b.id ? -1 : a.id < b.id ? 1 : 0
    );
    observations.value = result.data.observations;
  }

  formObservations.value.onResetForm();

  overlay.value = false;
};

const onSaveSolution = async (row, value, list) => {
  overlay.value = true;
  const data = { ...row, ...value };
  if (list) {
    const v = { ...value, id: Date.now() };
    Object.assign(data, {
      [list]: row[list]
        ? [...row[list], { ...v, doc: [] }]
        : [{ ...v, doc: [] }],
    });
  } else {
    Object.assign(data, value);
  }

  const result = await updateProduct({ observations: data }, route.params.id);
  if (result) {
    result.data.observations.sort((a, b) =>
      a.id > b.id ? -1 : a.id < b.id ? 1 : 0
    );
    observations.value = result.data.observations;
  }

  overlay.value = false;
};

const title = inject("title");

const mediaOverlay = ref(false);
const images = reactive({
  problem: {
    count: 0,
    progress: 0,
    pendint: 0,
    total: [],
    loading: false,
  },
  solution: {
    count: 0,
    progress: 0,
    pendint: 0,
    total: [],
    loading: false,
  },
});

const onUploadFiles = async ({ values, target }, row, type) => {
  images[type].pendint += values.length;
  images[type].total = [...images[type].total, ...values];

  if (!images[type].loading) {
    images[type].count = 0;
    images[type].loading = true;
    do {
      try {
        const { data: sing } = await $axios.get(
          `auth/product-media/${route.params.id}/${row.id}`
        );

        const { cloud_name } = sing;

        const data = new FormData();
        const formData = {
          file: images[type].total[images[type].count],
          ...sing,
        };
        for (let key in formData) data.append(key, formData[key]);

        const url = `https://api.cloudinary.com/v1_1/${cloud_name}/auto/upload`;

        const {
          data: { public_id, resource_type, format },
        } = await axios({
          method: "post",
          url,
          data,
          onUploadProgress: ({ progress: pgss }) => {
            images[type].progress = pgss;
          },
        });

        const result = await updateProduct(
          {
            observations: {
              ...row,
              [`images_${type}`]: { public_id, resource_type, format },
            },
          },
          route.params.id
        );
        if (result) {
          result.data.observations.sort((a, b) =>
            a.id > b.id ? -1 : a.id < b.id ? 1 : 0
          );
          observations.value = result.data.observations;
        }

        images[type].progress = 0;
        images[type].count++;
        images[type].pendint--;
      } catch (e) {
        console.error(e);
        if (e.response.data) toast.error(e.response.data.message);
        images[type].progress = 0;
        images[type].pendint = 0;
        images[type].count++;
        break;
      }
    } while (images[type].count < images[type].total.length);
    target.value = null;
    images[type].total = [];
    images[type].loading = false;
  }
};

const onUploadDocs = async ({ values, target }, row, item) => {
  item.pendint += values.length;
  item.total = [...values];
  item.progress = 0;
  item.pendint = 0;
  item.count = 0;

  if (!item.loading) {
    item.count = 0;
    item.loading = true;
    overlay.value = true;
    do {
      try {
        const { data: sing } = await $axios.get(
          `auth/product-media/${route.params.id}/${row.id}`
        );

        const { cloud_name } = sing;

        const data = new FormData();
        console.log(item.total[item.count], item.total)
        const formData = {
          file: item.total[item.count],
          ...sing,
        };
        for (let key in formData) data.append(key, formData[key]);

        const url = `https://api.cloudinary.com/v1_1/${cloud_name}/auto/upload`;

        const {
          data: { public_id, resource_type, format },
        } = await axios({
          method: "post",
          url,
          data,
          onUploadProgress: ({ progress: pgss }) => {
            item.progress = pgss;
          },
        });

        const result = await updateProduct(
          {
            observations: {
              ...row,
              supplier: row.supplier.map((sp) => {
                if (sp.id == item.id) {
                  Object.assign(sp, {
                    loading: false,
                    doc: [{ public_id, resource_type, format }],
                  });
                }
                return sp;
              }),
            },
          },
          route.params.id
        );
        if (result) {
          result.data.observations.sort((a, b) =>
            a.id > b.id ? -1 : a.id < b.id ? 1 : 0
          );
          observations.value = result.data.observations;
        }

        item.progress = 0;
        item.count++;
        item.pendint--;
      } catch (e) {
        console.error(e);
        console.log("catch while");
        if (e.response.data) toast.error(e.response.data.message);

        break;
      }
    } while (item.count < item.total.length);
    console.log("end while")
    target.value = null;
    item.total = [];
    item.loading = false;
    overlay.value = false;
  }
};

const onDeleteImage = async (image, id, type, supplier) => {
  mediaOverlay.value = true;
  try {
    const {
      data: { observations: result, message },
    } = await $axios({
      method: "delete",
      url: `auth/observation-media/${route.params.id}/${id}/${type}`,
      data: { image, supplier },
    });

    if (result) {
      result.sort((a, b) => (a.id > b.id ? -1 : a.id < b.id ? 1 : 0));
      observations.value = result;
    }

    toast.success(message);
  } catch (e) {
    const { data } = e.response;
    toast.error(data.message);
  }
  mediaOverlay.value = false;
};

const onDeleteImages = async (images, id, type) => {
  mediaOverlay.value = true;
  try {
    const {
      data: { observations: result, message },
    } = await $axios({
      method: "delete",
      url: `auth/observation-medias/${route.params.id}/${id}/${type}`,
      data: images,
    });

    if (result) {
      result.sort((a, b) => (a.id > b.id ? -1 : a.id < b.id ? 1 : 0));
      observations.value = result;
    }

    toast.success(message);
  } catch (e) {
    const { data } = e.response;
    toast.error(data.message);
  }
  mediaOverlay.value = false;
};

const status = reactive({
  show: false,
  title: "Cancelar observación",
  size: "xs",
  message: "Esta seguro que desea cancelar esta observación",
  footer: true,
  input: "",
  click: () => {},
});

const onStatus = async (row, value) => {
  await onSaveSolution(row, value);
  status.show = false;
};

const onCanceled = () => {
  Object.assign(status, {
    show: true,
    title: "Cancelar observación",
    size: "xs",
    message: "Esta seguro que desea cancelar esta observación",
    footer: true,
    input: "",
    style: "text-red-500",
    icon: faCircleXmark,
    field: "observation",
    submit: () =>
      onStatus(row.value, { status: "canceled", canceled: status.input }),
  });
};

const onSolved = () => {
  Object.assign(status, {
    show: true,
    title: "Solución de observación",
    size: "xs",
    message: "",
    footer: true,
    input: "",
    style: "text-teal-500",
    icon: faCheckCircle,
    field: "observation_solved",
    submit: () =>
      onStatus(row.value, {
        status: "finish-work",
        observation_solved: status.input,
      }),
  });
};

const onLinkGenerate = ({ id, obs, customer }, row) => {
  const { VUE_APP_DOMINE } = process.env;
  const password = `${row.id}-${row.date_solution.replace(/-/gi, "")}`;
  return `Enlace: ${VUE_APP_DOMINE}/observacion/${id}/${obs}/${customer}\nClave: ${password}`;
};

onMounted(async () => {
  const result = await getProduct(route.params.id);
  if (result) {
    if (!leased_state.value.includes(result.leased_state)) {
      router.push({ name: "inventory" });
      return;
    }

    result.observations.sort((a, b) =>
      a.id > b.id ? -1 : a.id < b.id ? 1 : 0
    );

    observations.value = result.observations;
    customers.proprietor = result.proprietor_data;
    customers.leaseholder = result.proprietor_data;

    title.setTitle("title", result.name);
    title.setTitle("subtitle", result.address);

    leasedState.value = result.leased_state;
    overlay.value = true;
    await getObservationsTypes();
    overlay.value = false;
  } else {
    router.push({ name: "inventory" });
  }
});
</script>
