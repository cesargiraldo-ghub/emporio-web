<template>
  <div class="flex flex-col gap-4 md:gap-10">
    <span
      class="md:hidden z-40 fixed backdrop-blur inset-0 w-full h-full transition duration-500 cursor-pointer"
      @click="onToggleFilters"
      :class="
        filterState ? 'pointer-events-auto' : 'opacity-0 pointer-events-none'
      "
    ></span>
    <VFieldset
      :border="false"
      class="!fixed max-h-[80vh] overflow-y-auto inset-x-0 bottom-0 md:!relative z-50 md:z-30 transition duration-500 md:translate-y-0 shadow"
      :class="{ 'translate-y-full': !filterState }"
    >
      <template #legend>
        <span class="text-xl font-medium text-red-600">Filtros</span>
        <VButton
          class="md:!hidden absolute left-5 bottom-full mb-5 z-50"
          bgColor="bg-violet-500"
          @click="onToggleFilters"
          title="Limpiar filtros"
          :icon="faSort"
        />
      </template>
      <template #tools>
        <VButton
          bgColor="bg-blue-500"
          @click="onClearFilters"
          title="Limpiar filtros"
          :icon="faBroom"
        />
      </template>
      <template #default>
        <div class="grid grid-cols-1 md:grid-cols-6 gap-4">
          <template
            v-for="(input, prop) in filtersProducts"
            :key="`input-filter-${prop}-${$.uid}`"
          >
            <VInput
              classLabel="!text-sm font-semibold"
              v-model="input.value"
              v-bind="input"
              :name="prop"
            />
          </template>
        </div>
      </template>
    </VFieldset>
    <ul class="flex flex-wrap divide-x divide-gray-400">
      <li
        v-for="(item, index) in menu"
        :key="`menu-item-${item.to?.query?.leased_state}-${index}`"
        class="text-xs md:text-sm flex-grow md:flex-grow-0"
      >
        <RouterLink
          :to="item.to"
          :class="[
            'px-4 py-2 font-semibold',
            (!leased_state.includes(route.query.leased_state) &&
              !item.to.query?.leased_state) ||
            (item.to.query?.leased_state == route.query.leased_state &&
              leased_state.includes(route.query.leased_state))
              ? 'text-red-500'
              : 'opacity-80',
          ]"
          >{{ item.name }}</RouterLink
        >
      </li>
    </ul>
    <VTableProducts
      ref="tableProducts"
      @reload="onReload"
      v-if="loaded"
      :items="items"
    ></VTableProducts>
  </div>
</template>
<script setup>
import { withPopper } from "@/assets/js/utils";
import { faBroom, faSort } from "@fortawesome/free-solid-svg-icons";
import { reactive, ref, computed, onMounted } from "vue";
import {
  productsData,
  productState,
  state,
  getProducts,
} from "@/mixins/MixinProductsData";
import {
  bussinessTypes,
  productsTypes,
  getBussinessTypes,
  getProductsTypes,
} from "@/mixins/MixinOptions";

import VInput from "@/components/VForm/VInput";
import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VTableProducts from "@/views/layout/VTableProducts";

import { clearString } from "@/assets/js/filters";

import { useRoute } from "vue-router";
const route = useRoute();

const items = computed(() =>
  productsData.value.filter((product) => {
    const res = [];
    
    if (!route?.query?.leased_state) res.push(true);
    else if (leased_state.value.includes(route.query.leased_state))
      res.push(product.leased_state == route.query.leased_state);

    for (let f in filtersProducts) {
      let value = filtersProducts[f].value;
      if (value) {
        switch (f) {
          case "address":
            res.push(
              clearString(product[f]).includes(clearString(value)) ||
                clearString(product["name"]).includes(clearString(value))
            );
            break;
          case "user":
            res.push(
              [product["second_user"]?.id, product["user"]?.id].includes(value)
            );
            break;
          default:
            res.push((product[f]?.id || product[f]) == value);
        }
      }
    }
    return !res.includes(false);
  })
);

const leased_state = ref(["available", "retired"]);
const menu = reactive([
  { name: "Todos", to: { name: "products-data" } },
  {
    name: "Disponible",
    to: { name: "products-data", query: { leased_state: "available" } },
  },
  {
    name: "Retirado",
    to: { name: "products-data", query: { leased_state: "retired" } },
  },
]);

const filtersProducts = reactive({
  address: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-4",
    label: "Nombre o Dirección",
    attr: {
      type: "text",
    },
    value: null,
  },
  bussiness_type: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-2",
    label: "Tipo de establecimiento",
    attr: {
      label: "name",
      type: "select",
      options: bussinessTypes,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  product_type: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-2",
    label: "Tipo de inmueble",
    attr: {
      label: "name",
      type: "select",
      options: productsTypes,
      reduce: (i) => i.id,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  state: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-2",
    label: "Estado de fisico",
    attr: {
      label: "label",
      type: "select",
      options: state.options,
      reduce: (i) => i.key,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
  product_state: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-2",
    label: "Clasificación ",
    attr: {
      label: "label",
      type: "select",
      options: productState.options,
      reduce: (i) => i.key,
      calculatePosition: withPopper,
      appendToBody: true,
    },
    value: null,
  },
});

const filterState = ref(false);
const onToggleFilters = () => {
  filterState.value = !filterState.value;
};

const onClearFilters = () => {
  for (let prop in filtersProducts) {
    filtersProducts[prop].value = null;
  }
};

const onReload = async (overlay) => {
  overlay.value = true;
  await getProducts();
  overlay.value = false;
};

const loaded = ref(false);
onMounted(async () => {
  await getBussinessTypes();
  await getProductsTypes();
  await getProducts();

  loaded.value = true;
});
</script>
