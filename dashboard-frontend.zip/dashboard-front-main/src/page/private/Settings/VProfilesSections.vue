<template>
  <VLoader :show="overlay">
    <div class="flex flex-col gap-5">
      <VForm
        v-if="can('create', 'settings')"
        @submit="onSave"
        :showSubmit="false"
        :disabledCols="true"
        :reset="true"
      >
        <template #default="{ onSubmit }">
          <VFieldset :border="false">
            <template #legend>
              <span class="text-lg font-medium text-red-600">
                <VInput
                  class="w-full bg-white"
                  v-bind="form.name"
                  name="name"
                />
              </span>
            </template>
            <template #tools>
              <VButton
                bgColor="bg-green-500"
                type="submit"
                :icon="faPlus"
                @click="onSubmit"
              ></VButton>
            </template>
            <template #default>
              <div class="flex flex-wrap gap-5">
                <VInput
                  class="w-full"
                  v-bind="form.productTypes"
                  name="productTypes"
                />
              </div>
            </template>
          </VFieldset>
        </template>
      </VForm>
      <VForm
        @submit="onSave($event, atmosphere)"
        :showSubmit="false"
        :disabledCols="true"
      >
        <template #default="{ onSubmit }">
          <template v-for="item in atmosphere" :key="`atmosphere-${item.id}`">
            <VFieldset :border="false">
              <template #legend>
                <span class="text-xl font-medium text-red-600">
                  <VInput
                    class="w-full bg-white"
                    v-bind="{
                      ...form.name,
                      attr: {
                        ...form.name.attr,
                        disabled: !can('update', 'settings'),
                      },
                    }"
                    :name="`name-${item.id}`"
                    v-model="item.name"
                  />
                </span>
              </template>
              <template #tools>
                <div
                  v-if="can('delete', 'settings')"
                  class="flex border border-gray-300 rounded bg-white items-center"
                >
                  <VButton
                    title="Remove"
                    class="flex-shrink-0"
                    bgColor="bg-transparent"
                    textColor="text-red-500"
                    :icon="faTrash"
                    @click="onDelete(item.id)"
                  />
                </div>
              </template>
              <template #default>
                <div class="flex flex-wrap gap-5">
                  <VInput
                    class="w-full"
                    v-bind="{
                      ...form.productTypes,
                      attr: {
                        ...form.productTypes.attr,
                        disabled: !can('update', 'settings'),
                      },
                    }"
                    :name="`productTypes-${item.id}`"
                    v-model="item.productTypes"
                  />
                </div>
              </template>
            </VFieldset>
          </template>
          <transition name="slide-right">
            <VWrapperStikcyBtn v-if="change && can('update', 'settings')">
              <VButton
                class="text-base font-medium"
                bgColor="bg-amber-500"
                text="Guardar cambios"
                @click="onSubmit"
              >
              </VButton>
            </VWrapperStikcyBtn>
          </transition>
        </template>
      </VForm>
    </div>
    <VModal v-model="destroy.show" v-bind="destroy">
      <VLoader :show="overlay">
        <div
          class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
        >
          <fa-icon
            class="text-red-500 text-5xl md:text-7xl"
            :icon="faCircleXmark"
          ></fa-icon>
          <p class="font-semibold text-red-500">
            {{ destroy.message }}
          </p>
          <p class="opacity-75 text-sm">
            <i
              >(Esta acción no se puede revertir despues de haberse
              ejecutado)</i
            >
          </p>
        </div>
      </VLoader>
      <template #footer>
        <div class="flex gap-3 justify-between">
          <VButton
            :disabled="overlay"
            text="Cerrar"
            bgColor="bg-gray-500"
            @click="destroy.show = false"
          />
          <VButton
            :disabled="overlay"
            text="Eliminar"
            @click="deleteRow(destroy.props)"
            bgColor="bg-red-500"
          />
        </div>
      </template>
    </VModal>
  </VLoader>
</template>

<script setup>
import {
  faPlus,
  faTrash,
  faCircleXmark,
} from "@fortawesome/free-solid-svg-icons";
import { ref, reactive, onMounted, watch } from "vue";
import {
  atmosphere,
  getAtmosphere,
  updateAtmosphere,
  createAtmosphere,
  deleteAtmosphere,
} from "@/mixins/MixinOptions";
import { productsTypes, getProductsTypes } from "@/mixins/MixinOptions";

import VFieldset from "@/components/VFieldset";
import VButton from "@/components/VButton";
import VForm from "@/components/VForm/VForm";
import VInput from "@/components/VForm/VInput";
import VLoader from "@/components/VLoader";
import VModal from "@/components/VModal";
import VWrapperStikcyBtn from "@/components/VWrapperStikcyBtn";

import { useAbility } from "@casl/vue";
const { can } = useAbility();

const overlay = ref(false);
const form = reactive({
  name: {
    hiddeValidate: true,
    outline: true,
    attr: {
      placeholder: "Crear ambiente",
      type: "text",
      rules: "required",
    },
  },
  productTypes: {
    hiddeValidate: true,
    outline: true,
    label: "Tipo de inmueble",
    attr: {
      type: "check",
      reduce: ({ id }) => id,
      options: productsTypes,
      label: "name",
      rules: "required|minLength:1",
    },
    value: [],
  },
});

const onSave = async ({ values }, data) => {
  overlay.value = true;

  if (data) await updateAtmosphere(data);
  else await createAtmosphere(values);

  change.value = false;
  overlay.value = false;
};

const destroy = reactive({
  show: false,
  title: "Elminar ambiente",
  type: "retired",
  size: "xs",
  message: "",
  footer: true,
  overlay: true,
  props: {},
});

const deleteRow = async ({ id }) => {
  overlay.value = true;
  const res = await deleteAtmosphere(id);
  if (res) {
    Object.assign(destroy, {
      show: false,
    });
  }
  overlay.value = false;
};

const onDelete = async (id) => {
  Object.assign(destroy, {
    show: true,
    message: "Esta seguro que quiere eliminar este ambiente.",
    props: { id },
  });
};

const change = ref(false);

watch(
  () => atmosphere.value,
  (a, b) => {
    if (b.length && a.length == b.length) {
      change.value = true;
    }
  },
  { deep: true }
);

onMounted(async () => {
  overlay.value = true;
  await getProductsTypes();
  await getAtmosphere();
  overlay.value = false;
});
</script>

<style lang="scss" scoped></style>
