<template>
  <VLoader :show="overlay">
    <VForm v-bind="form" @submit="onSaveForm">
      <template #default="{ onSubmit, fields }">
        <VFieldset class="col-span-2 md:col-span-10 mt-20" :border="false">
          <template #default>
            <div class="px-3 pb-3 grid grid-cols-6 gap-6 items-end">
              <div class="-mt-20 col-span-3 md:col-span-2 lg:col-span-1">
                <VLoader class="shadow rounded" :show="photo.overlay">
                  <VImageUpload
                    :widthFull="true"
                    @onDelete="deletePhoto"
                    @update:modelValue="uploadPhoto"
                    @onLoad="photo.overlay = false"
                    :image="photo.value?.url"
                    v-model="photo.value"
                  ></VImageUpload>
                </VLoader>
              </div>
              <template v-for="(input, prop) in fields" :key="`input-${prop}`">
                <VInput
                  v-if="input.attr.type != 'textarea'"
                  v-model="input.value"
                  :name="prop"
                  v-bind="input"
                />
                <div
                  v-else
                  class="col-span-6 flex flex-col flex-shrink-0 h-[500px]"
                >
                  <div
                    class="flex flex-wrap gap-2 py-5 border-t border-stone-200"
                  >
                    <VBadge
                      v-for="(item, prop) in variables"
                      :key="`variable-${prop}-${$.uid}`"
                      @change="onChange"
                      v-bind="item"
                      :name="prop"
                    />
                  </div>
                  <QuillEditor
                    toolbar="essential"
                    @ready="onReady"
                    theme="snow"
                    v-model:content="input.value"
                    contentType="html"
                  ></QuillEditor>
                </div>
              </template>
            </div>
          </template>
        </VFieldset>
        <VFieldset class="col-span-1 md:col-span-2" :border="false">
          <div class="flex flex-wrap gap-y-2 gap-x-3 font-semibold">
            <label class="w-full">Canales de atención</label>
            <VFilesUpload
              :columns="1"
              :modelValue="manual.value"
              :pendint="manual.pendint"
              :multiple="false"
              :progress="manual.progress"
              :image="(img) => onFilterURL(img)"
              :fullImage="(img) => onFilterURL(img, '', img.format)"
              @onChange="onUploadDoc($event, 'manual', manual)"
              @onDelete="onDeleteDoc('manual')"
            />
          </div>
        </VFieldset>
        <VFieldset class="col-span-1 md:col-span-2" :border="false">
          <div class="flex flex-wrap gap-y-2 gap-x-3 font-semibold">
            <label class="w-full">Tratamiento de datos</label>
            <VFilesUpload
              :columns="1"
              :modelValue="policy.value"
              :pendint="policy.pendint"
              :multiple="false"
              :progress="policy.progress"
              :image="(img) => onFilterURL(img)"
              :fullImage="(img) => onFilterURL(img, '', img.format)"
              @onChange="onUploadDoc($event, 'policy', policy)"
              @onDelete="onDeleteDoc('policy')"
            />
          </div>
        </VFieldset>
        <div
          class="sticky flex lg:hidden justify-end bottom-0 md:bottom-5 col-span-2 z-20"
        >
          <VButton
            class="text-lg font-medium w-full md:w-auto justify-center"
            bgColor="bg-green-500"
            text="Guardar"
            @click="onSubmit"
          ></VButton>
        </div>
        <div
          class="hidden lg:block fixed bottom-4 right-4 z-10 rounded shadow-md border border-gray-200 bg-white p-4"
        >
          <VButton
            class="text-lg font-medium"
            bgColor="bg-green-500"
            text="Guardar"
            @click="onSubmit"
          ></VButton>
        </div>
      </template>
    </VForm>
  </VLoader>
</template>
<script setup>
import { reactive, onMounted, ref } from "vue";

import VImageUpload from "@/components/VImageUpload";
import VFieldset from "@/components/VFieldset";
import VForm from "@/components/VForm/VForm";
import VButton from "@/components/VButton";
import VInput from "@/components/VForm/VInput";
import VLoader from "@/components/VLoader";
import VBadge from "@/components/VBadge";
import VFilesUpload from "@/components/VFilesUpload";

import { QuillEditor } from "@vueup/vue-quill";
import "@vueup/vue-quill/dist/vue-quill.snow.css";

import $axios from "@/assets/js/axios";
import axios from "axios";
import { setValuesForm, onFilterURL } from "@/assets/js/filters";

import { bussiness, onSubmitBussiness } from "@/mixins/MixinSettings";

import { useStore } from "vuex";
const store = useStore();

import { useToast } from "vue-toastification";
const toast = useToast();

const overlay = ref(false);
const photo = reactive({
  label: "Foto",
  value: null,
  overlay: false,
});

const variables = reactive({
  leaseholder: {
    color: "text-indigo-500",
    label: "Arrendatario",
    options: [
      { key: "fullName", label: "Nombre" },
      { key: "nit", label: "CC" },
      { key: "cellphone", label: "Celular" },
    ],
  },
  property: {
    color: "text-indigo-500",
    label: "Inmueble",
    options: [
      { key: "fullName", label: "Nombre" },
      { key: "address", label: "Dirección" },
    ],
  },
  realState: {
    color: "text-indigo-500",
    label: "Inmobilirari",
    options: [
      { key: "fullName", label: "Nombre" },
      { key: "nit", label: "Nit" },
      { key: "email", label: "Email" },
      { key: "cellphone", label: "Celular" },
      { key: "website", label: "Sitio Web" },
    ],
  },
});

const form = reactive({
  showSubmit: false,
  fields: {
    name: {
      notInherit: true,
      label: "Nombre de la Empresa",
      width: "col-span-6 md:col-span-4 lg:col-span-3",
      attr: {
        type: "text",
      },
      value: null,
    },
    nit: {
      notInherit: true,
      label: "Nit",
      width: "col-span-6 md:col-span-3 lg:col-span-2",
      attr: {
        type: "text",
      },
      value: null,
    },
    email: {
      notInherit: true,
      label: "Email",
      width: "col-span-6 md:col-span-3 lg:col-span-2",
      attr: {
        type: "text",
      },
      value: null,
    },
    cellphone: {
      notInherit: true,
      label: "Celular",
      width: "col-span-6 md:col-span-3 lg:col-span-2",
      attr: {
        type: "text",
      },
      value: null,
    },
    website: {
      notInherit: true,
      label: "Sitio Web",
      width: "col-span-6 md:col-span-3 lg:col-span-2",
      attr: {
        type: "text",
      },
      value: null,
    },
    terms: {
      notInherit: true,
      label: "Terminos del acta de entrega",
      width: "col-span-6 md:col-span-6",
      attr: {
        type: "textarea",
      },
      value: null,
    },
  },
});

const onSaveForm = ({ fields }) => {
  const data = [];
  for (let prop in fields) data.push({ key: prop, value: fields[prop] });

  updateBussiness(data);
};

const setData = (data) => {
  photo.value = data?.photo;
  manual.value = data?.manual;
  policy.value = data?.policy;

  setValuesForm(form.fields, (prop) => data[prop]);
};

const onFetchBussiness = async (config) => {
  overlay.value = true;
  const { data: resutl, res, status } = await onSubmitBussiness(config);

  switch (status) {
    case 200:
      setData(resutl);
      if (config.method != "get") toast.success(res.message);
      break;
    default:
      toast.error(res.message);
  }

  overlay.value = false;
};

const updateBussiness = async (data) => {
  onFetchBussiness({
    url: "auth/settings-options",
    method: "patch",
    data,
  });
};

const getBussiness = async () => {
  if (Object.keys(bussiness.value).length > 2) {
    setData(bussiness.value);
  } else {
    await onFetchBussiness({
      url: "auth/settings-options",
      method: "get",
    });
  }
};

let quill = null;
const onReady = (arg) => {
  quill = arg;
};

const onInsert = (text) => {
  quill.focus();
  const { index, length } = quill.getSelection();

  if (length) quill.deleteText(index, length);

  quill.insertText(index, text, "bold", true);
};

const onChange = ({ key }) => {
  onInsert(`{{${key}}}`);
};

const uploadPhoto = async (file) => {
  photo.overlay = true;
  try {
    const { data: dataSing } = await $axios.post("auth/brand", photo.value);
    const { cloud_name, ...config } = dataSing;
    const url = `https://api.cloudinary.com/v1_1/${cloud_name}/image/upload`;

    const data = new FormData();
    const formData = { file, ...config };

    for (let prop in formData) data.append(prop, formData[prop]);

    const { data: res } = await axios.post(url, data, {
      "Content-Type": "multipart/form-data",
    });
    const { public_id, secure_url } = res;
    await onUploadFile({
      method: "put",
      url: "auth/brand",
      data: { public_id, url: secure_url },
    });
  } catch (e) {
    toast.error("Ha ocurrido un error inesperado intentelo más tarde");
  }
  photo.overlay = false;
};

const deletePhoto = async () => {
  photo.overlay = true;
  await onUploadFile({
    method: "delete",
    url: "auth/brand",
  });
  photo.overlay = false;
};

const onUploadFile = async (config) => {
  const { status, data: res } = await $axios(config).catch((e) => e.response);
  const data = {};
  switch (status) {
    case 200:
      for (let { key, value } of res.rows) data[key] = value;

      store.commit("SET_STATE", {
        data,
        prop: "bussiness",
        modules: "Settings",
      });
      setData(data);
      toast.success(res.message);
      break;
    default:
      toast.error("Ha ocurrido un error inesperado intentelo más tarde");
  }
};

const manual = reactive({
  pendint: 0,
  total: 0,
  loading: false,
  value: [],
});
const policy = reactive({
  pendint: 0,
  total: 0,
  loading: false,
  value: [],
});

const onUploadDoc = async ({ values, target }, key, item) => {
  item.pendint += values.length;
  if (!item.total) item.total = [];

  item.total = [...item.total, ...values];

  if (!item.loading) {
    item.count = 0;
    item.loading = true;
    overlay.value = true;
    do {
      try {
        const { data: sing } = await $axios.post(
          `auth/settings-docuemnt/${key}`
        );

        const { cloud_name } = sing;

        const data = new FormData();
        const formData = {
          file: item.total[item.count],
          ...sing,
        };
        for (let key in formData) data.append(key, formData[key]);

        const url = `https://api.cloudinary.com/v1_1/${cloud_name}/auto/upload`;

        const {
          data: { public_id, resource_type, format },
        } = await axios({
          method: "post",
          url,
          data,
          onUploadProgress: ({ progress: pgss }) => {
            item.progress = pgss;
          },
        });

        await onUploadFile({
          method: "put",
          url: `auth/settings-docuemnt/${key}`,
          data: [{ public_id, resource_type, format }],
        });

        item.progress = 0;
        item.count++;
        item.pendint--;
      } catch (e) {
        console.error(e);

        if (e.response.data) toast.error(e.response.data.message);

        item.progress = 0;
        item.pendint = 0;
        item.count++;
        break;
      }
    } while (item.count < item.total.length);
    target.value = null;
    item.total = [];
    item.loading = false;
    overlay.value = false;
  }
};

const onDeleteDoc = async (key) => {
  overlay.value = true;
  await onUploadFile({
    method: "delete",
    url: `auth/settings-docuemnt/${key}`,
  });
  overlay.value = false;
};

onMounted(async () => {
  await getBussiness();
});
</script>
<style lang="scss">
.ql-container {
  @apply flex-grow h-1;
}
.ql-editor {
  @apply leading-relaxed #{!important};
  ::before {
    @apply hidden #{!important};
  }
  a {
    @apply text-red-500 #{!important};
  }
  b,
  strong {
    @apply font-bold #{!important};
  }
  ul,
  ol {
    @apply pl-5 flex flex-col gap-2 marker:text-red-500 #{!important};
    li {
      @apply p-0 list-[inherit] #{!important};
    }
  }
  ul {
    @apply list-disc #{!important};
  }
  ol {
    @apply list-decimal #{!important};
  }
  & > * + * {
    @apply mt-5 #{!important};
  }
}
</style>
