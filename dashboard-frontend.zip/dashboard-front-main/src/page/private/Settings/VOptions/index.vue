<template>
  <VLoader :show="overlay" class="grid lg:grid-cols-2 gap-6">
    <VTableOptions
      title="Tipo de inmueble"
      :options="productsTypes"
      :onCreate="createProductsTypes"
      :onUpdate="updateProductsTypes"
      :onDelete="deleteProductsTypes"
    ></VTableOptions>
    <VTableOptions
      title="Tipo de observación"
      :options="observationsTypes"
      :onCreate="createObservationsTypes"
      :onUpdate="updateObservationsTypes"
      :onDelete="deleteObservationsTypes"
    ></VTableOptions>
  </VLoader>
</template>
<script>
export default {
  name: "VOptions",
};
</script>
<script setup>
import { ref, onMounted } from "vue";
import {
  productsTypes,
  getProductsTypes,
  createProductsTypes,
  updateProductsTypes,
  deleteProductsTypes,
  observationsTypes,
  getObservationsTypes,
  createObservationsTypes,
  updateObservationsTypes,
  deleteObservationsTypes,
} from "@/mixins/MixinOptions";

import VTableOptions from "./VTableOptions.vue";
import VLoader from "@/components/VLoader";

const overlay = ref(false);

onMounted(async () => {
  overlay.value = true;
  for (let onGet of [getProductsTypes, getObservationsTypes]) {
    await onGet();
  }
  overlay.value = false;
});
</script>
