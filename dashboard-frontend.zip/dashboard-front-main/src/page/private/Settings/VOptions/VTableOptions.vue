<template>
  <VFieldset :border="false">
    <template #legend>
      <VForm
        ref="createForm"
        v-bind="form"
        @submit="onCreateOption($event, onCreate)"
      >
        <template #default="{ fields }">
          <template v-for="(input, prop) in fields" :key="`input-${prop}`">
            <VInput
              extrasClass="text-base bg-white"
              :modelModifiers="input.modifires"
              :name="prop"
              v-bind="{
                ...input,
                attr: { ...input.attr, disabled: !$can('create', 'settings') },
              }"
            />
          </template>
        </template>
      </VForm>
    </template>
    <template #tools>
      <VButton
        v-if="$can('create', 'settings')"
        type="submit"
        @click="onSubmit"
        bgColor="bg-green-500"
        :icon="faPlus"
      />
    </template>
    <template #default>
      <VTable v-bind="table" :rows="options">
        <template #name="{ row }">
          <VForm
            :showSubmit="false"
            @submit="onUpdateOption($event, onUpdate)"
            class="w-full"
          >
            <template #default="{ onSubmit }">
              <div class="flex col-span-10 gap-4">
                <template v-if="row.ranking > 0">
                  <VInput
                    class="flex-grow bg-white"
                    :modelValue="row.id"
                    name="id"
                    :attr="{ type: 'hidden' }"
                  />
                  <VInput
                    class="flex-grow bg-white"
                    v-model.first="row.name"
                    name="name"
                    v-bind="{
                      ...form.fields.name,
                      attr: {
                        ...form.fields.name.attr,
                        disabled: !$can('create', 'settings'),
                      },
                    }"
                  />
                  <div class="flex gap-2">
                    <VButton
                      v-if="$can('update', 'settings')"
                      @click="onSubmit"
                      bgColor="bg-transparent"
                      textColor="text-emerald-500"
                      :icon="faSave"
                    />
                    <VButton
                      v-if="$can('delete', 'settings')"
                      @click="onDeleteOption(row.id, onDelete)"
                      bgColor="bg-transparent"
                      textColor="text-red-500"
                      :icon="faTrash"
                    />
                  </div>
                </template>
                <template v-else>
                  <span class="block py-1 px-3">
                    {{ row.name }}
                  </span>
                </template>
              </div>
            </template>
          </VForm>
        </template>
      </VTable>
    </template>
  </VFieldset>
</template>
<script setup>
import { ref, reactive, defineProps } from "vue";
import { faSave, faTrash, faPlus } from "@fortawesome/free-solid-svg-icons";

import VFieldset from "@/components/VFieldset";
import VForm from "@/components/VForm/VForm";
import VInput from "@/components/VForm/VInput";
import VTable from "@/components/VTable";
import VButton from "@/components/VButton";

const props = defineProps({
  title: {
    type: String,
    default: "Crear",
  },
  options: {
    type: Array,
    required: true,
  },
  onCreate: {
    type: Function,
    required: true,
  },
  onUpdate: {
    type: Function,
    required: true,
  },
  onDelete: {
    type: Function,
    required: true,
  },
});

const overlay = ref(false);
const table = reactive({
  thead: false,
  columns: [{ field: "name", label: "Nombre", hiddenLabel: true }],
});

const form = reactive({
  showSubmit: false,
  fields: {
    name: {
      outline: true,
      notInherit: true,
      attr: {
        type: "text",
        placeholder: props.title,
        rules: "required",
      },
      modifires: {
        first: true,
      },
    },
  },
});

const createForm = ref(null);
const onSubmit = () => {
  createForm.value.onSubmit();
};

const onCreateOption = async ({ values }, onCreate) => {
  overlay.value = true;
  await onCreate(values);
  createForm.value.onResetForm();
  overlay.value = false;
};

const onUpdateOption = async ({ values }, onUpdate) => {
  overlay.value = true;
  await onUpdate(values);
  overlay.value = false;
};

const onDeleteOption = async (id, onDelete) => {
  overlay.value = true;
  await onDelete(id);
  overlay.value = false;
};
</script>
