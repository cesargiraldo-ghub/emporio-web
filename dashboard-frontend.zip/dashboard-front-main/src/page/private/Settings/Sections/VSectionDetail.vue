<template>
  <VLoader :show="overlay">
    <template v-if="section">
      <VForm ref="form" :showSubmit="false" :disabledCols="true" @submit="onSaveSection">
        <template #default="{ onSubmit }">
          <VFieldset class="flex-grow" :border="false" :lazy="true">
            <template #legend>
              <h2 class="text-lg font-medium">Ambientes</h2>
            </template>
            <template #default>
              <VInput class="bg-white" v-model="section.atmosphere" :name="`${section.id}-section-atmosphere`"
                v-bind="formSection.atmosphere" />
            </template>
          </VFieldset>
          <VFieldset class="flex-grow" :border="false" :lazy="true">
            <template #legend>
              <div class="flex gap-4">
                <VInput extrasClass="text-base md:text-xl font-medium text-red-600 bg-white" v-bind="formSection.name"
                  v-model.first="section.name" :name="`${section.id}-section-name`" />
              </div>
            </template>
            <template #default>
              <div class="px-3 pb-3 flex flex-col">
                <div class="flex flex-wrap gap-3 items-center pb-3 mb-5 border-b border-gray-300">
                  <h2 class="text-sm md:text-lg font-medium">Atributos</h2>
                  <div class="flex flex-wrap gap-3 ml-auto" v-if="section?.attrs?.length">
                    <VButton @click="toggleSpan(collapse, section.attrs, 'attr')" bgColor="bg-transparent"
                      textColor="text-emerald-500" class="border-current border" :text="textSpan(collapse, section.attrs, 'attr')
                        ? 'Abrir todo'
                        : 'Cerrar todo'
                        " />
                  </div>
                </div>
                <template v-if="section?.attrs?.length">
                  <VueDraggable v-model="section.attrs" @change="onChange(section.attrs)" item-key="id"
                    class="w-full grid grid-cols-1 gap-9" handle=".gp-handle">
                    <template #item="{ element: attr, index: a }">
                      <div class="flex flex-col">
                        <VButton title="Crear conjunto" @click="addAttr(section.attrs, a, `${a}`)"
                          class="mb-4 mx-auto rounded-full" bgColor="bg-emerald-400" :icon="faPlus" />
                        <VFieldset border="border-2 border-emerald-300" :lazy="true">
                          <template #legend>
                            <VInput extrasClass="text-sm md:text-base font-medium" v-bind="formSection.name"
                              v-model.first="attr.name" :name="`${section.id}-${attr.id}-attr-name`" />
                          </template>
                          <template #tools>
                            <div class="flex border-2 border-emerald-300 rounded bg-white items-center">
                              <VButton title="Contraer" class="flex-shrink-0" bgColor="bg-transparent"
                                textColor="text-emerald-400" :icon="faAngleUp" @click="
                                  collapse[`${attr.id}-attr`] =
                                  !collapse[`${attr.id}-attr`]
                                  " :class="collapse[`${attr.id}-attr`]
                                    ? 'rotate-180'
                                    : 'rotate-0'
                                    " />
                              <VButton title="Clonar" class="flex-shrink-0" bgColor="bg-transparent"
                                textColor="text-emerald-400" :icon="faClone" @click="onClone(section.attrs, attr, a)" />
                              <VButton title="Mover" class="flex-shrink-0 !cursor-move gp-handle"
                                bgColor="bg-transparent" textColor="text-emerald-400" :icon="faArrows" />
                              <VButton title="Elminar" class="flex-shrink-0" bgColor="bg-transparent"
                                textColor="text-emerald-400" :icon="faTrash" @click="onRemove(section.attrs, a)" />
                            </div>
                          </template>
                          <template #default>
                            <div v-show="!collapse[`${attr.id}-attr`]" class="px-3 flex flex-col">
                              <div class="flex flex-wrap gap-3 items-center pb-3 mb-5 border-b border-gray-300">
                                <h2 class="text-sm md:text-lg font-medium">
                                  Opciones
                                </h2>
                                <div class="flex flex-wrap gap-3 ml-auto">
                                  <VButton @click="
                                    toggleSpan(
                                      collapse,
                                      attr.fields,
                                      `${attr.id}-field`
                                    )
                                    " bgColor="bg-transparent" textColor="text-blue-500" class="border-current border"
                                    :text="textSpan(
                                      collapse,
                                      attr.fields,
                                      `${attr.id}-field`
                                    )
                                      ? 'Abrir todo'
                                      : 'Cerrar todo'
                                      " />
                                </div>
                              </div>
                              <template v-if="attr?.fields?.length">
                                <VueDraggable v-model="attr.fields" @change="onChange(attr.fields)" item-key="id"
                                  class="w-full grid grid-cols-1 gap-5" handle=".attr-handle">
                                  <template #item="{ element: field, index: f }">
                                    <div class="flex flex-col">
                                      <VButton title="Crear campo" @click="addField(attr.fields, f, `${a}${f}`)"
                                        class="mx-auto rounded-full" bgColor="bg-blue-400" :icon="faPlus" />
                                      <VFieldset border="border-2 border-blue-300" :lazy="true">
                                        <template #legend>
                                          <VInput v-bind="formSection.name" v-model.first="field.name"
                                            :name="`${section.id}-${attr.id}-${a}-${field.id}-${f}-field-name`" />
                                        </template>
                                        <template #tools>
                                          <div class="flex border-2 border-blue-300 rounded bg-white items-center">
                                            <VButton title="Contraer" class="flex-shrink-0" bgColor="bg-transparent"
                                              textColor="text-blue-400" :icon="faAngleUp" @click="
                                                collapse[
                                                `${field.id}-${attr.id}-field`
                                                ] =
                                                !collapse[
                                                `${field.id}-${attr.id}-field`
                                                ]
                                                " :class="collapse[
                                                  `${field.id}-${attr.id}-field`
                                                ]
                                                  ? 'rotate-180'
                                                  : 'rotate-0'
                                                  " />
                                            <VButton title="Clonar" class="flex-shrink-0" bgColor="bg-transparent"
                                              textColor="text-blue-400" :icon="faClone" @click="
                                                onClone(
                                                  attr.fields,
                                                  field,
                                                  f,
                                                  a
                                                )
                                                " />
                                            <VButton title="Mover" class="flex-shrink-0 !cursor-move attr-handle"
                                              bgColor="bg-transparent" textColor="text-blue-400" :icon="faArrows" />
                                            <VButton title="Eliminar" class="flex-shrink-0" bgColor="bg-transparent"
                                              textColor="text-blue-400" :icon="faTrash"
                                              @click="onRemove(attr.fields, f)" />
                                          </div>
                                        </template>
                                        <template #default>
                                          <div v-show="!collapse[
                                            `${field.id}-${attr.id}-field`
                                          ]
                                            " class="grid md:grid-cols-4 gap-6 pb-5">
                                            <VInput width="md:col-span-2 md:row-start-1 md:row-end-3"
                                              v-bind="formSection.description" v-model.first="field.description"
                                              :name="`${section.id}-${attr.id}-${field.id}-field-description`" />
                                            <VInput width="col-span-1" :disabledCols="true" :disabled="!field.id"
                                              v-bind="formSection.parent" v-model="field.parent" :attr="{
                                                ...formSection.parent.attr,
                                                options: filterAttr(
                                                  attr,
                                                  field
                                                ),
                                              }" :name="`${section.id}-${attr.id}-${field.id}-field-parent`" />
                                            <VInput width="col-span-1" :disabledCols="true" :disabled="!field.id"
                                              v-bind="formSection.conditional" v-model="field.conditional" :attr="{
                                                ...formSection.conditional.attr,
                                                options: filterOptions(
                                                  attr,
                                                  field
                                                ),
                                              }" :name="`${section.id}-${attr.id}-${field.id}-field-conditional`" />
                                            <VInput width="md:col-start-3 md:col-end-5" v-bind="formSection.type"
                                              v-model="field.type"
                                              :name="`${section.id}-${attr.id}-${field.id}-field-type`" />
                                            <VInput width="md:col-span-4" :disabled="!['multi', 'unique'].includes(
                                              field.type
                                            )
                                              " v-bind="formSection.options" v-model="field.options"
                                              :name="`${section.id}-${attr.id}-${field.id}-field-options`" />
                                          </div>
                                        </template>
                                      </VFieldset>
                                    </div>
                                  </template>
                                </VueDraggable>
                              </template>
                              <template v-else>
                                <div class="p-5 bg-gray-100 rounded font-medium text-base">
                                  No hay opciones registrados
                                </div>
                              </template>
                              <VButton title="Crear campo" @click="
                                addField(attr.fields, attr.fields.length, `${a}${attr.fields.length}`)
                                " class="mt-4 mx-auto rounded-full" bgColor="bg-blue-400" :icon="faPlus" />
                            </div>
                          </template>
                        </VFieldset>
                      </div>
                    </template>
                  </VueDraggable>
                </template>
                <template v-else>
                  <div class="p-5 bg-gray-100 rounded font-medium text-base">
                    No hay atributos registrados
                  </div>
                </template>
                <VButton title="Crear conjunto"
                  @click="addAttr(section.attrs, section.attrs.length, `${section.attrs.length}`)"
                  class="mt-6 mx-auto rounded-full" bgColor="bg-emerald-400" :icon="faPlus" />
              </div>
            </template>
          </VFieldset>
          <transition name="slide-right">
            <VWrapperStikcyBtn class="col-span-1">
              <VButton class="text-lg font-medium" bgColor="bg-green-500" :text="route.params.id ? 'Guardar' : 'Crear'"
                @click="onSave(onSubmit)"></VButton>
              <VButton v-if="route.params.id" class="text-lg font-medium" bgColor="bg-blue-500" text="Guardar y salir"
                @click="onSaveExit(onSubmit)"></VButton>
            </VWrapperStikcyBtn>
          </transition>
        </template>
      </VForm>
    </template>
  </VLoader>
</template>
<script setup>
import { reactive, onMounted, computed, ref, watch } from "vue";
import {
  faPlus,
  faTrash,
  faArrows,
  faAngleUp,
  faClone,
} from "@fortawesome/free-solid-svg-icons";
import { createSection, updateSection } from "@/mixins/MixinSections";
import { atmosphere, getAtmosphere } from "@/mixins/MixinOptions";

import { useToast } from "vue-toastification";
const toast = useToast();

import { useStore } from "vuex";
const store = useStore();

import VFieldset from "@/components/VFieldset";
import VButton from "@/components/VButton";
import VLoader from "@/components/VLoader";
import VForm from "@/components/VForm/VForm";
import VInput from "@/components/VForm/VInput";
import VueDraggable from "vuedraggable";
import VWrapperStikcyBtn from "@/components/VWrapperStikcyBtn";
import { idSection } from "@/assets/js/filters";

import { useRoute, useRouter } from "vue-router";
const router = useRouter();
const route = useRoute();

const form = ref();
const overlay = ref(false);
const section = ref(null);

const formSection = reactive({
  name: {
    hiddeValidate: true,
    outline: true,
    attr: {
      placeholder: "Nombre",
      type: "text",
      rules: "required",
    },
  },
  atmosphere: {
    hiddeValidate: true,
    attr: {
      type: "check",
      multiple: true,
      options: atmosphere,
      reduce: (i) => i.id,
      rules: "required|minLength:1",
    },
  },
  description: {
    hiddeValidate: true,
    outline: true,
    label: "Descripción",
    attr: {
      type: "textarea",
      rows: "4",
    },
  },
  type: {
    hiddeValidate: true,
    outline: true,
    label: "Tipo",
    attr: {
      type: "select",
      clearable: false,
      label: "name",
      reduce: ({ value }) => value,
      options: [
        {
          name: "Valor unico",
          value: "unique",
        },
        {
          name: "Valor multiple",
          value: "multi",
        },
        {
          name: "Numerico",
          value: "number",
        },
        {
          name: "Texto corto",
          value: "short",
        },
        {
          name: "Texto largo",
          value: "long",
        },
      ],
    },
  },
  parent: {
    hiddeValidate: true,
    outline: true,
    label: "Regla",
    attr: {
      type: "select",
      label: "name",
      resetOnOptionsChange: (arr, _, [value]) =>
        value && typeof value == "object"
          ? !arr.find((item) => value?.id == item.id)
          : false,
      reduce: ({ id }) => id,
    },
  },
  conditional: {
    hiddeValidate: true,
    outline: true,
    label: "Condición",
    attr: {
      resetOnOptionsChange: (arr, _, [value]) => !arr.includes(value),
      type: "select",
    },
  },
  options: {
    hiddeValidate: true,
    outline: true,
    label: "Opciones",
    attr: {
      type: "tag",
    },
  },
});

const filterAttr = ({ fields }, attr) => {
  const group = fields.map((item) => ({ name: `${item.name}`, ...item }));
  return group.filter((item) => item.id != attr.id && item.id);
};

const filterOptions = ({ fields }, { parent }) => {
  return fields.filter((item) => item.id == parent)[0]?.options;
};

const collapse = ref({});

const textSpan = (collapse, items, sufix) => {
  return items?.find((item) => {
    const key = `${item.id}-${sufix}`;
    return collapse[key];
  });
};

const toggleSpan = (collapse, items, sufix) => {
  const result = textSpan(collapse, items, sufix);
  items.forEach((item) => {
    const key = `${item.id}-${sufix}`;
    collapse[key] = !result;
  });
};

const getSection = async (id) => {
  return await store.dispatch("getRow", {
    url: "auth/settings-section",
    id,
  });
};

const addAttr = (attrs, index, sufix) => {
  const position = attrs.length;
  attrs.splice(index, 0, {
    id: idSection(sufix),
    fields: [],
    name: null,
    position,
  });
};

const addField = (fields, index, sufix) => {
  const position = fields.length;
  console.log(idSection(sufix), fields, index, sufix)
  fields.splice(index, 0, {
    id: idSection(sufix),
    name: null,
    description: null,
    options: [],
    columns: "1",
    type: "unique",
    position,
  });
};

const onRemove = (elements, index) => {
  elements.splice(index, 1);
};

const onChange = (items) => {
  items.forEach((item, i) => {
    item.position = i;
  });
};

const exit = ref(false);
const onSaveSection = async () => {
  const { id } = route.params;
  overlay.value = true;
  try {
    if (id) {
      const { data } = await updateSection(section.value, id);

      if (exit.value) {
        router.push({ name: "setting-sections" });
        return;
      }

      section.value = data;
    } else {
      const { data } = await createSection(section.value);
      router.push({ name: "settings-section-edit", params: { id: data.id } });
    }
  } catch (e) {
    console.error(e);
  }

  overlay.value = false;
};

const save = ref(false);
const onSave = (onSubmit) => {
  save.value = true;
  onSubmit();
};

const onSaveExit = (onSubmit) => {
  save.value = true;
  exit.value = true;
  onSubmit();
};

const setSection = async () => {
  const { id } = route.params;

  if (id) {
    section.value = await getSection(id);

    if (!section.value) router.push({ name: "not-found" });
  } else {
    section.value = {
      name: null,
      attrs: [],
      position: route.query.position || 0,
    };
  }
};

watch(
  () => route.params,
  async ({ id }) => {
    if (id && route.name == "settings-section-edit") await setSection();
  },
  { deep: true }
);

const onClone = async (rows, row, index, attr) => {
  const element = structuredClone(row);
  element.name = element.name + " - Copia - " + (index + 1);

  element.id = Math.floor(index + Date.now() / 100000);

  if (attr) element.id += attr;

  rows.splice(index + 1, 0, element);
};

const errors = computed(() => form.value.errors);

onMounted(async () => {
  overlay.value = true;
  await getAtmosphere();
  await setSection();
  overlay.value = false;

  watch(
    () => errors.value,
    (a) => {
      if (Object.keys(a).length && save.value) {
        toast.error("Faltan campos por registrar");
        save.value = false;
      }
    }
  );
});
</script>
