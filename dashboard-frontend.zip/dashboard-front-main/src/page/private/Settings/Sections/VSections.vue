<template>
  <div class="flex flex-col gap-3">
    <VFieldset :border="false">
      <template #legend>
        <span class="text-xl font-medium text-red-600">Características</span>
      </template>
      <template #tools>
        <VButton
          bgColor="bg-blue-500"
          @click="onClearFilters"
          title="Limpiar filtros"
          :icon="faBroom"
        />
        <VButton
          bgColor="bg-green-500"
          v-if="can('create', 'settings')"
          :icon="faPlus"
          :to="{
            name: 'settings-section-create',
            query: {
              position: sections.length,
            },
          }"
        ></VButton>
      </template>
      <template #default>
        <div class="mb-6 flex flex-col gap-3">
          <VInput
            v-model="form.fields.name.value"
            v-bind="form.fields.name"
            name="name"
          />
          <VInput
            v-model="form.fields.atmosphere.value"
            v-bind="form.fields.atmosphere"
            name="atmosphere"
          />
        </div>
        <VLoader :show="overlay">
          <VTable
            v-bind="table"
            v-model="sections"
            @update:modelValue="changeState = true"
          >
            <template #name="{ row: { name, atmosphere: value } }">
              <div class="flex flex-col gap-2">
                <div class="flex flex-col gap-1 font-semibold text-base">
                  <span>{{ name }}</span>
                </div>
                <div v-if="value.length" class="flex flex-wrap gap-3">
                  <template
                    v-for="(i, index) in value"
                    :key="`productType-${i}-${index}-${$.uid}`"
                  >
                    <VBadge color="text-blue-500">
                      {{ getValueArrayJSON(atmosphere, "id", i)?.name }}
                    </VBadge>
                  </template>
                </div>
              </div>
            </template>
            <template #actions="{ row, index }">
              <div class="inline-flex flex-wrap gap-2">
                <VButton
                  v-if="can('update', 'settings')"
                  bgColor="bg-transparent"
                  textColor="text-emerald-500"
                  :icon="faClone"
                  title="Clonar"
                  @click="onClone(row, index)"
                />
                <VButton
                  v-if="can('update', 'settings')"
                  :to="{
                    name: 'settings-section-edit',
                    params: { id: row.id },
                  }"
                  bgColor="bg-transparent"
                  textColor="text-blue-500"
                  :icon="faPen"
                />
                <VButton
                  v-if="can('delete', 'settings')"
                  @click="onDelete(row.id)"
                  bgColor="bg-transparent"
                  textColor="text-red-500"
                  :icon="faTrash"
                />
              </div>
            </template>
          </VTable>
        </VLoader>
      </template>
    </VFieldset>
    <VModal v-model="destroy.show" v-bind="destroy">
      <VLoader :show="overlay">
        <div
          class="flex flex-col gap-4 text-sm md:text-base leading-relaxed text-center"
        >
          <fa-icon
            class="text-red-500 text-5xl md:text-7xl"
            :icon="faCircleXmark"
          ></fa-icon>
          <p class="font-semibold text-red-500">
            {{ destroy.message }}
          </p>
          <p class="opacity-75 text-sm">
            <i
              >(Esta acción no se puede revertir despues de haberse
              ejecutado)</i
            >
          </p>
        </div>
      </VLoader>
      <template #footer>
        <div class="flex gap-3 justify-between">
          <VButton
            :disabled="overlay"
            text="Cerrar"
            bgColor="bg-gray-500"
            @click="destroy.show = false"
          />
          <VButton
            :disabled="overlay"
            text="Eliminar"
            @click="deleteRow(destroy.props)"
            bgColor="bg-red-500"
          />
        </div>
      </template>
    </VModal>
    <transition name="slide-right">
      <VWrapperStikcyBtn v-if="changeState">
        <VButton
          class="text-base font-medium"
          bgColor="bg-amber-500"
          text="Guardar cambios"
          @click="onSaveChanges"
        >
        </VButton>
      </VWrapperStikcyBtn>
    </transition>
  </div>
</template>
<script setup>
import { useAbility } from "@casl/vue";
import {
  faPlus,
  faPen,
  faTrash,
  faBroom,
  faClone,
  faCircleXmark,
} from "@fortawesome/free-solid-svg-icons";
import {
  getSections,
  deleteSection,
  createSection,
} from "@/mixins/MixinSections";
import { reactive, onMounted, computed, ref } from "vue";
import { atmosphere, getAtmosphere } from "@/mixins/MixinOptions";
import { getValueArrayJSON, clearString } from "@/assets/js/filters";
import { sections } from "@/mixins/MixinSections";

import VTable from "@/components/VTable";
import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VLoader from "@/components/VLoader";
import VBadge from "@/components/VBadge";
import VInput from "@/components/VForm/VInput";
import VWrapperStikcyBtn from "@/components/VWrapperStikcyBtn";
import VModal from "@/components/VModal";

import { useStore } from "vuex";
const store = useStore();

const { can } = useAbility();
const overlay = ref(false);
const form = reactive({
  fields: {
    name: {
      hiddeValidate: true,
      outline: true,
      label: "Característica",
      attr: {
        type: "text",
      },
      value: "",
    },
    atmosphere: {
      hiddeValidate: true,
      outline: true,
      label: "Ambiente",
      attr: {
        type: "check",
        multiple: true,
        options: atmosphere,
        reduce: (i) => i.id,
      },
      value: [],
    },
  },
});

const rows = computed(() => {
  const result = sections.value.filter((section) => {
    const value = [];
    for (let key in form.fields) {
      if (Array.isArray(form.fields[key].value)) {
        for (let v of form.fields[key].value)
          value.push(section[key]?.includes(v));
      } else {
        value.push(
          clearString(section[key]).includes(
            clearString(form.fields[key].value)
          )
        );
      }
    }

    return !value.includes(false);
  });
  return result;
});

const table = reactive({
  rows,
  move: true,
  reverse: true,
  thead: false,
  columns: [
    // {field: "id", label: "ID"},
    { field: "name", label: "Nombre", hiddenLabel: true },
    {
      field: "actions",
      label: "Acciones",
      class: "text-right items-end justify-end flex-grow",
      hiddenLabel: true,
      can: [can("update", "users"), can("delete", "users")],
    },
  ],
});

const destroy = reactive({
  show: false,
  title: "Elminar sección",
  type: "retired",
  size: "xs",
  message: "",
  footer: true,
  overlay: true,
  props: {},
});

const deleteRow = async ({ id }) => {
  overlay.value = true;
  const res = await deleteSection(id);
  if (res) {
    Object.assign(destroy, {
      show: false,
    });
  }
  overlay.value = false;
};

const onDelete = async (id) => {
  Object.assign(destroy, {
    show: true,
    message: "Esta seguro que quiere eliminar esta sección.",
    props: { id },
  });
};

const onClearFilters = () => {
  for (let key in form.fields) {
    form.fields[key].value = Array.isArray(form.fields[key].value) ? [] : "";
  }
};

const changeState = ref(false);

const onSaveChanges = async () => {
  overlay.value = true;
  const data = sections.value.map(({ id, position }) => ({ id, position }));
  const { status } = await store.dispatch("updateRows", {
    url: "auth/settings-sections",
    prop: "sections",
    modules: "Settings",
    data,
  });
  overlay.value = false;

  switch (status) {
    case 200:
      changeState.value = false;
  }
};

const onClone = async (row, index) => {
  const section = structuredClone(row);
  delete section.id;
  section.position++;
  section.name = section.name + " - Copia - " + section.position;
  overlay.value = true;
  await createSection(section, index);
  overlay.value = false;
};

onMounted(async () => {
  overlay.value = true;
  await getSections();
  await getAtmosphere();
  overlay.value = false;
});
</script>
