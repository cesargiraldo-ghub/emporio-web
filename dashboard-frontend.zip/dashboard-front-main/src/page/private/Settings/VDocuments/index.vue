<template>
  <VLoader :show="overlay">
    <form @submit="onSubmit">
      <div class="col-span-2 md:col-span-10 flex flex-col gap-5">
        <VFieldset :border="false">
          <template #legend>
            <span class="text-xl font-medium text-red-600">Documento</span>
          </template>
          <template #default>
            <fieldset
              class="flex flex-col border border-gray-300 rounded onOutline"
            >
              <legend
                class="text-left z-10 relative px-3 ml-2 leading-[0] !text-sm font-semibold"
              >
                Tipo de inmueble
              </legend>
              <div class="relative">
                <select
                  name="productsType"
                  class="px-4 py-2.5 -mt-1 w-full"
                  v-model="select"
                >
                  <option value="null" disabled>
                    Seleccione un tipo de inmueble
                  </option>
                  <template
                    v-for="(item, index) in productsTypes"
                    :key="`productsType-${index}-${item.id}`"
                  >
                    <option :value="item.id" default>{{ item.name }}</option>
                  </template>
                </select>
              </div>
            </fieldset>
          </template>
        </VFieldset>
        <template v-if="select">
          <VFieldset :border="false">
            <template #legend>
              <span class="text-xl font-medium text-red-600">Opciones</span>
            </template>
            <template #default>
              <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-5">
                <template
                  v-for="(item, index) in options"
                  :key="`atmosphere-${index}-${item.id}`"
                >
                  <fieldset
                    class="flex flex-col border border-gray-300 rounded onOutline"
                  >
                    <legend
                      class="text-left z-10 relative px-3 ml-2 leading-[0] !text-sm font-semibold"
                    >
                      {{ item.name }}
                    </legend>
                    <div class="relative">
                      <select
                        :name="`atmosphere-${item.id}`"
                        class="px-4 py-2.5 -mt-1 w-full"
                        value="1"
                      >
                        <option value="null">0</option>
                        <template
                          v-for="i in 10"
                          :key="`atmosphere-option-${i}-${item.id}`"
                        >
                          <option :value="i" default>
                            {{ i }}
                          </option>
                        </template>
                      </select>
                    </div>
                  </fieldset>
                </template>
              </div>
            </template>
          </VFieldset>
          <div>
            <VButton type="submit" text="Crear documento"></VButton>
          </div>
        </template>
      </div>
    </form>
  </VLoader>
</template>
<script>
export default {
  name: "VDocuments",
};
</script>
<script setup>
import { onMounted, ref, computed } from "vue";
import VFieldset from "@/components/VFieldset";
import VLoader from "@/components/VLoader";
import VButton from "@/components/VButton";
import axios from "@/assets/js/axios";
import { useToast } from "vue-toastification";
import { onBlobToString } from "@/assets/js/filters";
import {
  productsTypes,
  getProductsTypes,
  atmosphere,
  getAtmosphere,
} from "@/mixins/MixinOptions";
import { getProduct } from "@/mixins/MixinProductsData";
import { useRoute } from "vue-router";
import router from "@/router";

const route = useRoute();
const routeId = computed(() => route.params.id);

const toast = useToast();

const select = ref(null);
const overlay = ref(false);

const options = computed(() =>
  atmosphere.value.filter((item) => item.productTypes.includes(select.value))
);

const onSubmit = async (e) => {
  overlay.value = true;
  e.preventDefault();
  const body = new FormData(e.target);
  const { status, data } = await axios
    .post(`auth/empty-document/${routeId.value}`, body, {
      responseType: "blob",
    })
    .catch((e) => e.response);
  let link = null;
  switch (status) {
    case 200:
      link = document.createElement("a");
      link.href = URL.createObjectURL(data);
      link.download = `plantilla-inventario-${new Date().valueOf()}.pdf`;
      link.click();
      toast.success("Documento generado");
      break;
    case 406:
      onBlobToString(data).then((res) => {
        toast.info(res.message);
      });
      break;
    default:
      onBlobToString(data).then((res) => {
        toast.error(res.message);
      });
  }
  overlay.value = false;
};

onMounted(async () => {
  await getAtmosphere();
  await getProductsTypes();

  const result = await getProduct(routeId.value);
  if (!result) {
    await router.push({ name: "not-found" });
    return;
  } else {
    select.value = result.productsType;
  }
});
</script>

<style lang="scss" scoped></style>
