<template>
  <div class="flex flex-col gap-4 md:gap-10">
    <VFieldset :border="false" class="relative shadow">
      <template #legend>
        <span class="text-xl font-medium text-red-600">Filtros</span>
      </template>
      <template #default>
        <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
          <template
            v-for="(field, prop) in filters"
            :key="`field-filter-${prop}-${$.uid}`"
          >
            <VInput
              classLabel="!text-sm font-semibold"
              v-model="field.value"
              v-bind="field"
              :name="`${prop}-${$.uid}`"
            />
          </template>
        </div>
      </template>
    </VFieldset>
    <VFieldset :border="false" :fixed-tools="true">
      <template #legend>
        <span v-if="title" class="text-xl font-medium text-red-600">{{
          title
        }}</span>
      </template>
      <template #tools>
        <VButton
          v-if="can('create', 'customers')"
          @click="createRow"
          bgColor="bg-green-500"
          :icon="faPlus"
        />
        <VButton
          v-if="can('export', 'customers')"
          @click="onExporCustomers"
          bgColor="bg-orange-500"
          :icon="faFileDownload"
        />
        <VButton
          v-if="can('import', 'customers')"
          @click="onModalImport"
          bgColor="bg-blue-500"
          :icon="faFileUpload"
        />
      </template>
      <template #default>
        <VLoader :show="overlay">
          <div class="flex flex-wrap xl:flex-nowrap gap-5 xl:mt-3">
            <VInput
              class="w-24"
              v-model="pages.perPage"
              @update:modelValue="pages.current = 1"
              v-bind="pages.select"
              name="perPage"
            />
            <div
              class="flex flex-col md:flex-row gap-5 w-full xl:w-auto flex-grow items-center"
            >
              <span class="my-auto xl:ml-auto font-semibold opacity-80">
                <span class="text-red-500">{{ totalItems.current }}</span> de
                {{ totalItems.total }} Inmuebles
              </span>
              <VPagination
                class="md:ml-auto"
                :pages="pagination.pages"
                v-model:current="pages.current"
              ></VPagination>
            </div>
          </div>
          <VTable
            class="my-4"
            v-bind="{ ...table, selected }"
            @rowSelected="rowSelected"
          >
            <template #rol="{ value }">
              {{ value.name }}
            </template>
            <template #customerType="{ value }">
              <div class="flex flex-wrap gap-3">
                <template
                  v-for="(i, index) in value"
                  :key="`customer-type-${i}-${index}-${$.uid}`"
                >
                  <VBadge :color="i == 1 ? 'text-purple-600' : 'text-rose-600'">
                    {{ getValueArrayJSON(customersTypes, "id", i)?.name }}
                  </VBadge>
                </template>
              </div>
            </template>
            <template #actions="{ row }">
              <div class="inline-flex flex-wrap gap-2">
                <VButton
                  v-if="can('update', 'customers')"
                  @click="updateRow(row)"
                  bgColor="bg-transparent"
                  textColor="text-blue-500"
                  :icon="faPen"
                />
              </div>
            </template>
          </VTable>
          <div
            class="flex flex-col items-center md:flex-row md:items-start gap-5"
          >
            <span class="md:mr-auto font-semibold opacity-80">
              <span class="text-red-500">{{ totalItems.current }}</span> de
              {{ totalItems.total }} Inmuebles
            </span>
            <VPagination
              :pages="pagination.pages"
              v-model:current="pages.current"
            ></VPagination>
          </div>
        </VLoader>
        <VModal v-model="modal.show" v-bind="modal">
          <VLoader :show="overlay">
            <VForm
              v-if="modal.type != 'import'"
              v-bind="formFields"
              @submit="onSubmit"
              ref="form"
            >
              <template #default="{ fields }">
                <template
                  v-for="(input, prop) in fields"
                  :key="`field_${prop}_${$.uid}`"
                >
                  <VInput
                    v-model="input.value"
                    :name="prop"
                    v-bind="input"
                    :modelModifiers="input.modifires"
                  />
                </template>
              </template>
            </VForm>
            <VForm v-else v-bind="formImport" @submit="onImportCustomers" />
          </VLoader>
          <template #footer>
            <div class="flex gap-3">
              <VButton
                :disabled="overlay"
                :text="modal.type == 'update' ? 'Guardar' : 'Crear'"
                bgColor="bg-green-500"
                @click="form.onSubmit()"
              />
              <VButton
                :disabled="overlay"
                text="Cerrar"
                bgColor="bg-blue-500"
                @click="modal.show = false"
              />
            </div>
          </template>
        </VModal>
      </template>
    </VFieldset>
  </div>
</template>
<script setup>
import { useAbility } from "@casl/vue";
import {
  faPlus,
  faPen,
  faFileDownload,
  faFileUpload,
} from "@fortawesome/free-solid-svg-icons";
import {
  computed,
  reactive,
  onMounted,
  ref,
  defineProps,
  defineEmits,
  defineExpose,
  watch,
} from "vue";
import {
  customers,
  getCustomers,
  createCustomer,
  updateCustomer,
  updateCustomersStore,
} from "@/mixins/MixinCustomers";
import { customersTypes, getCustomersTypes } from "@/mixins/MixinOptions";
import {
  getValueArrayJSON,
  onBlobToString,
  clearString,
} from "@/assets/js/filters";

import VButton from "@/components/VButton";
import VFieldset from "@/components/VFieldset";
import VForm from "@/components/VForm/VForm";
import VInput from "@/components/VForm/VInput";
import VLoader from "@/components/VLoader";
import VModal from "@/components/VModal";
import VTable from "@/components/VTable";
import VBadge from "@/components/VBadge";
import VPagination from "@/components/VPagination";

import axios from "@/assets/js/axios";

const { can } = useAbility();

import { useToast } from "vue-toastification";
const toast = useToast();

const emits = defineEmits(["rowSelected"]);
const props = defineProps({
  selected: {
    type: Boolean,
    default: false,
  },
  title: {
    type: String,
    default: "",
  },
  filter: {
    type: [String, Number],
    default: "",
  },
});

const overlay = ref(false);
const modal = reactive({
  show: false,
  title: null,
  size: "xs",
  aside: "right",
  overlay: true,
  type: null,
  id: null,
});

const formImport = reactive({
  textSubmit: "Subir",
  fields: {
    file: {
      label: "Documento",
      attr: {
        type: "file",
        accept: ".xlsx",
        rules: "required|ext:xlsx",
      },
    },
  },
});
const onModalImport = () => {
  Object.assign(modal, {
    show: true,
    title: "Importart Productos",
    type: "import",
    footer: false,
    aside: "",
    overlay: true,
  });
};

const filters = reactive({
  name: {
    outline: true,
    hiddeValidate: true,
    width: "md:col-span-12",
    label: "Nombre",
    attr: {
      type: "text",
    },
    value: null,
  },
});

// const items = computed(() => {
//   const result = customers.value.filter((customer) => {
//     return props.filter ? customer.customerType.includes(props.filter) : true;
//   });
//   return result;
// });

const items = computed(() =>
  customers.value.filter((customer) => {
    const res = [];

    for (let f in filters) {
      let value = filters[f].value;
      if (value) {
        if (f == "name") {
          res.push(
            clearString(`${customer["name"]}${customer["last"]}`).includes(
              clearString(value)
            )
          );
        }
      }
    }
    res.push(
      props.filter ? customer.customerType.includes(props.filter) : true
    );

    return !res.includes(false);
  })
);

const pages = reactive({
  current: 1,
  perPage: 9,
  select: {
    notInherit: true,
    hiddeValidate: true,
    outline: true,
    attr: {
      type: "select",
      clearable: false,
      options: [9, 18, 50],
    },
  },
});

watch(
  () => items.value,
  () => {
    pages.current = 1;
  }
);

const pagination = computed(() => {
  const start = (pages.current - 1) * pages.perPage;
  const end = start + pages.perPage;

  return {
    pages: Math.ceil(items.value.length / pages.perPage),
    start,
    end,
  };
});

const totalItems = computed(() => {
  return {
    current:
      pagination.value.start + pages.perPage > items.value.length
        ? items.value.length
        : pagination.value.start + pages.perPage,
    total: items.value.length,
  };
});

const rows = computed(() => {
  return items.value.slice(pagination.value.start, pagination.value.end);
});

const table = reactive({
  rows,
  columns: [
    { field: "name", label: "Nombre" },
    { field: "last", label: "Apellido" },
    { field: "nit", label: "CC" },
    { field: "email", label: "E-mail", class: "break-words" },
    { field: "customerType", label: "Tipo" },
    {
      field: "actions",
      label: "Acciones",
      class: "text-right items-end justify-end",
      hiddenLabel: true,
      can: [can("update", "customers"), can("delete", "customers")],
    },
  ],
});
const form = ref(null);
const formFields = reactive({
  showSubmit: false,
  fields: {
    customerType: {
      notInherit: true,
      label: "Tipo de cliente",
      width: "col-span-10",
      attr: {
        type: "check",
        multiple: true,
        reduce: (i) => i.id,
        cols: 2,
        options: customersTypes,
        rules: "required",
      },
      value: [],
    },
    name: {
      notInherit: true,
      label: "Nombres",
      width: "col-span-5",
      attr: {
        type: "text",
        rules: "required",
      },
      modifires: {
        capitalize: true,
      },
      value: null,
    },
    last: {
      notInherit: true,
      label: "Apellidos",
      width: "col-span-5",
      attr: {
        type: "text",
        rules: "required",
      },
      modifires: {
        capitalize: true,
      },
      value: null,
    },
    nit: {
      notInherit: true,
      label: "Numero de identificación",
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        numeric: true,
      },
      value: null,
    },
    email: {
      notInherit: true,
      label: "E-mail",
      width: "col-span-5",
      attr: {
        type: "email",
        rules: "required|email",
      },
      modifires: {
        lowercase: true,
      },
      value: null,
    },
    cellphone: {
      notInherit: true,
      label: "Celular",
      width: "col-span-5",
      attr: {
        type: "text",
        rules: "required|numeric",
      },
      modifires: {
        numeric: true,
      },
      value: null,
    },
  },
});

const onSubmit = async ({ values }) => {
  overlay.value = true;

  let state = false;
  const { type, id } = modal;

  switch (type) {
    case "create":
      state = await createCustomer(values);
      break;

    case "update":
      state = await updateCustomer(values, id);
      break;
  }

  overlay.value = false;
  if (state?.status == 200) {
    Object.assign(modal, {
      show: false,
      type: null,
    });
  }
};

const createRow = () => {
  setValuesForm(() => null);
  Object.assign(modal, {
    show: true,
    title: "Crear",
    type: "create",
    footer: true,
    aside: "right",
    overlay: true,
  });
};

const updateRow = ({ id, ...row }) => {
  setValuesForm((prop) => row[prop]?.id || row[prop]);
  Object.assign(modal, {
    show: true,
    title: "Actualizar",
    type: "update",
    footer: true,
    aside: "right",
    overlay: true,
    id,
  });
};

const setValuesForm = (callback) => {
  const inputsForm = formFields.fields;
  for (let prop in inputsForm) inputsForm[prop].value = callback(prop);
};

const onExporCustomers = async () => {
  overlay.value = true;
  await axios
    .get("auth/customers-documents", { responseType: "blob" })
    .then(({ data }) => {
      const href = window.URL.createObjectURL(data);

      const link = document.createElement("a");

      link.href = href;
      link.download = `${Date.now()}-clientes.xlsx`;
      link.click();

      window.URL.revokeObjectURL(href);

      toast.success("Archivo descargado");
    })
    .catch(({ response }) => {
      const { data } = response;
      onBlobToString(data).then((res) => {
        toast.error(res.message);
      });
    });
  overlay.value = false;
};

const onImportCustomers = async ({ values }) => {
  overlay.value = true;
  await axios
    .post("auth/customers-documents", values, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    })
    .then(({ data }) => {
      modal.show = false;
      updateCustomersStore(data.rows);
      toast.success("Archivo cargado");
    })
    .catch(({ response }) => {
      const { data } = response;
      toast.error(data.message);
    });
  overlay.value = false;
};

onMounted(async () => {
  overlay.value = true;
  await getCustomersTypes();
  await getCustomers();
  overlay.value = false;
});

const row = ref(null);
const rowSelected = (data) => {
  row.value = data;
  emits("rowSelected", Boolean(data));
};

const getRow = () => {
  return row.value;
};

defineExpose({ getRow });
</script>
