<template>
  <transition name="fade" mode="out-in">
    <div class="flex flex-col gap-5" :key="route.name">
      <VFieldset class="mt-9" :border="false">
        <template #tools>
          <VButton
            v-if="!routeId && profileUpdate"
            bgColor="bg-blue-500"
            :icon="faPen"
            @click="onUpdateProfile"
          />
        </template>
        <template #default>
          <div class="flex flex-col gap-5 items-start md:flex-row md:items-end">
            <!-- <div class="-mt-12 md:-mt-16">
              <VLoader class="shadow rounded" :show="photo.overlay">
                <VImageUpload v-if="!routeId" @onDelete="deletePhoto" @update:modelValue="uploadPhoto" @onLoad="photo.overlay = false" :image="profile.photo?.url" v-model="photo.value"></VImageUpload>
                <VImageUpload v-else v-bind="photo" :image="profile?.photo?.url" class="pointer-events-none"></VImageUpload>
              </VLoader>
            </div> -->
            <div class="relative flex-grow">
              <div class="flex flex-col">
                <span
                  class="block text-red-800 uppercase font-bold leading-none"
                  >{{ profile?.rol?.name }}</span
                >
                <h2
                  class="font-bold text-red-500 text-lg md:text-2xl lg:text-3xl mb-2.5 md:mb-4 leading-tight md:leading-none"
                >
                  {{ profile?.name }} {{ profile?.last }}
                </h2>
                <div class="flex flex-wrap gap-5">
                  <span class="block font-medium opacity-75 italic">
                    {{ profile?.nit }}
                  </span>
                  <div
                    v-if="profile?.cellphone || profile?.email"
                    class="flex flex-wrap gap-3 md:gap-10 opacity-75 lg:text-base items-end md:justify-end ml-auto"
                  >
                    <div
                      v-if="profile.cellphone"
                      class="flex gap-2 items-center"
                      title="Arrendatario"
                    >
                      <fa-icon
                        class="w-3 md:w-4 h-auto aspect-square text-indigo-400 inline-block"
                        :icon="faPhone"
                      ></fa-icon>
                      <span>
                        {{ profile.cellphone }}
                      </span>
                    </div>
                    <div
                      v-if="profile.email"
                      class="flex gap-2 items-center"
                      title="Arrendatario"
                    >
                      <fa-icon
                        class="w-3 md:w-4 h-auto aspect-square text-indigo-400 inline-block"
                        :icon="faEnvelope"
                      ></fa-icon>
                      <span>
                        {{ profile.email }}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </template>
      </VFieldset>
      <VTableProducts v-if="productsRead" v-bind="table" />
      <VModal
        v-if="!routeId && profileUpdate"
        v-model="modal.show"
        v-bind="modal"
      >
        <VLoader :show="overlay">
          <VForm v-bind="formFields" @submit="onSubmit" ref="form">
            <template #default="{ fields }">
              <template
                v-for="(input, prop) in fields"
                :key="`field_${prop}_${$.uid}`"
              >
                <VSignature
                  v-if="prop == 'signature'"
                  :importFile="true"
                  class="col-span-10"
                  v-model="input.value"
                ></VSignature>
                <VInput
                  v-else
                  v-model="input.value"
                  :name="prop"
                  v-bind="input"
                  :modelModifiers="input.modifires"
                />
              </template>
            </template>
          </VForm>
        </VLoader>
        <template #footer>
          <div class="flex gap-3">
            <VButton
              :disabled="overlay"
              text="Guardar"
              bgColor="bg-green-500"
              @click="form.onSubmit()"
            />
            <VButton
              :disabled="overlay"
              text="Cerrar"
              bgColor="bg-blue-500"
              @click="modal.show = false"
            />
          </div>
        </template>
      </VModal>
    </div>
  </transition>
</template>
<script setup>
import { ref, reactive, watch, computed, onMounted } from "vue";
import { faPhone, faEnvelope, faPen } from "@fortawesome/free-solid-svg-icons";
import { getUser, updateProfile } from "@/mixins/MixinUsers";

import $axios from "@/assets/js/axios";
// import axios from "axios"
import store from "@/store";

// import VImageUpload from "@/components/VImageUpload";
import VLoader from "@/components/VLoader";
import VFieldset from "@/components/VFieldset";
import VButton from "@/components/VButton";
import VModal from "@/components/VModal";
import VForm from "@/components/VForm/VForm";
import VInput from "@/components/VForm/VInput";
import VSignature from "@/components/VSignature";
import VTableProducts from "@/views/layout/VTableProducts";

import { useAbility } from "@casl/vue";
import { useToast } from "vue-toastification";

const { can } = useAbility();

const productsRead = computed(() => can("read", "products"));
const profileUpdate = computed(() => can("update", "profile"));

const toast = useToast();

import { useRoute } from "vue-router";

const route = useRoute();
const routeId = computed(() => route.params.id);

const userProfile = ref(null);
const table = reactive({
  items: [],
  tools: false,
  inventory: true,
});
const photo = reactive({
  label: "Foto",
  value: null,
  overlay: false,
});

const profile = computed(() =>
  routeId.value ? userProfile.value : store.state["Users"].user
);

const getUserProducts = async () => {
  let url = "auth/products-user";
  if (routeId.value) url += `/${routeId.value}`;

  const { status, data: res } = await $axios.get(url).catch((e) => e.response);
  switch (status) {
    case 200:
      table.items = res.rows;
      break;
    default:
      toast.error(res.message);
  }
};

// const uploadPhoto = async (file) => {
//   photo.overlay = true;
//   try {
//     const {data: dataSing} =  await $axios.post('auth/profile-photo', profile.value);
//     const {cloud_name, ...config} = dataSing;
//     const url =  `https://api.cloudinary.com/v1_1/${cloud_name}/image/upload`;

//     const data = new FormData();
//     const formData = {file, ...config};

//     for(let prop in formData)
//       data.append(prop, formData[prop]);

//     const {data: res} = await axios.post(url, data, {'Content-Type': 'multipart/form-data'})
//     const {public_id, secure_url} = res;
//     onPhoto({
//       method: 'put',
//       url: 'auth/profile-photo',
//       data: {public_id, url: secure_url}
//     });

//   }catch(e){
//     toast.error("Ha ocurrido un error inesperado intentelo más tarde");
//   }

//   photo.overlay = false;
// }

// const deletePhoto = async() => {
//   photo.overlay = true;
//   await onPhoto({
//     method: 'delete',
//     url: "auth/profile-photo"
//   });
//   photo.overlay = false;
// };

// const onPhoto = async (config) => {
//   const {status, data} = await $axios(config).catch(e => e.response);
//   switch(status){
//     case 200:
//       store.commit("SET_STATE", {
//         data: data.row,
//         prop: "user",
//         modules: "Users"
//       });
//       toast.success(data.message);
//       break;
//     default:
//       toast.error("Ha ocurrido un error inesperado intentelo más tarde");
//   }
// };

const modal = reactive({
  show: false,
  title: "Editar perfil",
  size: "xs",
  aside: "right",
  overlay: true,
});
const form = ref(null);
const overlay = ref(false);
const formFields = reactive({
  showSubmit: false,
  fields: {
    name: {
      notInherit: true,
      label: "Nombres",
      width: "col-span-5",
      modifires: {
        capitalize: true,
      },
      attr: {
        type: "text",
      },
    },
    last: {
      notInherit: true,
      label: "Apellidos",
      modifires: {
        capitalize: true,
      },
      width: "col-span-5",
      attr: {
        type: "text",
      },
    },
    cellphone: {
      notInherit: true,
      label: "Celular",
      width: "col-span-10",
      attr: {
        type: "text",
        rules: "numeric",
      },
      modifires: {
        numeric: true,
      },
    },
    signature: {
      notInherit: true,
      value: null,
    },
  },
});
const onSubmit = async ({ fields }) => {
  overlay.value = true;
  const res = await updateProfile(fields, profile.value.id);
  overlay.value = false;

  if (res.status == 200) {
    modal.show = false;
    store.commit("SET_STATE", {
      prop: "user",
      modules: "Users",
      data: res.data,
    });
  }
};

const onUpdateProfile = () => {
  setValuesForm((prop) => profile.value[prop]?.id || profile.value[prop]);
  modal.show = true;
};

const setValuesForm = (callback) => {
  const inputsForm = formFields.fields;
  for (let prop in inputsForm) inputsForm[prop].value = callback(prop);
};

watch(
  () => profile.value,
  async (a) => {
    photo.value = a?.photo;
    if (productsRead.value) await getUserProducts();
  }
);

onMounted(async () => {

  if (routeId.value) userProfile.value = await getUser(routeId.value);
  else Object.assign(photo, { value: profile.value?.photo });

  if (productsRead.value) await getUserProducts();

});
</script>
