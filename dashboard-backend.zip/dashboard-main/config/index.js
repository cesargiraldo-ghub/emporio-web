import * as dotenv from "dotenv";
dotenv.config();

export const {
  NODE_ENV,
  SERVER,
  HOST,
  HTTP,
  HTTPS,
  DB,
  DBPORT,
  DBUSER,
  DBPASS,
  ORIGIN,
  TOKEN_KEY,
  REFRESH_KEY,
  CLOUDINARY_NAME,
  AUTH_USER,
AUTH_PASS
} = process.env;
