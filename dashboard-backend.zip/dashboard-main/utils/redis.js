import redis from 'redis';
let redisClient = null;

(async () => {
    redisClient = redis.createClient();

    redisClient.on("error", (error) => {
    console.log(error);
    });
    redisClient.on("connect", () => {
    console.log("Redis connected!");
    });

    await redisClient.connect();
})();

export const setKey = async (iat, exp) => {
	try{
		const result = await redisClient.set(`jwt_${iat + exp}`, iat + exp,{
		  EX: 60 * (60 * 12),
		  NX: true
		});
		
		return Boolean(result);
	}catch(e){
		console.error(e);
	}
}

export const getKey = async (iat, exp) => {
	try{
		const result = await redisClient.get(`jwt_${iat + exp}`);
		return result;
	}catch(e){
		console.error(e);
	}
}

export const delKey = async (iat, exp) => {
	try{
		const result = await redisClient.del(`jwt_${iat + exp}`);
		return Boolean(result);
	}catch(e){
		console.error(e);	
	}
}

export default redisClient;