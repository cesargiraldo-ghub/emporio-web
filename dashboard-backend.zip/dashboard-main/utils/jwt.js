import { TOKEN_KEY } from "#config";
import jwt from "jsonwebtoken";
import * as Redis from "#utils/redis.js";

export const createToken = ({ id, email }) => {
  const token = jwt.sign({ email }, TOKEN_KEY, {
    expiresIn: 60 * (60 * 12),
    jwtid: `${id}`,
  });
  return { token };
};

export const getToken = async (req) => {
  const token = req.headers?.authorization?.split(" ");

  return req.headers.authorization && token[0] === "Bearer" ? token[1] : null;
};

export const isRevoked = async (req, { payload }) => {
  const { iat, exp } = payload;
  const result = await Redis.getKey(iat, exp);
  req.isRevoked = iat + exp == result;
};

export const onExpired = async (req, err) => {
  req.onExpired = err.inner.expiredAt < new Date();
};

export const authToken = (req, res, next) => {
  const { auth, isRevoked, onExpired } = req;
  if (auth && !isRevoked && !onExpired) {
    req.user_id = auth.jti;
    next();
  } else {
    res.sendStatus(401);
  }
};

export const authPublic = (req, res, next) => {
  const { auth, isRevoked, onExpired } = req;
  req.authPublic = auth && !isRevoked && !onExpired;
  next();
};

export const configJWT = {
  secret: TOKEN_KEY,
  getToken,
  isRevoked,
  onExpired,
  credentialsRequired: false,
  algorithms: ["HS256"],
};
