import puppeteer from "puppeteer";
import { CLOUDINARY_NAME } from "#config";

export const rowsToJSON = (rows) => {
  const result = {};
  for (let { key, value } of rows) result[key] = value;
  return result;
};
export const mapRols = (result) => {
  const rol = {
    rol: {
      id: result[0].rol_id,
    },
    modules: mapModules(result),
  };

  rol.modules.sort((a, b) => (a.id > b.id ? 1 : a.id < b.id ? -1 : 0));

  return rol;
};

export const mapModules = (result) => {
  const modules = [];

  for (let r of result) {
    let module_id = modules.find((i) => i.id == r.module_id);

    if (!module_id) {
      modules.push({
        id: r.module_id,
        alias: r.module_alias,
        permissions: [],
      });
    }

    if (modules.length) {
      for (let m of modules) {
        if (m.id == r.module_id) {
          let m_permissions = m.permissions;
          let permission_id = m.permissions.find(
            (i) => i.id == r.permission_id
          );

          if (!permission_id) {
            m_permissions.push({
              id: r.permission_id,
              alias: r.permission_alias,
            });
          }
        }
      }
    }
  }

  modules.sort((a, b) => (a.id > b.id ? 1 : a.id < b.id ? -1 : 0));

  return modules;
};

export const clearString = (strg) => {
  return strg
    .normalize("NFD")
    .replace(/[\u0300-\u036f-\s]/g, "")
    .toLowerCase();
};

export const clearWhiteSpace = (strg) => {
  return strg
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s/g, "-")
    .toLowerCase();
};

export const onResponsible = (key) => {
  switch (key) {
    case "propietario":
      return "proprietorSignature";
    case "proveedor":
      return "supplierSignature";
    case "encargado-autorizado":
      return "tenantSignature";
  }
};

export const createPDF = async (url, authorization) => {
  const browser = await puppeteer.launch({
    headless: "new",
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });
  const page = await browser.newPage();
  if (authorization) await page.setExtraHTTPHeaders({ authorization });

  await page.goto(url);
  const buffer = await page.pdf({
    format: "Legal",
    printBackground: true,
    margin: {
      top: 40,
      right: 40,
      bottom: 40,
      left: 40,
    },
  });
  browser.close();

  return buffer;
};

export const onFilterURL = (
  { public_id, resource_type },
  transform = "c_thumb,h_350,w_350/",
  format = "jpg"
) => {
  return `https://res.cloudinary.com/${CLOUDINARY_NAME}/${resource_type}/upload/${transform}${public_id}.${format}`;
};
