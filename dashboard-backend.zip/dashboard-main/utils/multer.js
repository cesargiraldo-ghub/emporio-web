import multer from "multer"
import {__dirname} from "#dirname"

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, `${__dirname}/uploads/`)
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + '-' + Date.now() + '-' + file.originalname);
  },
})

const Multer = multer({ storage }); 

export default Multer;