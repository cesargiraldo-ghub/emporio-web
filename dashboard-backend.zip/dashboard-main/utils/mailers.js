import nodemailer from "nodemailer";
import hbs from "nodemailer-express-handlebars";
import { helpers } from "#utils/handlebars.js";
import { AUTH_USER, AUTH_PASS } from "#config";

const Mail = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: AUTH_USER,
    pass: AUTH_PASS,
  },
});

Mail.use(
  "compile",
  hbs({
    viewEngine: {
      extname: ".hbs",
      layoutsDir: "views/email/layouts",
      defaultLayout: false,
      partialsDir: "views/email/partials",
      helpers,
    },
    viewPath: "views/email/layouts",
    extName: ".hbs",
  })
);

export default Mail;
