export const helpers = {
  rules(data) {
    const { attrs, attr } = data.hash;
    const value = attrs.filter((item) => item.id == attr.parent)[0]?.value;
    const result = value == attr.conditional;
    return result && attr.type != "long"
      ? data.fn(this)
      : result && attr.type == "long"
      ? data.inverse(this)
      : null;
  },
  rulesEmpty(data) {
    const { attr } = data.hash;

    return attr.type != "long"
      ? data.fn(this)
      : attr.type == "long"
      ? data.inverse(this)
      : null;
  },
  idCode(data) {
    const date = new Date(data);
    return `${date
      .getUTCDate()
      .toLocaleString("es", { minimumIntegerDigits: 2 })}${(
      date.getUTCMonth() + 1
    ).toLocaleString("es", {
      minimumIntegerDigits: 2,
    })}${date.getUTCFullYear()}`;
  },
  date(data) {
    const date = new Date(data);
    return `${date
      .getUTCDate()
      .toLocaleString("es", { minimumIntegerDigits: 2 })}/${(
      date.getUTCMonth() + 1
    ).toLocaleString("es", {
      minimumIntegerDigits: 2,
    })}/${date.getUTCFullYear()}`;
  },
  ifEqual(v1, v2, options) {
    if (!options) {
      if (v1) return v2.fn(this);

      return v2.inverse(this);
    } else {
      if (v1 == v2) {
        return options.fn(this);
      }
      return options.inverse(this);
    }
  },
  ifOr(options) {
    const arr = Object.keys(options.hash).map((prop) =>
      Boolean(options.hash[prop])
    );
    if (arr.includes(true)) {
      return options.fn(this);
    }
    return options.inverse(this);
  },
};
