import {v2} from 'cloudinary';

const {api_secret, cloud_name, api_key} = v2.config({secure: true});

export const uploadPhotoProfile = (public_id, id) => {

  const params = {
    timestamp: Math.round((new Date).getTime()/1000),
    public_id,
    transformation: 'c_thumb,g_face,h_300,w_300,z_0.5',
    folder: `photo/${id}`
  }

  const signature = v2.utils.api_sign_request(params, api_secret);

  return { signature, cloud_name, api_key, ...params }
}

export const uploadProductsMedia = (public_id, id) => {

  const params = {
    timestamp: Math.round((new Date).getTime()/1000),
    public_id,
    transformation: 'c_limit,h_500,w_500',
    eager: 'c_thumb,g_center,h_150,w_150',
    folder: `products/${id}`
  }

  const signature = v2.utils.api_sign_request(params, api_secret);

  return { signature, cloud_name, api_key, ...params }
}

export const uploadBrand = (public_id, id) => {

  const params = {
    timestamp: Math.round((new Date).getTime()/1000),
    public_id,
    transformation: 'c_limit,h_300,w_300',
    folder: `options/${id}`
  }

  const signature = v2.utils.api_sign_request(params, api_secret);

  return { signature, cloud_name, api_key, ...params }
}

export const uploadDocument = (public_id, id) => {

  const params = {
    timestamp: Math.round((new Date).getTime()/1000),
    public_id,
    folder: `options/${id}`
  }

  const signature = v2.utils.api_sign_request(params, api_secret);

  return { signature, cloud_name, api_key, ...params }
}

export const uploadFiles = (public_id, folder) => {

  const params = {
    timestamp: Math.round((new Date).getTime()/1000),
    public_id,
    folder
  }

  const signature = v2.utils.api_sign_request(params, api_secret);

  return { signature, cloud_name, api_key, ...params }
}

export default v2;