import { DataTypes } from "sequelize";
import sequelize from "#db";
import { UsersSaved } from "#models/users/UsersModels.js";
import Customers from "#models/customers/CustomersModels.js";
import BussinessTypes from "#models/BussinessTypesModels.js";
import ProductsTypes from "#models/ProductsTypesModels.js";
import { Buffer } from "node:buffer";

export const state = {
  new: ["new", "Nuevo"],
  used: ["used", "Usado"],
};

export const leased_state = {
  draft: ["draft", "Borrador"],
  initial: ["initial", "Inicial"],
  delivery: ["delivery", "Entrega"],
  leased: ["leased", "Alquilado"],
  finished: ["finished", "Finalizado"],
};

export const product_state = {
  new: ["new", "Reciente"],
  relocation: ["relocation", "Recolocación"],
};

const options = {
  name: {
    type: DataTypes.STRING,
  },
  address: {
    type: DataTypes.STRING,
  },
  code: {
    type: DataTypes.BIGINT,
    get() {
      return Number(this.getDataValue("code"));
    },
  },
  attrs: {
    type: DataTypes.JSON,
    defaultValue: [],
  },
  observations: {
    type: DataTypes.JSON,
    defaultValue: [],
  },
  images: {
    type: DataTypes.JSON,
  },
  price: {
    type: DataTypes.INTEGER,
  },
  signature: {
    type: DataTypes.BLOB("long"),
    get() {
      return this.getDataValue("signature")
        ? this.getDataValue("signature").toString()
        : this.getDataValue("signature");
    },
    set(value) {
      this.setDataValue("signature", value ? Buffer.from(value) : value);
    },
  },
  signature_proprietor: {
    type: DataTypes.BLOB("long"),
    get() {
      return this.getDataValue("signature_proprietor")
        ? this.getDataValue("signature_proprietor").toString()
        : this.getDataValue("signature_proprietor");
    },
    set(value) {
      this.setDataValue(
        "signature_proprietor",
        value ? Buffer.from(value) : value
      );
    },
  },
  state: {
    type: DataTypes.ENUM,
    values: Object.keys(state),
    defaultValue: state.new[0],
    allowNull: false,
  },
  leased_state: {
    type: DataTypes.ENUM,
    values: Object.keys(leased_state),
    defaultValue: leased_state.draft[0],
    allowNull: false,
  },
  product_state: {
    type: DataTypes.ENUM,
    values: Object.keys(product_state),
    defaultValue: product_state.new[0],
    allowNull: false,
  },
  date: {
    type: DataTypes.DATEONLY,
  },
  date_catchment: {
    type: DataTypes.DATEONLY,
    defaultValue: DataTypes.NOW,
  },
  date_inventory: {
    type: DataTypes.DATEONLY,
  },
  tyc: {
    type: DataTypes.BOOLEAN,
  },
  policy: {
    type: DataTypes.BOOLEAN,
  },
  user_observation: {
    type: DataTypes.TEXT,
  },
  proprietor_observation: {
    type: DataTypes.TEXT,
  },
  leaseholder_observation: {
    type: DataTypes.TEXT,
  },
  proprietor_data: {
    type: DataTypes.JSON,
    defaultValue: {},
  },
  leaseholder_data: {
    type: DataTypes.JSON,
    defaultValue: {},
  },
};

const Products = sequelize.define("products", options, {
  paranoid: true,
});

// Products.sync({force: true});

Products.belongsTo(UsersSaved, {
  as: "user",
  foreignKey: "userId",
});

Products.belongsTo(UsersSaved, {
  as: "created_by",
  foreignKey: "createdBy",
});

Products.belongsTo(UsersSaved, {
  as: "second_user",
  foreignKey: "secondUser",
});

Products.belongsTo(Customers, {
  as: "proprietor",
  foreignKey: "proprietorId",
});

Products.belongsTo(Customers, {
  as: "leaseholder",
  foreignKey: "leaseholderId",
});

Products.belongsTo(BussinessTypes, {
  as: "bussiness_type",
  foreignKey: "bussinessType",
});

Products.belongsTo(ProductsTypes, {
  as: "product_type",
  foreignKey: "productsType",
});

// Products.sync({force: true});
// Products.destroy({truncate: true, force: true});

export const excelSchemaProducts = [
  {
    column: "Titulo inmueble",
    value: ({ name }) => name,
  },
  {
    column: "Dirección",
    value: ({ address }) => address,
  },
  {
    column: "Código",
    value: ({ code }) => code,
  },
  {
    column: "Precio alquiler",
    value: ({ price }) => price,
  },
  {
    column: "Tipo negocio",
    value: ({ bussiness_type }) => bussiness_type?.name,
  },
  {
    column: "Tipo inmueble",
    value: ({ product_type }) => product_type?.name,
  },
  {
    column: "Estado de arriendo",
    value: ({ leased_state: ls }) => onStateMap(ls, leased_state, 0, 1),
  },
  {
    column: "Estado",
    value: ({ product_state: ps }) => onStateMap(ps, product_state, 0, 1),
  },
];

export const excelRelationProducts = {
  tituloinmueble: "name",
  direccion: "address",
  codigo: "code",
  precioalquiler: "price",
  estadodearriendo: "leased_state",
  tipoinmueble: "productsType",
  tiponegocio: "bussinessType",
};

export function onStateMap(value, state, k, v) {
  let result = null;
  let first = null;
  Object.keys(state).forEach((key, index) => {
    if (index == 0) first = key;
    if (value == state[key][k]) result = key;
  });
  return result ? state[result][v] : state[first][v];
}

function productState(value) {
  switch (value) {
    case "relocation":
      return "Recolocacion";
    default:
      return "Nuevo";
  }
}

export const stateMap = (value) => {
  switch (value) {
    case "En Proceso":
      return "process";
    case "Arrendado":
      return "leased";
    default:
      return "free";
  }
};

const user = ["id", "name", "last", "fullName", "nit", "email", "cellphone"];

const exclude = [
  "createdAt",
  "updatedAt",
  "userId",
  "proprietorId",
  "leaseholderId",
  "createdBy",
  "secondUser",
  "bussinessType",
  "productsType",
];

export const ProductsOptions = {
  order: [["id", "DESC"]],
  paranoid: false,
  include: [
    {
      model: BussinessTypes,
      as: "bussiness_type",
      attributes: ["id", "name"],
    },
    {
      model: ProductsTypes,
      as: "product_type",
      attributes: ["id", "name"],
    },
    {
      model: UsersSaved,
      as: "user",
      attributes: [...user, "signature"],
    },
    {
      model: UsersSaved,
      as: "second_user",
      attributes: [...user, "signature"],
    },
    {
      model: UsersSaved,
      as: "created_by",
      attributes: user,
    },
    {
      model: Customers,
      as: "proprietor",
      attributes: user,
    },
    {
      model: Customers,
      as: "leaseholder",
      attributes: user,
    },
  ],
  attributes: {
    exclude: [...exclude, "attrs", "images"],
  },
};

export const SingleProductsOptions = {
  order: [["id", "DESC"]],
  include: [
    {
      model: BussinessTypes,
      as: "bussiness_type",
      attributes: ["id", "name"],
    },
    {
      model: ProductsTypes,
      as: "product_type",
      attributes: ["id", "name"],
    },
    {
      model: UsersSaved,
      as: "user",
      attributes: [...user, "signature"],
    },
    {
      model: UsersSaved,
      as: "second_user",
      attributes: [...user, "signature"],
    },
    {
      model: UsersSaved,
      as: "created_by",
      attributes: user,
    },
    {
      model: Customers,
      as: "proprietor",
      attributes: user,
    },
    {
      model: Customers,
      as: "leaseholder",
      attributes: user,
    },
  ],
  attributes: {
    exclude,
  },
};

export const ProductsOptionsSettings = {
  order: [["id", "DESC"]],
  include: [
    {
      model: BussinessTypes,
      as: "bussiness_type",
      attributes: ["id", "name"],
    },
    {
      model: ProductsTypes,
      as: "product_type",
      attributes: ["id", "name"],
    },
    {
      model: UsersSaved,
      as: "user",
      attributes: [...user, "signature"],
    },
    {
      model: UsersSaved,
      as: "second_user",
      attributes: [...user, "signature"],
    },
    {
      model: UsersSaved,
      as: "created_by",
      attributes: user,
    },
    {
      model: Customers,
      as: "proprietor",
      attributes: [...user, "password"],
    },
    {
      model: Customers,
      as: "leaseholder",
      attributes: [...user, "password"],
    },
  ],
  attributes: {
    exclude,
  },
};

export default Products;
