import {DataTypes} from "sequelize"
import sequelize from "#db"

const Permissions = sequelize.define("permissions", {
	name: {
		type: DataTypes.STRING
	},
	alias: {
		type: DataTypes.STRING
	},
}, {
	timestamps: false
});

export default Permissions;