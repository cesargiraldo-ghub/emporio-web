import { DataTypes } from "sequelize";
import sequelize from "#db";
import { mapModules } from "#utils/helpers.js";
import Users from "#models/users/UsersModels.js";

const RolsPermissions = sequelize.define(
  "rols_permissions",
  {
    rolId: {
      type: DataTypes.INTEGER,
    },
    moduleId: {
      type: DataTypes.INTEGER,
    },
    permissionId: {
      type: DataTypes.INTEGER,
    },
  },
  {
    timestamps: false,
  }
);
RolsPermissions.removeAttribute("id");

export const getRolPermissions = async (id) => {
  const [result] = await sequelize.query(
    `select "r"."id" as "rol_id", "r"."name" as "rol_name", "m"."id" as "module_id", "m"."name" as "module_name", "m"."alias" as "module_alias", "p"."id" as "permission_id", "p"."name" as "permission_name", "p"."alias" as "permission_alias" from rols_permissions rp inner join rols r on "rp"."rolId" = "r"."id" inner join modules m on "rp"."moduleId" = "m"."id" inner join permissions p on "rp"."permissionId" = "p"."id" where "r"."id" = ${id}`
  );
  return result.length ? result : null;
};

export const authPermissions = ({ modules, permissions }) => {
  return async (req, res, next) => {
    try {
      const id = req.user_id;
      const { rolId, ...user } = await Users.findOne({
        include: { all: true },
        where: { id },
      });
      let rol = await getRolPermissions(rolId);
      rol = rol?.find(
        (Module) =>
          modules.includes(Module.module_alias) &&
          permissions.includes(Module.permission_alias)
      );
      req.rol_alias = user.rol.alias;

      user.rol.ranking === "0" || rol
        ? next()
        : res
            .status(403)
            .json({
              message:
                "Lo sentimos pero no tienes permiso para realizar esa acción",
            });
    } catch (e) {
      console.error(e);
      res.status(500).json({ message: "Ocurrio un problema inesperado" });
    }
  };
};

export default RolsPermissions;
