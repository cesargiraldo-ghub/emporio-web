import { DataTypes } from "sequelize";
import sequelize from "#db";
import { clearWhiteSpace } from "#utils/helpers.js";

const ObservationsTypes = sequelize.define(
  "observations_types",
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    alias: {
      type: DataTypes.STRING,
      allowNull: false,
      set(value) {
        this.setDataValue("alias", `${clearWhiteSpace(value)}-${Date.now()}`);
      },
    },
    ranking: {
      type: DataTypes.ENUM,
      values: ["0", "1"],
      defaultValue: "1",
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);

export const ObservationsTypesOptions = {
  order: [
    ["ranking", "ASC"],
    ["name", "ASC"],
  ],
  attributes: {
    exclude: ["createdAt", "updatedAt"],
  },
};

export default ObservationsTypes;
