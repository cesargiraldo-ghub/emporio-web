import {DataTypes} from "sequelize"
import sequelize from "#db"

const BussinessTypes = sequelize.define("bussiness_types", {
	name: {
		type: DataTypes.STRING
	},
	alias: {
		type: DataTypes.STRING
	}
}, {
	timestamps: false
});

export default BussinessTypes;