import {DataTypes} from "sequelize"
import sequelize from "#db"

const Rols = sequelize.define("rols", {
	name: {
		type: DataTypes.STRING
	},
	alias: {
		type: DataTypes.STRING
	},
	ranking: {
		type: DataTypes.ENUM,
		values: ['0', '1', '2'],
		defaultValue: '2'
	}
}, {
	timestamps: false
});

export default Rols;