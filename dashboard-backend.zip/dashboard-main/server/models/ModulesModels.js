import {DataTypes} from "sequelize"
import sequelize from "#db"

const Modules = sequelize.define("modules", {
	name: {
		type: DataTypes.STRING
	},
	alias: {
		type: DataTypes.STRING
	},
}, {
	timestamps: false
});

export default Modules;