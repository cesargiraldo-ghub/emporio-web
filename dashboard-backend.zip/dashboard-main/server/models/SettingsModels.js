import { DataTypes } from "sequelize"
import sequelize from "#db"

export const productSections = sequelize.define("product_sections", {
	name: {
		type: DataTypes.STRING,
		allowNull: false
	},
	attrs: {
		type: DataTypes.JSON,
		defaultValue: []
	},
	atmosphere: {
		type: DataTypes.JSON,
		defaultValue: []
	},
	position: {
		type: DataTypes.INTEGER,
	},
}, {
	timestamps: false
});

// productSections.sync({force: true});

export const bussinessSettigns = sequelize.define("bussinesses", {
	key: {
		type: DataTypes.STRING,
		unique: true,
	},
	value: {
		type: DataTypes.TEXT,
		get() {
			const value = this.getDataValue('value');
			return ["photo", "manual", "policy"].includes(this.getDataValue('key')) ? JSON.parse(value) : value;
		}
	}
}, {
	timestamps: false
});

export const mapOptions = (rows) => {
	const options = {};
	rows.forEach(item => {
		const { key, value } = item.toJSON();
		options[key] = value;
	});

	return options;
}

export const templateTerms = (options, product) => {
	const { leaseholder } = product;
	const { terms, ...realState } = mapOptions(options);
	const property = {
		name: product.name,
		address: product.address
	}

	let value = terms;
	const variables = { realState, property }
	if (leaseholder) {
		Object.assign(variables, { leaseholder })
	}

	const valueMap = {};
	for (let prop in variables) {

		const { name, last, ...values } = variables[prop];
		valueMap[`${prop}.fullName`] = last ? `${name} ${last}` : name;

		for (let p in values) {
			valueMap[`${prop}.${p}`] = values[p];
		}
	}

	if (value) {
		const allKeys = Object.keys(valueMap);

		allKeys.forEach(key => {
			value = value.replace(new RegExp('href="{{', 'gi'), 'href="https://{{');
			const stgKey = new RegExp('{{' + key + '}}', 'gi');
			value = value.replace(stgKey, valueMap[key]);
		});
	}
	return { ...realState, terms: value };
}

const excludeDate = ["createdAt", "updatedAt"];
export const SectionsOptions = {
	order: [
		['position', 'DESC']
	],
	attributes: {
		exclude: [...excludeDate]
	}
}