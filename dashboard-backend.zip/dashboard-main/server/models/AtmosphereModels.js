import { DataTypes } from "sequelize"
import sequelize from "#db"
import { clearWhiteSpace } from "#utils/helpers.js"
import { productSections } from "#models/SettingsModels.js"

const Atmosphere = sequelize.define("atmosphere", {
	name: {
		type: DataTypes.STRING,
		allowNull: false
	},
	alias: {
		type: DataTypes.STRING,
		allowNull: false,
		set(value) {
			this.setDataValue('alias', `${clearWhiteSpace(value)}-${Date.now()}`);
		}
	},
	productTypes: {
		type: DataTypes.JSON,
		defaultValue: '[]',
		get() {
			const value = this.getDataValue("productTypes");
			return typeof value == 'string' ? JSON.parse(value) : value;
		},
	},
	ranking: {
		type: DataTypes.ENUM,
		values: ['0', '1'],
		defaultValue: "1",
		allowNull: false
	},
}, {
	hooks: {
		async afterBulkDestroy({ where: { id: ID } }) {
			try {
				const rows = await productSections.findAll();
				const data = rows.map(item => {
					const res = item.toJSON();
					res.atmosphere = res.atmosphere.filter(i => i != ID);
					return res;
				})
				for (let { id, ...item } of data) {
					await productSections.update(item, { where: { id } });
				}
			} catch (e) {
				console.error(e);
			}
		},
	},
	timestamps: false
});

// Atmosphere.sync({force: true});

export const AtmosphereOptions = {
	order: [
		['ranking', 'ASC'],
		['name', 'ASC']
	],
	attributes: {
		exclude: ["createdAt", "updatedAt"]
	}
}

export default Atmosphere;