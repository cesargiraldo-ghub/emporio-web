import { DataTypes } from "sequelize";
import sequelize from "#db";

const Customers = sequelize.define(
  "customers",
  {
    name: {
      type: DataTypes.STRING,
    },
    last: {
      type: DataTypes.STRING,
    },
    fullName: {
      type: DataTypes.VIRTUAL,
      get() {
        return this.name && this.last
          ? `${this.name?.split(" ")[0]} ${this.last?.split(" ")[0]}`
          : null;
      },
      set(value) {
        throw new Error("Do not try to set the `fullName` value!");
      },
    },
    fullNameLong: {
      type: DataTypes.VIRTUAL,
      get() {
        return `${this.name} ${this.last}`;
      },
      set(value) {
        throw new Error("Do not try to set the `fullNameLong` value!");
      },
    },
    nit: {
      type: DataTypes.BIGINT,
      unique: true,
      allowNull: false,
      get() {
        return Number(this.getDataValue("nit"));
      },
    },
    password: {
      type: DataTypes.VIRTUAL,
      get() {
        return `${this.nit}-${this.id}`;
      },
      set(value) {
        throw new Error("Do not try to set the `password` value!");
      },
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cellphone: {
      type: DataTypes.BIGINT,
      get() {
        return Number(this.getDataValue("cellphone"));
      },
    },
    customerType: {
      type: DataTypes.JSON,
    },
    state: {
      type: DataTypes.ENUM,
      values: ["publish", "draf", "archived"],
      defaultValue: "publish",
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);

// Customers.sync({force: true});

export const excelSchemaCustomers = [
  {
    column: "Nombres",
    value: ({ name }) => name,
  },
  {
    column: "Apellidos",
    value: ({ last }) => last,
  },
  {
    column: "CC",
    value: ({ nit }) => nit,
  },
  {
    column: "Email",
    value: ({ email }) => email,
  },
  {
    column: "Celular",
    value: ({ cellphone }) => cellphone,
  },
  {
    column: "Tipo de cliente",
    value: ({ customerType }) => customerType,
  },
];

export const excelRelationCustomers = {
  nombres: "name",
  apellidos: "last",
  cc: "nit",
  email: "email",
  celular: "cellphone",
  tipodecliente: "customerType",
};

const fields = ["createdAt", "updatedAt"];
export const CustomersOptions = {
  include: {
    all: true,
    attributes: {
      exclude: ["alias", ...fields],
    },
  },
  attributes: {
    exclude: ["password", "leaseholderId", "proprietorId", ...fields],
  },
};

export default Customers;
