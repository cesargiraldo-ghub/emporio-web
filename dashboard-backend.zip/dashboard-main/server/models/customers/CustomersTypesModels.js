import {DataTypes} from "sequelize"
import sequelize from "#db"

const CustomersTypes = sequelize.define("customers_types", {
	name: {
		type: DataTypes.STRING
	},
	alias: {
		type: DataTypes.STRING,
		unique: true
	}
}, {
	timestamps: false
})

export default CustomersTypes;