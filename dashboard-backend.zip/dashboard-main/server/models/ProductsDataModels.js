import { DataTypes } from "sequelize";
import sequelize from "#db";
import Users from "#models/users/UsersModels.js";
import BussinessTypes from "#models/BussinessTypesModels.js";
import ProductsTypes from "#models/ProductsTypesModels.js";
import readXlsxFile from "read-excel-file/node";
import { clearString } from "#utils/helpers.js";

export const state = {
  new: ["new", "Nuevo"],
  used: ["used", "Usado"],
};

export const leased_state = {
  available: ["available", "Disponible"],
  retired: ["retired", "Retirado"],
};

export const product_state = {
  new: ["new", "Reciente"],
  relocation: ["relocation", "Recolocación"],
};

const options = {
  name: {
    type: DataTypes.STRING,
  },
  address: {
    type: DataTypes.STRING,
  },
  code: {
    type: DataTypes.BIGINT,
    get() {
      return Number(this.getDataValue("code"));
    },
  },
  price: {
    type: DataTypes.INTEGER,
  },
  state: {
    type: DataTypes.ENUM,
    values: Object.keys(state),
    defaultValue: state.new[0],
    allowNull: false,
  },
  leased_state: {
    type: DataTypes.ENUM,
    values: Object.keys(leased_state),
    defaultValue: leased_state.available[0],
    allowNull: false,
  },
  product_state: {
    type: DataTypes.ENUM,
    values: Object.keys(product_state),
    defaultValue: product_state.new[0],
    allowNull: false,
  },
};

const ProductsData = sequelize.define("products_data", options, {
  timestamps: false,
});

ProductsData.belongsTo(Users, {
  as: "created_by",
  foreignKey: "createdBy",
});

ProductsData.belongsTo(BussinessTypes, {
  as: "bussiness_type",
  foreignKey: "bussinessType",
});

ProductsData.belongsTo(ProductsTypes, {
  as: "product_type",
  foreignKey: "productsType",
});

// ProductsData.sync({force: true});
// ProductsData.destroy({truncate: true});

export const excelSchemaProducts = [
  {
    column: "Titulo inmueble",
    value: ({ name }) => name,
  },
  {
    column: "Dirección",
    value: ({ address }) => address,
  },
  {
    column: "Código",
    value: ({ code }) => code,
  },
  {
    column: "Precio alquiler",
    value: ({ price }) => price,
  },
  {
    column: "Tipo negocio",
    value: ({ bussiness_type }) => bussiness_type?.name,
  },
  {
    column: "Tipo inmueble",
    value: ({ product_type }) => product_type?.name,
  },
  {
    column: "Estado de arriendo",
    value: ({ leased_state: ls }) => onStateMap(ls, leased_state, 0, 1),
  },
  {
    column: "Estado",
    value: ({ product_state: ps }) => onStateMap(ps, product_state, 0, 1),
  },
];

export const excelRelationProducts = {
  tituloinmueble: "name",
  direccion: "address",
  codigo: "code",
  precioalquiler: "price",
  estadodearriendo: "leased_state",
  tipoinmueble: "productsType",
  tiponegocio: "bussinessType",
};

export function onStateMap(value, state, k, v) {
  let result = null;
  let first = null;
  Object.keys(state).forEach((key, index) => {
    if (index == 0) first = key;
    if (value == state[key][k]) result = key;
  });
  return result ? state[result][v] : state[first][v];
}

export const stateMap = (value) => {
  switch (value) {
    case "En Proceso":
      return "process";
    case "Arrendado":
      return "leased";
    default:
      return "free";
  }
};

export const ProductsDataOptions = {
  order: [["id", "DESC"]],
  include: [
    {
      model: BussinessTypes,
      as: "bussiness_type",
      attributes: ["id", "name"],
    },
    {
      model: ProductsTypes,
      as: "product_type",
      attributes: ["id", "name"],
    },
    {
      model: Users,
      as: "created_by",
      attributes: ["id", "name", "last", "fullName"],
    },
  ],
};

export const ProductsDataOptionsSettings = {
  order: [["id", "DESC"]],
  include: [
    {
      model: BussinessTypes,
      as: "bussiness_type",
      attributes: ["id", "name"],
    },
    {
      model: ProductsTypes,
      as: "product_type",
      attributes: ["id", "name"],
    },
    {
      model: Users,
      as: "created_by",
      attributes: [
        "id",
        "name",
        "last",
        "fullName",
        "nit",
        "email",
        "cellphone",
      ],
    },
  ],
  attributes: {
    exclude: [
      "createdAt",
      "updatedAt",
      "createdBy",
      "bussinessType",
      "productsType",
    ],
  },
};

export default ProductsData;

export const readExcelFile = async (filePath, createdBy) => {
  const excel = await readXlsxFile(filePath);
  const columns = excel.shift();

  const bt = await BussinessTypes.findAll();
  const pt = await ProductsTypes.findAll();

  const data = excel.map((value) => {
    const result = { createdBy };
    columns.forEach(async (col, index) => {
      const prop = clearString(col);
      if (Object.keys(excelRelationProducts).includes(prop)) {
        const column = excelRelationProducts[prop];
        if (column == "productsType" && value[index]) {
          let type = pt.find(
            (item) => clearString(item.name) == clearString(value[index])
          );
          result[column] = type?.id;
        } else if (column == "bussinessType" && value[index]) {
          let type = bt.find(
            (item) => clearString(item.name) == clearString(value[index])
          );
          result[column] = type?.id;
        } else if (column == "leased_state") {
          result[column] = onStateMap(value[index], leased_state, 1, 0);
        } else if (column == "name") {
          result[column] = value[index]
            .toLowerCase()
            .split(" ")
            .map((word, index) =>
              word.length > 3 || index == 0
                ? word.replace(/\w/, (letter) => letter.toUpperCase())
                : word
            )
            .join(" ");
        } else {
          result[column] = value[index];
        }
      }
    });
    return result;
  });
  return data;
};
