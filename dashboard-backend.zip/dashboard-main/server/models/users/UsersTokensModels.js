import { DataTypes } from "sequelize"
import sequelize from "#db"

const UsersTokens = sequelize.define("users_tokens", {
	userId: DataTypes.INTEGER,
	token: DataTypes.STRING
}, {
	timestamps: false
});

export default UsersTokens;