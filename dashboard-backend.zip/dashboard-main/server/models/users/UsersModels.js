import { DataTypes } from "sequelize";
import sequelize from "#db";
import Rols from "#models/RolsModels.js";

const options = {
  name: {
    type: DataTypes.STRING,
  },
  last: {
    type: DataTypes.STRING,
  },
  fullName: {
    type: DataTypes.VIRTUAL,
    get() {
      return this.name && this.last
        ? `${this.name?.split(" ")[0]} ${this.last?.split(" ")[0]}`
        : null;
    },
    set(value) {
      throw new Error("Do not try to set the `fullName` value!");
    },
  },
  fullNameLong: {
    type: DataTypes.VIRTUAL,
    get() {
      return `${this.name} ${this.last}`;
    },
    set() {
      throw new Error("Do not try to set the `fullName` value!");
    },
  },
  photo: {
    type: DataTypes.JSON,
  },
  cellphone: {
    type: DataTypes.BIGINT,
    get() {
      return Number(this.getDataValue("cellphone"));
    },
  },
  signature: {
    type: DataTypes.BLOB("long"),
    get() {
      return this.getDataValue("signature")
        ? this.getDataValue("signature").toString()
        : this.getDataValue("signature");
    },
    set(value) {
      this.setDataValue("signature", value ? Buffer.from(value) : value);
    },
  },
};

export const UsersSaved = sequelize.define("users_saved", {
  ...options,
  email: {
    type: DataTypes.STRING,
    unique: false,
    allowNull: false,
  },
  nit: {
    type: DataTypes.BIGINT,
    unique: false,
    get() {
      return Number(this.getDataValue("nit"));
    },
    allowNull: false,
  },
});

const Users = sequelize.define(
  "users",
  {
    ...options,
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      unique: { msg: "E-mail ya registrado" },
      allowNull: false,
    },
    nit: {
      type: DataTypes.BIGINT,
      unique: { msg: "Numero de identificación ya registrado" },
      get() {
        return Number(this.getDataValue("nit"));
      },
      allowNull: false,
    },
  },
  {
    hooks: {
      afterCreate: async (data) => {
        const user = data.toJSON();
        delete user.fullName;
        delete user.fullNameLong;

        await UsersSaved.create(user);
      },
      afterUpdate: async (data) => {
        const user = data.toJSON();
        delete user.fullName;
        delete user.fullNameLong;
        console.log({ user });
        await UsersSaved.update(user, { where: { id: user.id } });
      },
    },
  }
);

Users.belongsTo(Rols);
UsersSaved.belongsTo(Rols);

// (async () => {
// 	const user = {
// 		cellphone: 3107295488,
// 		nit: 1144071424,
// 		name: 'Jorge Ivan',
// 		last: 'Ortiz Muñoz',
// 		password: '$2b$10$K9fqWNQW5Tg1..GkWgiKqeYzTZMbSoftfk7FWDQsa/gC01ahNk2HW',
// 		email: 'jortiz.webdeveloper@gmail.com',
// 		rolId: 1
// 	}

//   await UsersSaved.sync({force: true});
// 	await Users.sync({ force: true });
// 	await Users.create(user);

// })()

export default Users;
