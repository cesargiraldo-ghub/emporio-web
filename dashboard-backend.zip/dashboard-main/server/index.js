import app from "./app.js"

import http from "http";
import https from "https";
import fs from "fs";

import sequelize from "#db"

import {HOST, HTTP, HTTPS, NODE_ENV} from "#config"

http.createServer(app).listen(HTTP, () => {
	console.info(`Server run http://${HOST}:${HTTP}`);
	// sequelize.sync()
});

if(NODE_ENV == "production"){
	const options = {
		cert: fs.readFileSync(`/etc/letsencrypt/live/${HOST}/cert.pem`, 'utf8'),
	  key: fs.readFileSync(`/etc/letsencrypt/live/${HOST}/privkey.pem`, 'utf8'),
	  ca: fs.readFileSync(`/etc/letsencrypt/live/${HOST}/chain.pem`, 'utf8')
	};

	https.createServer(options, app).listen(HTTPS, () => {
		console.info(`Server run https://${HOST}:${HTTP}`);
	});
}