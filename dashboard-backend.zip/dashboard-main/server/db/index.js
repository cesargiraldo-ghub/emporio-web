import { Sequelize } from "sequelize";
import { SERVER, DB, DBPORT, DBUSER, DBPASS } from "#config";

const sequelize = new Sequelize(DB, DBUSER, DBPASS, {
  host: SERVER,
	port: DBPORT,
  dialect: "postgres",
});
export default sequelize;
