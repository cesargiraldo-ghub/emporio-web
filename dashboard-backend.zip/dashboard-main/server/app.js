import express from "express";
import cors from "cors";
import publics from "#api/public/index.js";
import auths from "#api/auth/index.js";
import { authToken, authPublic, configJWT } from "#utils/jwt.js";
import { expressjwt } from "express-jwt";
import { engine } from "express-handlebars";
import { helpers } from "#utils/handlebars.js";

const app = express();
app.engine(
  ".hbs",
  engine({
    extname: ".hbs",
    helpers,
  })
);
app.set("view engine", ".hbs");
app.set("views", "./views");

app.use([cors({ origin: "*" }), express.json({ limit: "50mb" })]);

app.use("/public", expressjwt(configJWT), authPublic, publics);
app.use("/auth", expressjwt(configJWT), authToken, auths);
// app.use("/auth", auths);

export default app;
