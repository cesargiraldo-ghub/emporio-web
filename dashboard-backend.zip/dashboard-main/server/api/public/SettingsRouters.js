import {Router} from "express"
import * as Options from "#controllers/SettingsOptionsControllers.js"

const router = Router();

router.route("/settings-options")
	.get(Options.getBrand)

export default router;

