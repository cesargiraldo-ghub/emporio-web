import Products from "./ProductsRouters.js"
import Auth from "./AuthRouters.js"
import Settings from "./SettingsRouters.js"

export default [
	Auth,
	Products,
	Settings
]