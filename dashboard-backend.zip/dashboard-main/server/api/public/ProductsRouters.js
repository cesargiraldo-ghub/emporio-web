import { Router } from "express";
import * as Products from "#controllers/Products/ProductsControllers.js";
import * as ProductsLeasedState from "#controllers/Products/ProductsLeasedStateControllers.js";
import * as ProductsDocuemnt from "#controllers/Products/ProductsDocumentsControllers.js";

const router = Router();

router.route("/document/:id").get(ProductsDocuemnt.getProductDocument);
router
  .route("/product-state/:id")
  .get(ProductsLeasedState.getProductState)
  .post(ProductsLeasedState.getProductLeaseholder);

router
  .route("/observation-state/:id/:obs")
  .get(ProductsLeasedState.getObservationState)
  .post(ProductsLeasedState.getProductObservation)
  .patch(ProductsLeasedState.updateObservationState);

router
  .route("/product-state-lease/:id")
  .patch(ProductsLeasedState.updateProductStateLeased);

export default router;
