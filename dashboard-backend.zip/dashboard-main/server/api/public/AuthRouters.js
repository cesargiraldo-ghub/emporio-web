import {Router} from "express"
import * as Auth from "#controllers/AuthControllers.js"

const router = Router();

router.route("/signin")
	.post(Auth.signIn)

// router.route("/signup")
// 	.post(Auth.signUp)

router.route("/reset-password")
	.post(Auth.createTokenPassword)

router.route("/reset-password/:userId/:token")
	.get(Auth.validateTokenPassword)
	.patch(Auth.updatePassword)

export default router;