import { Router } from "express";
import * as ProductsData from "#controllers/Products/ProductsDataControllers.js";
import multer from "multer";
import { __dirname } from "#dirname";
import { authPermissions } from "#models/RolsPermissionsModels.js";

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, `${__dirname}/uploads/`);
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + "-" + Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });
const router = Router();

router
  .route("/products-data")
  .get(
    authPermissions({
      modules: "products",
      permissions: ["read"],
    }),
    ProductsData.getProducts
  )
  .post(
    authPermissions({
      modules: "products",
      permissions: ["create"],
    }),
    ProductsData.createProduct
  )
  .delete(
    authPermissions({
      modules: "products",
      permissions: ["delete"],
    }),
    ProductsData.bulkDeleteProduct
  );

router
  .route("/product-data/:id")
  .get(
    authPermissions({
      modules: "products",
      permissions: ["update"],
    }),
    ProductsData.getProduct
  )
  .patch(
    authPermissions({
      modules: "products",
      permissions: ["update"],
    }),
    ProductsData.updateProduct
  )
  .delete(
    authPermissions({
      modules: "products",
      permissions: ["delete"],
    }),
    ProductsData.deleteProduct
  );

router
  .route("/products-data-documents")
  .get(
    authPermissions({
      modules: "products",
      permissions: ["export"],
    }),
    ProductsData.exportProducts
  )
  .post(
    authPermissions({
      modules: "products",
      permissions: ["import"],
    }),
    upload.single("file"),
    ProductsData.importProducts
  );

export default router;
