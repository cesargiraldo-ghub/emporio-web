import { Router } from "express";
import * as Customers from "#controllers/Customers/CustomersControllers.js";
import * as CustomersDocuments from "#controllers/Customers/CustomersDocumentsControllers.js";
import { authPermissions } from "#models/RolsPermissionsModels.js";
import Multer from "#utils/multer.js";

const router = Router();

router.route("/customers").get(
  authPermissions({
    modules: "customers",
    permissions: ["read"],
  }),
  Customers.getCustomers
);

router.route("/customer").post(
  authPermissions({
    modules: "customers",
    permissions: ["create"],
  }),
  Customers.createCustomer
);

router
  .route("/customer/:id")
  .get(
    authPermissions({
      modules: "customers",
      permissions: ["read"],
    }),
    Customers.getCustomer
  )
  .patch(
    authPermissions({
      modules: "customers",
      permissions: ["update"],
    }),
    Customers.updateCustomer
  );

router
  .route("/customers-documents")
  .get(
    authPermissions({
      modules: "customers",
      permissions: ["export"],
    }),
    CustomersDocuments.exportCustomers
  )
  .post(
    authPermissions({
      modules: "customers",
      permissions: ["import"],
    }),
    Multer.single("file"),
    CustomersDocuments.importCustomers
  );

export default router;
