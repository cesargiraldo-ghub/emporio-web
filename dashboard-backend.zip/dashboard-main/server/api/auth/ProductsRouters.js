import { Router } from "express";
import * as Products from "#controllers/Products/ProductsControllers.js";
import * as ProductsUser from "#controllers/Products/ProductsUserControllers.js";
import * as ProductsDocuemnt from "#controllers/Products/ProductsDocumentsControllers.js";
import * as ProductsMedia from "#controllers/Products/ProductsMediaControllers.js";
import { authPermissions } from "#models/RolsPermissionsModels.js";
import Multer from "#root/utils/multer.js";

const router = Router();

router.route("/products-user").get(
  authPermissions({
    modules: "products",
    permissions: ["read"],
  }),
  ProductsUser.getProducts
);

router.route("/products-user/:id").get(
  authPermissions({
    modules: "products",
    permissions: ["read"],
  }),
  ProductsUser.getProducts
);

router
  .route("/products")
  .get(
    authPermissions({
      modules: ["products", "observations"],
      permissions: ["read"],
    }),
    Products.getProducts
  )
  .post(
    authPermissions({
      modules: "products",
      permissions: ["create"],
    }),
    Products.createProduct
  );

router
  .route("/product/:id")
  .get(
    authPermissions({
      modules: ["products", "observations"],
      permissions: ["update", "read"],
    }),
    Products.getProduct
  )
  .patch(
    authPermissions({
      modules: ["products", "observations"],
      permissions: ["update"],
    }),
    Products.updateProduct
  )
  .delete(
    authPermissions({
      modules: "products",
      permissions: ["delete"],
    }),
    Products.deleteProduct
  );

router.route("/bulk-product").delete(
  authPermissions({
    modules: "products",
    permissions: ["delete"],
  }),
  Products.bulkDeleteProduct
);

/* Media */

/* Documents */

router.route("/document/:id").get(ProductsDocuemnt.getProductDocument);
router
  .route("/empty-document-inventory/:id")
  .get(ProductsDocuemnt.getEmptyProductDocument);

router
  .route("/product-document/:id")
  .get(ProductsDocuemnt.createProductDocument);

router
  .route("/empty-document/:id")
  .post(Multer.none(), ProductsDocuemnt.createEmptyDocument);

router.route("/mail-documents/:id").post(ProductsDocuemnt.mailProductDocument);

router
  .route("/product-media/:id/:attr")
  .get(
    authPermissions({
      modules: ["products", "observations"],
      permissions: ["update"],
    }),
    ProductsMedia.updateFileSing
  )
  .patch(
    authPermissions({
      modules: "products",
      permissions: ["update"],
    }),
    ProductsMedia.updateProductMedia
  )
  .delete(
    authPermissions({
      modules: "products",
      permissions: ["delete"],
    }),
    ProductsMedia.deleteProductMedia
  );

router.route("/product-medias/:id/:attr").delete(
  authPermissions({
    modules: "products",
    permissions: ["delete"],
  }),
  ProductsMedia.deleteProductMedias
);

router.route("/observation-media/:id/:obs/:type").delete(
  authPermissions({
    modules: "observations",
    permissions: ["delete"],
  }),
  ProductsMedia.deleteObservationMedia
);

router.route("/observation-medias/:id/:obs/:type").delete(
  authPermissions({
    modules: "observations",
    permissions: ["delete"],
  }),
  ProductsMedia.deleteObservationMedias
);
export default router;
