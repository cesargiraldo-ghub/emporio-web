import {Router} from "express"
import * as Auth from "#controllers/AuthControllers.js"

const router = Router();

router.route("/signin")
	.post(Auth.onSignIn)

router.route("/signout")
	.post(Auth.signOut)

export default router;