import { Router } from "express";
import * as Sections from "#controllers/SettingsSectionsControllers.js";
import * as Options from "#controllers/SettingsOptionsControllers.js";
import { authPermissions } from "#models/RolsPermissionsModels.js";

const router = Router();

router
  .route("/settings-sections")
  .get(
    Sections.getSections
  )
  .post(
    authPermissions({
      modules: "settings",
      permissions: ["create"],
    }),
    Sections.createSection
  )
  .put(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Sections.updateSections
  );

router
  .route("/settings-section/:id")
  .get(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Sections.getSection
  )
  .patch(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Sections.updateSection
  )
  .delete(
    authPermissions({
      modules: "settings",
      permissions: ["delete"],
    }),
    Sections.deleteSection
  );

router
  .route("/settings-options")
  .get(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Options.getOptions
  )
  .patch(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Options.updateOptions
  );

router
  .route("/brand")
  .post(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Options.updateBrandSign
  )
  .put(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Options.updateBrand
  )
  .delete(
    authPermissions({
      modules: "settings",
      permissions: ["delete"],
    }),
    Options.deleteBrand
  );

router
  .route("/settings-docuemnt/:key")
  .post(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Options.updateDocumentSign
  )
  .put(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Options.updateDocument
  )
  .delete(
    authPermissions({
      modules: "settings",
      permissions: ["delete"],
    }),
    Options.deleteDocument
  );

export default router;
