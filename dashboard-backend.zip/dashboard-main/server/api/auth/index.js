import Auth from "./AuthRouters.js"
import Users from "./UsersRouters.js"
import Options from "./OptionsRouters.js"
import Rols from "./RolsRouters.js"
import Settings from "./SettingsRouters.js"
import Products from "./ProductsRouters.js"
import ProductsData from "./ProductsDataRouters.js"
import Customers from "./CustomersRouters.js"

export default [
	Users,
	Auth,
	Options,
	Rols,
	Settings,
	Products,
	ProductsData,
	Customers
]