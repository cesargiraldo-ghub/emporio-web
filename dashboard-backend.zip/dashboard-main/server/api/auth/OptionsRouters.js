import { Router } from "express";
import * as Options from "#controllers/OptionsControllers.js";
import * as ProductsTypes from "#controllers/Options/ProductsTypesControllers.js";
import * as ObservationsTypes from "#controllers/Options/ObservationsTypesControllers.js";
import * as Atmosphere from "#controllers/Options/AtmosphereControllers.js";
import { authPermissions } from "#models/RolsPermissionsModels.js";

const router = Router();

router.route("/customers-types").get(Options.getCustomersTypes);

router.route("/bussiness-types").get(Options.getBussinessTypes);

router.route("/products-types").get(ProductsTypes.getProductsTypes);
router.route("/product-type").post(
  authPermissions({
    modules: "settings",
    permissions: ["create"],
  }),
  ProductsTypes.createProductType
);
router
  .route("/product-type/:id")
  .patch(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    ProductsTypes.updateProductType
  )
  .delete(
    authPermissions({
      modules: "settings",
      permissions: ["delete"],
    }),
    ProductsTypes.deleteProductType
  );

router.route("/observations-types").get(ObservationsTypes.getObservationsTypes);
router.route("/observation-type").post(
  authPermissions({
    modules: "settings",
    permissions: ["create"],
  }),
  ObservationsTypes.createObservationType
);
router
  .route("/observation-type/:id")
  .patch(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    ObservationsTypes.updateObservationType
  )
  .delete(
    authPermissions({
      modules: "settings",
      permissions: ["delete"],
    }),
    ObservationsTypes.deleteObservationType
  );

router
  .route("/atmosphere")
  .get(Atmosphere.getAtmosphere)
  .post(
    authPermissions({
      modules: "settings",
      permissions: ["create"],
    }),
    Atmosphere.createAtmosphere
  )
  .put(
    authPermissions({
      modules: "settings",
      permissions: ["update"],
    }),
    Atmosphere.updateAtmosphere
  );

router.route("/atmosphere/:id").delete(
  authPermissions({
    modules: "settings",
    permissions: ["delete"],
  }),
  Atmosphere.deleteAtmosphere
);

export default router;
