import { Router } from "express"
import * as Rols from "#controllers/RolsControllers.js"
import { authPermissions } from "#models/RolsPermissionsModels.js"

const router = Router();

router.route("/rols")
	.get(Rols.getRols)

router.route("/rol")
	.post(authPermissions({
		modules: "rols",
		permissions: ["create"]
	}), Rols.createRol)

router.route("/rol/:id")
	.delete(authPermissions({
		modules: "rols",
		permissions: ["delete"]
	}), Rols.deleteRol)

router.route("/modules")
	.get(Rols.getModules)

router.route("/rols/:rolId")
	.all(authPermissions({
		modules: "rols",
		permissions: ["update"]
	}))
	.get(Rols.getRolPermission)
	.post(Rols.updateRolPermission)


export default router;