import { Router } from "express";
import * as Users from "#controllers/Users/UsersControllers.js";
import * as UserPhoto from "#controllers/Users/UserPhotoControllers.js";
import { authPermissions } from "#models/RolsPermissionsModels.js";

const router = Router();

router.route("/users").get(Users.getUsers);

router.route("/user").post(
  authPermissions({
    modules: "users",
    permissions: ["create"],
  }),
  Users.createUser
);

router
  .route("/user/:id")
  .get(
    authPermissions({
      modules: "users",
      permissions: ["read"],
    }),
    Users.getUser
  )
  .patch(
    authPermissions({
      modules: "users",
      permissions: ["update"],
    }),
    Users.updateUser
  )
  .delete(
    authPermissions({
      modules: "users",
      permissions: ["delete"],
    }),
    Users.deleteUser
  );

router.route("/profile").patch(
  authPermissions({
    modules: "profile",
    permissions: ["update"],
  }),
  Users.updateProfile
);

router
  .route("/profile-photo")
  .post(
    authPermissions({
      modules: "profile",
      permissions: ["update"],
    }),
    UserPhoto.updatePhotoProfileSign
  )
  .put(
    authPermissions({
      modules: "profile",
      permissions: ["update"],
    }),
    UserPhoto.updatePhotoProfile
  )
  .delete(
    authPermissions({
      modules: "profile",
      permissions: ["delete"],
    }),
    UserPhoto.deletePhoto
  );

export default router;
