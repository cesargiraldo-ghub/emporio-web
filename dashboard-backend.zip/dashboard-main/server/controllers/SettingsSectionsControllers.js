import { productSections, SectionsOptions } from "#models/SettingsModels.js"

export const getSections = async (req, res) => {
	try {
		const rows = await productSections.findAll(SectionsOptions);
		res.status(200).json({ rows })
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const getSection = async (req, res) => {
	const { id } = req.params;
	try {
		const row = await productSections.findOne({ ...SectionsOptions, where: { id } });
		res.status(200).json({ row })
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const createSection = async (req, res) => {
	try {
		const { body } = req;

		const { id } = await productSections.create(body);

		const row = await productSections.findOne({ ...SectionsOptions, where: { id } });
		res.status(200).json({ row, message: "Seccion creada" })
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const updateSection = async (req, res) => {
	try {
		const { body, params: { id } } = req;
		await productSections.update(body, { where: { id } });

		const row = await productSections.findOne({ ...SectionsOptions, where: { id } });

		res.status(200).json({ row, message: "Seccion actualizada" });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const updateSections = async (req, res) => {
	const data = req.body;
	try {
		for (let { id, ...item } of data) {
			await productSections.update(item, { where: { id } });
		}
		const rows = await productSections.findAll(SectionsOptions);

		res.status(200).json({ rows, message: "Cambios guardados" });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const deleteSection = async (req, res) => {
	const { id } = req.params;
	try {
		const result = await productSections.destroy({ where: { id } });
		res.status(200).json({ message: result ? "Seccion eliminado" : "No se elimino ningun registro" });

	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}