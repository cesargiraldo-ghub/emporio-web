import { Op } from "sequelize";
import Users from "#models/users/UsersModels.js";
import bcrypt from "bcrypt";
import { delKey } from "#utils/redis.js";

const fields = ["createdAt", "updatedAt"];
const options = {
  include: {
    all: true,
    attributes: {
      exclude: ["alias", ...fields],
    },
  },
  attributes: {
    exclude: ["password", "genderId", "rolId", ...fields],
  },
};

export const getUsersPublic = async (req, res) => {
  try {
    const rows = await Users.findAll({ ...options });
    res.status(200).json({
      rows,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getUsers = async (req, res) => {
  try {
    const id = req.user_id;
    const rows = await Users.findAll({
      ...options,
      // paranoid: false,
      where: {
        rolId: {
          [Op.or]: [null, { [Op.ne]: 1 }],
        },
        id: {
          [Op.ne]: id,
        },
      },
    });
    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getUser = async (req, res) => {
  const { id } = req.params;
  try {
    const row = await Users.findOne({ ...options, where: { id } });
    res.status(200).json({ row });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const createUser = async (req, res) => {
  try {
    const { id: idUser, nit, photo, ...data } = req.body;
    if (nit) {
      const password = await bcrypt.hash(nit.toString(), 10);
      const rol = data.rol == 1 ? 2 : data.rol;

      const { id } = await Users.create({ password, nit, rolId: rol, ...data });
      const row = await Users.findOne({ ...options, where: { id } });
      res.status(200).json({ row, message: "Usuario registrado" });
    } else {
      res.status(400).json({ message: "Nit obligatorio" });
    }
  } catch (e) {
    console.error(e.name);
    if (e.name === "SequelizeUniqueConstraintError") {
      const [{ message }] = e.errors;
      res.status(400).json({ message });
    } else {
      res.status(500).json({ message: "Ocurrio un problema inesperado" });
    }
  }
};

export const updateUser = async (req, res) => {
  try {
    const id = req.params.id;
    const { id: idUser, nit, email, photo, password, ...data } = req.body;
    const rol = data.rol == 1 ? 2 : data.rol;
    await Users.update(
      { rolId: rol, ...data },
      { where: { id }, individualHooks: true }
    );
    const row = await Users.findOne({ ...options, where: { id } });

    res.status(200).json({ row, message: "Usuario actualizado" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await Users.destroy({ where: { id } });
    await delKey(id);
    if (result) {
      res.status(200).json({ message: "Usuario eliminado" });
    } else {
      res.status(200).json({ message: "Usuario no existente o ya eliminado" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updateProfile = async (req, res) => {
  try {
    const id = req.user_id;
    const { name, last, cellphone, signature } = req.body;
    await Users.update(
      { name, last, cellphone, signature },
      { where: { id }, individualHooks: true }
    );
    const row = await Users.findOne({ ...options, where: { id } });

    res.status(200).json({ row, message: "Perfil actualizado" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
