import Users from "#models/users/UsersModels.js"
import cloudinary, {uploadPhotoProfile} from "#utils/cloudinary.js"

const fields = ["createdAt",  "updatedAt"];
const options = {
	include: {
		all: true,
		attributes:{
			exclude: ["alias", ...fields]
		}
	},
	attributes:{
		exclude: [ "password", "genderId", "rolId", ...fields ]
	}
}

export const updatePhotoProfileSign =  async (req, res) => {
	const id = req.user_id;
	const user = req.body;
	try {
		const result = uploadPhotoProfile(`${id}-${Date.now()}`, id);
		res.status(200).json(result);

  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"});
  }
}

export const updatePhotoProfile =  async (req, res) => {
	const id = req.user_id;
	const photo = req.body;
	
	try {

    const {photo: photoUser} = await Users.findOne({...options, where: {id}});

		if(photoUser)
	    cloudinary.uploader.destroy(photoUser.public_id);

    await Users.update({photo}, {where: {id}});
    const row = await Users.findOne({...options, where: {id}});
    
		res.status(200).json({row, message: "Foto actualizada"});

  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"});
  }
}

export const deletePhoto =  async (req, res) => {
	const id = req.user_id;
	try {

    const {photo} = await Users.findOne({where: {id}});

	  const {result} = await cloudinary.uploader.destroy(photo?.public_id);
	  if(result === "ok")
			await Users.update({photo: null}, {where: {id}});

    const row = await Users.findOne({...options, where: {id}});
    
		res.status(200).json({row, message: "Foto eliminada"});

  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"});
  }
}