import axios from "axios";
import Products, { ProductsOptionsSettings } from "#models/ProductsModels.js";
import Atmosphere, { AtmosphereOptions } from "#models/AtmosphereModels.js";

import {
  bussinessSettigns,
  productSections,
  SectionsOptions,
  templateTerms,
} from "#models/SettingsModels.js";

import { rowsToJSON, createPDF } from "#utils/helpers.js";
import { AUTH_USER, CLOUDINARY_NAME, ORIGIN } from "#config";

import { Op } from "sequelize";

import Mail from "#utils/mailers.js";
import ProductsData from "#root/server/models/ProductsDataModels.js";
import app from "#root/server/app.js";

export const getProductDocument = async (req, res) => {
  try {
    const {
      query: { customer, empty },
      params: { id },
    } = req;

    const row = await Products.findOne({
      ...ProductsOptionsSettings,
      where: { id },
    });

    const rows = await bussinessSettigns.findAll({
      attributes: { exclude: ["createdAt", "updatedAt"] },
    });

    const context = { customer, empty };
    if (row && rows.length) {
      const product = row.toJSON();
      const options = templateTerms(rows, product);
      Object.assign(context, { ...product, options });
    }
    res.render("product", context);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getEmptyProductDocument = async (req, res) => {
  try {
    const {
      params: { id },
      query,
    } = req;

    const row = await ProductsData.findOne({
      where: { id },
    });

    const atmospheres = await Atmosphere.findAll({
      raw: true,
    }).then((res) =>
      res.filter((item) => item.productTypes.includes(row.productsType))
    );

    const sections = await productSections.findAll({
      raw: true,
    });

    const attrs = [];

    Object.keys(query).forEach((key) => {
      const [_, id] = key.split("-");

      const sc = sections.filter((section) =>
        section.atmosphere.includes(Number(id))
      );

      const ap = atmospheres.find((item) => item.id == id);
      Object.assign(ap, { sections: sc });

      if (!["null"].includes(query[key])) {
        for (let i = 0; i < Number(query[key]); i++) {
          attrs.push(ap);
        }
      }
    });

    const rows = await bussinessSettigns.findAll({
      attributes: { exclude: ["createdAt", "updatedAt"] },
    });

    const context = {};
    if (row && rows.length) {
      const product = row.toJSON();
      const options = templateTerms(rows, product);
      Object.assign(context, { ...product, attrs, options });
    }
    res.render("empty", context);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const createProductDocument = async (req, res) => {
  try {
    const {
      query: { customer },
      params: { id },
      headers: { authorization },
    } = req;
    const url = `${req.protocol}://${req.get(
      "host"
    )}/public/document/${id}?customer=${customer}`;
    console.log({url})
    const row = await Products.findOne({
      ...ProductsOptionsSettings,
      where: { id },
    });

    const {
      user,
      second_user,
      leaseholder,
      proprietor,
      date_inventory,
      date,
      signature,
      signature_proprietor,
    } = row.toJSON();

    let message =
      "No se puede generar el documento porque hacen faltan los siguientes datos: ";
    const list = [];

    if (customer) {
      if (!proprietor) list.push("Propietario");

      if (!signature_proprietor) list.push("Firma del propietario");

      if (!date_inventory) list.push("Fecha de inventario");

      if (!user) list.push("Asesor");

      if (!user?.signature) list.push("Firma del asesor");
    }

    if (customer == "arrendatario") {
      if (!leaseholder) list.push("Arrendatario");

      if (!signature) list.push("Firma del arrendatario");

      if (!date) list.push("Fecha de entrega");

      if (second_user && !second_user?.signature)
        list.push("Firma del segundo asesor");
    }

    if (list.length) {
      message += list.join(", ");
      res.status(406).json({ message });
      return;
    }
    const pdf = await createPDF(url, authorization);

    res.setHeader('Content-Type', 'application/pdf');
    
    res.send(Buffer.from(pdf));
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const createEmptyDocument = async (req, res) => {
  try {
    const {
      params: { id },
      headers: { authorization },
      body,
    } = req;
    const { productsType, ...data } = body;
    const query = [];
    Object.keys(data).forEach((key) => {
      query.push(`${key}=${data[key]}`);
    });

    const url = `${req.protocol}://${req.get(
      "host"
    )}/auth/empty-document-inventory/${id}?${query.join("&")}`;

    const pdf = await createPDF(url, authorization);

    res.type("application/pdf");
    res.send(pdf);
    res.status(200);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const mailProductDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const { customer, type } = req.query;
    const { authorization } = req.headers;

    const url = `${req.protocol}://${req.get(
      "host"
    )}/public/document/${id}?customer=${customer}`;
    const row = await Products.findOne({
      ...ProductsOptionsSettings,
      where: { id },
    });
    const {
      name,
      user,
      second_user,
      leaseholder,
      proprietor,
      date_inventory,
      date,
      signature,
      signature_proprietor,
      address,
    } = row.toJSON();

    let message =
      "No se puede enviar el correo porque hacen faltan los siguientes datos: ";
    const list = [];

    if (!["propietario", "arrendatario"].includes(customer)) {
      res.status(406).json({ message: "Tipo de cliente invalido" });
      return;
    }

    if (customer) {
      if (customer == "propietario") {
        if (!proprietor) list.push("Propietario");
        if (!date_inventory) list.push("Fecha de inventario");
      } else {
        if (!leaseholder) list.push("Arrendatario");
        if (!date) list.push("Fecha de entrega");
      }

      if (!signature_proprietor && type != "signature")
        list.push("Firma del propietario");

      if (!signature && customer == "arrendatario" && type != "signature")
        list.push("Firma del arrendatario");

      if (!user) list.push("Asesor");

      if (!user?.signature && type != "signature")
        list.push("Firma del asesor");

      if (second_user && !second_user?.signature && type != "signature")
        list.push("Firma del segundo asesor");
    }

    if (list.length) {
      message += list.join(", ");
      res.status(406).json({ message });
      return;
    }

    const rows = await bussinessSettigns.findAll({
      where: { key: { [Op.in]: ["name", "photo", "manual"] } },
    });
    const bussiness = rowsToJSON(rows);

    const to = customer == "arrendatario" ? leaseholder : proprietor;
    const from = `"${bussiness.name}" <no-reply@emporiobienes.com>`;

    const context = {
      year: new Date().getFullYear(),
      bussiness,
      customer,
      name,
      address,
      to,
      password:
        customer == "arrendatario" ? leaseholder.password : proprietor.password,
      url: `${ORIGIN}/inmueble/${id}/${customer}`,
    };

    if (type == "signature") {
      const subject =
        customer == "arrendatario"
          ? "Firma de Acta de entrega"
          : "Firma de Inventario";

      await Mail.sendMail({
        from,
        subject,
        context,
        to: to.email,
        template: "signature",
      });
    } else {
      const subject =
        customer == "arrendatario"
          ? "Inventario y Acta de entrega"
          : "Inventario";

      const pdf = await createPDF(url, authorization);

      const attachments = [
        {
          filename:
            customer == "arrendatario"
              ? `Inventario y acta de entrega inmueble ${address}.pdf`
              : `Inventario del inmueble ${address}.pdf`,
          content: pdf,
        },
      ];
      console.log(bussiness);

      if (bussiness.manual) {
        attachments.push({
          filename: "Canales de atención.pdf",
          path: `https://res.cloudinary.com/${CLOUDINARY_NAME}/image/upload/${bussiness.manual[0].public_id}.pdf`,
        });
      }

      await Mail.sendMail({
        from,
        subject,
        context,
        to: to.email,
        template: "document",
        attachments,
      });
    }

    res.status(200).json({ message: "Correo enviado exitosamente" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const sendMailProductDocument = async (id, customer, req) => {
  const { authorization } = req.headers;
  const row = await Products.findOne({
    ...ProductsOptionsSettings,
    where: { id },
  });
  const { name, leaseholder, proprietor, address } = row.toJSON();

  const rows = await bussinessSettigns.findAll({
    where: { key: { [Op.in]: ["name", "photo", "manual"] } },
  });
  const bussiness = rowsToJSON(rows);

  const to =
    customer == "arrendatario"
      ? leaseholder
      : customer == "propietario"
      ? proprietor
      : { email: AUTH_USER };
  const from = `"${bussiness.name}" <no-reply@emporiobienes.com>`;

  const context = {
    year: new Date().getFullYear(),
    bussiness,
    customer,
    name,
    address,
    to,
    password:
      customer == "arrendatario" ? leaseholder.password : proprietor.password,
    url: `${ORIGIN}/inmueble/${id}/${
      customer == "business" ? "arrendatario" : customer
    }`,
  };

  const subject =
    customer == "arrendatario"
      ? "Inventario y Acta de entrega"
      : customer == "propietario"
      ? "Inventario"
      : `Registro de inventarios del inmueble ${address}}`;

  const attachments = [];

  if (customer == "business") {
    for (const key of ["arrendatario", "propietario"]) {
      const url = `${req.protocol}://${req.get(
        "host"
      )}/public/document/${id}?customer=${key}`;

      const pdf = await createPDF(url, authorization);

      attachments.push({
        filename:
          key == "arrendatario"
            ? `Inventario y acta de entrega inmueble ${address}.pdf`
            : `Inventario del inmueble ${address}.pdf`,
        content: pdf,
      });
    }
  } else {
    const url = `${req.protocol}://${req.get(
      "host"
    )}/public/document/${id}?customer=${
      customer == "business" ? "propietario" : customer
    }`;
    const pdf = await createPDF(url, authorization);
    if (bussiness.manual) {
      attachments.push({
        filename: "Canales de atención.pdf",
        path: `https://res.cloudinary.com/${CLOUDINARY_NAME}/image/upload/${bussiness.manual[0].public_id}.pdf`,
      });
    }

    attachments.push({
      filename:
        customer == "arrendatario"
          ? `Inventario y acta de entrega inmueble ${address}.pdf`
          : `Inventario del inmueble ${address}.pdf`,
      content: pdf,
    });
  }

  await Mail.sendMail({
    from,
    subject,
    context,
    to: to.email,
    template: customer == "business" ? "registry" : "document",
    attachments,
  });
};
