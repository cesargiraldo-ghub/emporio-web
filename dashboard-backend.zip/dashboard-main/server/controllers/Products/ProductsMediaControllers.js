import Products from "#models/ProductsModels.js";
import cloudinary, {
  uploadProductsMedia,
  uploadFiles,
} from "#utils/cloudinary.js";

export const updateFileSing = async (req, res) => {
  try {
    const {
      params: { id, attr },
    } = req;
    const result = uploadFiles(`${id}-${Date.now()}`, `products/${id}/${attr}`);
    res.status(200).json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json(e);
  }
};

export const updateProductMedia = async (req, res) => {
  try {
    const { id, attr } = req.params;
    const image = req.body;
    const { attrs: currents } = await Products.findOne({
      attributes: ["attrs"],
      where: { id },
    });

    currents.forEach((item) => {
      if (item.idPanel == attr) item.images.push(image);
    });

    await Products.update({ attrs: currents }, { where: { id } });
    const { attrs } = await Products.findOne({
      where: { id },
      attributes: ["attrs"],
    });
    res.status(200).json({ attrs, message: "Imagenes actualizadas" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteProductMedia = async (req, res) => {
  try {
    const { id, attr } = req.params;
    const {
      image: { public_id, resource_type },
    } = req.body;
    const { attrs: currents } = await Products.findOne({
      attributes: ["attrs"],
      where: { id },
    });

    currents.forEach((item) => {
      if (item.idPanel == attr)
        item.images = item.images.filter((img) => img.public_id != public_id);
    });

    cloudinary.uploader.destroy(public_id, { resource_type });

    await Products.update({ attrs: currents }, { where: { id } });
    const { attrs } = await Products.findOne({
      where: { id },
      attributes: ["attrs"],
    });

    res.status(200).json({ attrs, message: "Imagen eliminada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteProductMedias = async (req, res) => {
  try {
    const { id, attr } = req.params;
    const images = req.body;
    const { attrs: currents } = await Products.findOne({
      attributes: ["attrs"],
      where: { id },
    });
    currents.forEach((item) => {
      if (item.idPanel == attr)
        item.images = item.images.filter(
          (img) => !images.find(({ public_id }) => public_id == img.public_id)
        );
    });

    images.forEach(async ({ public_id, resource_type }) => {
      await cloudinary.uploader.destroy(public_id, { resource_type });
    });

    await Products.update({ attrs: currents }, { where: { id } });
    const { attrs } = await Products.findOne({
      where: { id },
      attributes: ["attrs"],
    });

    res.status(200).json({ attrs, message: "Imagenes eliminadas" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteObservationMedia = async (req, res) => {
  try {
    const { id, obs, type } = req.params;
    const {
      image: { public_id, resource_type },
      supplier
    } = req.body;
    const { observations: currents } = await Products.findOne({
      attributes: ["observations"],
      where: { id },
    });

    currents.forEach((item) => {
      if (item.id == obs){
        if(supplier && type === "supplier"){
          item?.supplier?.forEach((sp) => {
            if(sp.id == supplier){
              sp.doc = [];
            }
          })
        }else {
          item[`images_${type}`] = item[`images_${type}`].filter((img) => img.public_id != public_id);
        }
      }
    });

    cloudinary.uploader.destroy(public_id, { resource_type });

    await Products.update({ observations: currents }, { where: { id } });
    const { observations } = await Products.findOne({
      where: { id },
      attributes: ["observations"],
    });

    res.status(200).json({ observations, message: "Imagenes eliminadas" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteObservationMedias = async (req, res) => {
  try {
    const { id, obs, type } = req.params;
    const images = req.body;
    const { observations: currents } = await Products.findOne({
      attributes: ["observations"],
      where: { id },
    });
    currents.forEach((item) => {
      if (item.id == obs)
        item[`images_${type}`] = item[`images_${type}`].filter(
          (img) => !images.find(({ public_id }) => public_id == img.public_id)
        );
    });

    images.forEach(async ({ public_id, resource_type }) => {
      await cloudinary.uploader.destroy(public_id, { resource_type });
    });

    await Products.update({ observations: currents }, { where: { id } });
    const { observations } = await Products.findOne({
      where: { id },
      attributes: ["observations"],
    });

    res.status(200).json({ observations, message: "Imagen eliminada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getFolder = async (req, res) => {
  try {
    const result = await cloudinary.api.resources({ max_results: 5 });
    console.log({ result });
    res.status(200).json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json(e);
  }
};
