import Products, {
  SingleProductsOptions,
  leased_state,
} from "#models/ProductsModels.js";
import { bussinessSettigns, templateTerms } from "#models/SettingsModels.js";
import { onResponsible } from "#utils/helpers.js";
import sequelize from "../../db/index.js";
import { sendMailProductDocument } from "./ProductsDocumentsControllers.js";

export const getProductState = async (req, res) => {
  try {
    const {
      params: { id },
      query: { customer },
    } = req;

    const result = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
    });
    if (result) {
      const row = result.toJSON();
      if (
        (row.attrs.length &&
          row.user &&
          ((row.date_inventory &&
            row.leased_state == leased_state.draft[0] &&
            row.proprietor &&
            !row.signature_proprietor &&
            customer == "propietario") ||
            (row.date &&
              row.leased_state == leased_state.draft[0] &&
              row.leaseholder &&
              !row.signature &&
              customer == "arrendatario"))) ||
        (row.signature_proprietor &&
          ["draft", "leased"].includes(row.leased_state) &&
          customer == "propietario") ||
        (row.signature &&
          ["draft", "leased"].includes(row.leased_state) &&
          customer == "arrendatario")
      ) {
        res.status(200).json({ auth: req.authPublic ? true : false });
      } else {
        res.status(403).json({
          message:
            "Lo sentimos pero por el momento no esta disponile este producto",
        });
      }
    } else {
      res.sendStatus(404);
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getProductLeaseholder = async ({ authPublic, ...req }, res) => {
  try {
    const {
      params: { id },
      query: { customer },
      body: { keyword },
    } = req;

    const result = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
    });
    if (result) {
      const row = result.toJSON();
      const [customerNit, customerId] = keyword?.split("-") || [];

      let currentCustomer = null;
      switch (customer) {
        case "arrendatario":
          currentCustomer = row.leaseholder;
          break;
        case "propietario":
          currentCustomer = row.proprietor;
          break;
      }

      if (
        (((currentCustomer &&
          currentCustomer?.nit == customerNit &&
          currentCustomer?.id == customerId) ||
          authPublic) &&
          row.attrs.length &&
          row.user &&
          ((row.date_inventory &&
            row.leased_state == leased_state.draft[0] &&
            row.proprietor &&
            !row.signature_proprietor &&
            customer == "propietario") ||
            (row.date &&
              row.leased_state == leased_state.draft[0] &&
              row.leaseholder &&
              !row.signature &&
              customer == "arrendatario"))) ||
        (row.signature_proprietor &&
          ["draft", "leased"].includes(row.leased_state) &&
          customer == "propietario") ||
        (row.signature &&
          ["draft", "leased"].includes(row.leased_state) &&
          customer == "arrendatario") ||
        authPublic
      ) {
        const rows = await bussinessSettigns.findAll({
          attributes: { exclude: ["createdAt", "updatedAt"] },
        });

        const context = {};
        if (row && rows.length) {
          const options = templateTerms(rows, row);

          Object.assign(context, { row, options });
        }

        res.status(200).json(context);
      } else {
        res.status(403).json({ message: "Acceso invalido" });
      }
    } else {
      res.status(404).json({ message: "Producto no existente" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updateProductStateLeased = async (req, res) => {
  const { authPublic } = req;
  const transaction = await sequelize.transaction();
  try {
    const {
      params: { id },
      query: { customer },
      body: { keyword, signature, tyc, policy },
    } = req;

    const [customerNit, customerId] = keyword?.split("-") || [];

    const row = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
      transaction,
    });

    const data = {};
    let currentCustomer = null;
    switch (customer) {
      case "arrendatario":
        currentCustomer = row.leaseholder;
        Object.assign(data, {
          signature,
          tyc,
          policy,
          leaseholder_data: currentCustomer,
        });
        break;
      case "propietario":
        currentCustomer = row.proprietor;
        data.signature_proprietor = signature;
        data.proprietor_data = currentCustomer;
        break;
    }

    if (
      ((currentCustomer &&
        currentCustomer?.nit == customerNit &&
        currentCustomer?.id == customerId) ||
        authPublic) &&
      row.attrs.length &&
      row.user &&
      ((row.date_inventory &&
        row.leased_state == leased_state.draft[0] &&
        row.proprietor &&
        customer == "propietario") ||
        (tyc &&
          row.date &&
          row.leased_state == leased_state.draft[0] &&
          row.leaseholder &&
          customer == "arrendatario"))
    ) {
      await row.update(data, { transaction });

      if (row.signature && row.signature_proprietor) {
        await row.update(
          { leased_state: leased_state.leased[0] },
          { transaction }
        );
      }

      await transaction.commit();

      res.status(210).json({ message: "Documento diligenciado exitosamente" });

      if (row.signature && row.signature_proprietor) {
        await sendMailProductDocument(id, "propietario", req);
        await sendMailProductDocument(id, "arrendatario", req);
        await sendMailProductDocument(id, "business", req);
      }
    } else {
      res.status(403).json({ message: "Datos incompletos" });
      await transaction.rollback();
    }
  } catch (e) {
    await transaction.rollback();
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getObservationState = async (req, res) => {
  try {
    const {
      params: { id, obs },
      query: { customer },
    } = req;

    const { observations, leased_state } = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
    });
    const result = observations.find((item) => item.id == obs);

    if (result) {
      const { id, status, responsible, images_solution, observation_solved } =
        result;

      if (
        (customer == "propietario" ||
          (!observation_solved && customer == "proveedor") ||
          (leased_state == "leased" && customer == "encargado-autorizado")) &&
        id &&
        images_solution &&
        images_solution.length &&
        ["canceled", "solved", "finished"].includes(status) &&
        responsible
      ) {
        res.status(200).json({ auth: req.authPublic ? true : false });
      } else {
        res.status(403).json({
          message:
            "Lo sentimos pero por el momento no esta disponile este producto",
        });
      }
    } else {
      res.sendStatus(404);
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
export const getProductObservation = async ({ authPublic, ...req }, res) => {
  try {
    const {
      params: { id, obs },
      query: { customer },
      body: { keyword },
    } = req;

    const { observations } = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
    });
    const result = observations.find((item) => item.id == obs);

    if (result) {
      const { id, status, date_solution } = result;
      const [kId, kDate] = keyword?.split("-") || [];

      if (
        ["propietario", "proveedor", "encargado-autorizado"].includes(
          customer
        ) &&
        ((["canceled", "solved", "finished"].includes(status) &&
          id == kId &&
          kDate == date_solution.replace(/\-/gi, "")) ||
          authPublic)
      ) {
        result.images_problem = result.images_problem.filter(
          (img) => img.format != "pdf"
        );
        result.images_solution = result.images_solution.filter(
          (img) => img.format != "pdf"
        );
        delete result.supplier;
        res.status(200).json({ row: result });
      } else {
        res.status(403).json({ message: "Acceso invalido" });
      }
    } else {
      res.status(404).json({ message: "Producto no existente" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
export const updateObservationState = async ({ authPublic, ...req }, res) => {
  try {
    const {
      params: { id, obs },
      query: { customer },
      body: { keyword, signature, tenant },
    } = req;

    const { observations } = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
    });
    const result = observations.find((item) => item.id == obs);

    if (result) {
      const { id: obsId, status, date_solution } = result;
      const [kId, kDate] = keyword?.split("-") || [];
      if (
        ["propietario", "proveedor", "encargado-autorizado"].includes(
          customer
        ) &&
        ((status == "solved" &&
          obsId == kId &&
          kDate == date_solution.replace(/\-/gi, "")) ||
          authPublic)
      ) {
        observations.forEach((item) => {
          if (item.id == obs) {
            item[onResponsible(customer)] = signature;
            item.tenant = tenant;
            if (
              (item.observation_solved && item.proprietorSignature) ||
              (item.proprietorSignature &&
                item.supplierSignature &&
                item.tenantSignature)
            ) {
              item.status = "finished";
            }
          }
        });
        await Products.update({ observations }, { where: { id } });
        res
          .status(210)
          .json({ message: "Documento diligenciado exitosamente" });
      } else {
        res.status(403).json({ message: "Datos incompletos" });
      }
    } else {
      res.status(404).json({ message: "Producto no existente" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
