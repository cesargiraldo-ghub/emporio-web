import { Op } from "sequelize";
import ProductsData, {
  ProductsDataOptions,
  ProductsDataOptionsSettings,
  excelSchemaProducts,
  readExcelFile,
  leased_state,
} from "#models/ProductsDataModels.js";

import writeXlsxFile from "write-excel-file/node";

import fs from "fs";

export const importProducts = async (req, res) => {
  const createdBy = req.user_id;
  try {
    const data = await readExcelFile(req.file.path, createdBy);
    const currentRows = await ProductsData.findAll(ProductsDataOptions);

    const create = data.filter((item) => {
      const result = currentRows.find((row) => row?.code == item?.code);
      return !result;
    });

    if (create.length) await ProductsData.bulkCreate(create);
    const update = currentRows.map((item) => {
      const row = item.toJSON();
      const result = data.find((r) => row?.code == r?.code);

      if (result) {
        delete result.leased_state;
      }

      return result
        ? { ...result, leased_state: "available", id: row.id }
        : { ...row, leased_state: "retired", id: row.id };
    });

    if (update.length)
      for (let item of update) {
        await ProductsData.update(item, {
          where: { code: item.code, id: item.id },
        });
      }

    const rows = await ProductsData.findAll(ProductsDataOptions);

    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
  fs.unlink(req.file.path, (error) => {
    if (error) return new Error();
    console.log(`Delete ${req.file.path}`);
  });
};

export const exportProducts = async (req, res) => {
  try {
    const rows = await ProductsData.findAll(ProductsDataOptionsSettings);
    const file = await writeXlsxFile(rows, {
      schema: excelSchemaProducts,
      buffer: true,
      fileName: `${Date.now()}-inmuebles.xlsx`,
    });

    res.type(
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.send(file);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getProducts = async (req, res) => {
  try {
    const rows = await ProductsData.findAll(ProductsDataOptions);
    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getProduct = async (req, res) => {
  const { id } = req.params;
  try {
    const row = await ProductsData.findOne({
      ...ProductsDataOptions,
      where: { id },
    });
    res.status(200).json({ row });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const createProduct = async (req, res) => {
  try {
    const createdBy = req.user_id;
    const {
      proprietor: proprietorId,
      leaseholder: leaseholderId,
      bussiness_type: bussinessType,
      product_type: productsType,
      ...data
    } = req.body;
    const { id } = await ProductsData.create({
      ...data,
      proprietorId,
      leaseholderId,
      createdBy,
      bussinessType,
      productsType,
    });
    const row = await ProductsData.findOne({
      ...ProductsDataOptions,
      where: { id },
    });
    res.status(200).json({ row, message: "Productos creado" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updateProduct = async (req, res) => {
  const { id } = req.params;
  const {
    proprietor: proprietorId,
    leaseholder: leaseholderId,
    bussiness_type: bussinessType,
    product_type: productsType,
    ...data
  } = req.body;

  try {
    await ProductsData.update(
      {
        ...data,
        proprietorId,
        leaseholderId,
        bussinessType,
        productsType,
      },
      { where: { id } }
    );
    const row = await ProductsData.findOne({
      ...ProductsDataOptions,
      where: { id },
    });

    res.status(200).json({ row, message: "Productos actualizado" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado", e });
  }
};

export const deleteProduct = async (req, res) => {
  const { id } = req.params;
  try {
    const row = await ProductsData.findOne({
      ...ProductsDataOptions,
      where: { id, leased_state: leased_state.retired[0] },
    });
    if (row) {
      await ProductsData.destroy({ where: { id } });
      res.status(200).json({ message: "Producto eliminado" });
    } else {
      res.status(406).json({ message: "El producto debe estar archivado" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const bulkDeleteProduct = async (req, res) => {
  const { ids } = req.body;
  try {
    const retired = await ProductsData.findAll({
      attributes: ["id", "leased_state"],
      where: {
        [Op.and]: {
          id: { [Op.in]: ids },
          leased_state: leased_state.retired[0],
        },
      },
    });
    const products = await ProductsData.findAll({
      attributes: ["id", "leased_state"],
      where: {
        [Op.and]: {
          id: { [Op.in]: ids },
          leased_state: { [Op.ne]: leased_state.retired[0] },
        },
      },
    });
    if (products.length) {
      const IDS = products.map(({ dataValues: { id } }) => id);
      await ProductsData.update(
        { leased_state: leased_state.retired[0] },
        { where: { id: { [Op.in]: IDS } } }
      );
    }
    if (retired.length) {
      const IDS = retired.map(({ dataValues: { id } }) => id);
      await ProductsData.destroy({ where: { id: { [Op.in]: IDS } } });
    }
    const rows = await ProductsData.findAll(ProductsDataOptions);
    res.status(200).json({
      rows,
      message: "Productos eliminados o retirados exitosamente",
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
