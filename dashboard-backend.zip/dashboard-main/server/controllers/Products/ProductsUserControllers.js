import Products, { ProductsOptions } from "#models/ProductsModels.js";

export const getProducts = async (req, res) => {
  try {
    const userId = req.params.id || req.user_id;
    const rows = await Products.findAll({
      ...ProductsOptions,
      where: { userId },
    });
    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
