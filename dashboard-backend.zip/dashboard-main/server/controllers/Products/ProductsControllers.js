import { Op } from "sequelize";
import Products, {
  ProductsOptions,
  SingleProductsOptions,
  leased_state,
} from "#models/ProductsModels.js";

export const getProducts = async (req, res) => {
  try {
    let rows = await Products.findAll({ ...ProductsOptions });
    rows = rows.map((item) => {
      const row = item.toJSON();
      return { ...row, observations: row?.observations?.length };
    });
    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getProduct = async (req, res) => {
  const { id } = req.params;
  try {
    const row = await Products.findOne({
      ...SingleProductsOptions,
      paranoid: false,
      where: { id },
    });
    res.status(200).json({ row });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const createProduct = async (req, res) => {
  const {
    user: userId,
    second_user: secondUser,
    proprietor: proprietorId,
    leaseholder: leaseholderId,
    bussiness_type: bussinessType,
    product_type: productsType,
    ...data
  } = req.body;
  const createdBy = req.user_id;

  try {
    const { id } = await Products.create({
      ...data,
      images: [],
      userId,
      secondUser,
      proprietorId,
      leaseholderId,
      createdBy,
      bussinessType,
      productsType,
      leased_state: "draft",
    });
    const row = await Products.findOne({
      ...SingleProductsOptions,
      where: { id },
    });
    res.status(200).json({ row, message: "Productos creado" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    let current = await Products.findOne({ where: { id } });
    current = current.toJSON();
    if (current.leased_state != leased_state.finished[0]) {
      const {
        observations,
        images,
        user: userId,
        date,
        second_user: secondUser,
        proprietor: proprietorId,
        leaseholder: leaseholderId,
        bussiness_type: bussinessType,
        product_type: productsType,
        leased_state: leasedState,
        attrs,
        ...payload
      } = req.body;

      const data = { leased_state: leasedState };
      Object.assign(data, {
        ...payload,
        attrs,
        date,
        userId,
        secondUser,
        proprietorId,
        leaseholderId,
        bussinessType,
        productsType,
      });

      if (
        ["initial", "delivery", "leased"].includes(current.leased_state) &&
        observations
      ) {
        const element = current.observations.find(
          ({ id }) => id == observations.id
        );
        if (element) {
          const { images_problem, images_solution, ...ob } = observations;
          current.observations.forEach((item) => {
            if (item.id == observations.id) {
              if (!item.images_problem) item.images_problem = [];
              if (!item.images_solution) item.images_solution = [];
              if (!item.supplier) item.supplier = [];
              if (!item.observations) item.observations = [];
              Object.assign(item, { ...ob });
              const images = { images_problem, images_solution };
              for (let key in images) {
                if (!Array.isArray(images[key]) && images[key])
                  Object.assign(item, { [key]: [...item[key], images[key]] });
              }
            }
          });

          Object.assign(data, {
            observations: [...current.observations],
          });
        } else {
          if (observations.id) observations.status = "reception";

          Object.assign(data, {
            observations: [...current.observations, observations],
          });
        }
      }

      let message = "Productos actualizado";

      await Products.update(data, { where: { id } });
      const row = await Products.findOne({
        ...SingleProductsOptions,
        where: { id },
      });

      row.proprietor_data = row.proprietor;
      row.leaseholder_data = row.leaseholder;

      if (!row.proprietor) row.signature_proprietor = null;
      if (!row.leaseholder) row.signature = null;

      await row.save();

      res.status(200).json({ row, message });
    } else {
      res.status(200).json({ message: "Contrato finalizado" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado", e });
  }
};

export const deleteProduct = async (req, res) => {
  const { id } = req.params;
  try {
    const row = await Products.findOne({
      attributes: ["id", "leased_state"],
      where: {
        id,
        leased_state: {
          [Op.in]: [leased_state.draft[0], leased_state.finished[0]],
        },
      },
    });
    if (row) {
      await Products.destroy({ where: { id } });

      const row = await Products.findOne({
        ...ProductsOptions,
        where: { id },
      });
      res.status(200).json({ row, message: "Producto eliminado" });
    } else {
      res.status(406).json({ message: "El producto debe estar archivado" });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const bulkDeleteProduct = async (req, res) => {
  const { ids } = req.body;
  try {
    const products = await Products.findAll({
      attributes: ["id", "leased_state"],
      where: {
        [Op.and]: {
          id: { [Op.in]: ids },
          leased_state: {
            [Op.in]: [leased_state.draft[0], leased_state.finished[0]],
          },
        },
      },
    });

    if (products.length) {
      await Products.destroy({
        where: {
          [Op.and]: {
            id: { [Op.in]: ids },
            leased_state: {
              [Op.in]: [leased_state.draft[0], leased_state.finished[0]],
            },
          },
        },
      });
    }
    const rows = await Products.findAll(ProductsOptions);
    res.status(200).json({
      rows,
      message: "Productos eliminados o archivados exitosamente",
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
