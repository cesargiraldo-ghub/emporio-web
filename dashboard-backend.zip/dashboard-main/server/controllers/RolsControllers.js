import {Op} from "sequelize"
import sequelize from "#db"
import {mapModules} from "#utils/helpers.js"
import Rols from "#models/RolsModels.js"
import Modules from "#models/ModulesModels.js"
import Permissions from "#models/PermissionsModels.js"
import RolsPermissions, {getRolPermissions} from "#models/RolsPermissionsModels.js"

const fields = ["createdAt",  "updatedAt"];
const options = {
	attributes:{
		exclude: [ ...fields ]
	}
}

export const getRols = async (req, res) => {
	try{
		const rows = await Rols.findAll({...options, where: {
			ranking: {
				[Op.gt]: "0"
			}
		}})

		res.status(200).json({
			rows
		})
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const createRol = async (req, res) => {
	const {ranking, alias: als, ...data} = req.body;
	try{
		const alias = `${data.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()}_${Date.now()}`;
		
		const {id} = await Rols.create({alias, ranking: "2", ...data});
		const row = await Rols.findOne({...options, where: {id}});
		res.status(200).json({row, message: "Rol registrado"});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const deleteRol = async (req, res) => {
	const {id} = req.params;
	try{
		const result = await Rols.destroy({where: {id}});
		res.status(200).json({message: "Rol eliminado"});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const getModules = async (req, res) => {
	try{
		const modules = await Modules.findAll({...options});
		const permissions = await Permissions.findAll({...options});

		const rows = modules.map(item => ({...item.toJSON(), permissions}));

		res.status(200).json({
			rows
		})
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const getRolPermission = async (req, res) => {
	const {rolId} = req.params;
	try{
		const result = await getRolPermissions(rolId);
		if(result){
			const rol = mapModules(result);
			res.status(200).json(rol);
		}else{
			res.status(200).json([]);
		}

	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const updateRolPermission = async ({rol_alias, ...req}, res) => {
	const {rolId} = req.params;
	const {modules} = req.body;
	try{
		const data = [];
		modules.forEach(({permissions, ...Module}) => {
			permissions.forEach((Permission) => {
				data.push({
					rolId,
					moduleId: Module.id,
					permissionId: Permission.id
				})
			})
		});
		
		const rolResult = await Rols.findOne({where: {
			id: rolId,
			ranking: rol_alias == "super_admin" ? {[Op.gt]: "0"} : {[Op.gt]: "1"}
		}});
		if(rolResult){
			await RolsPermissions.destroy({where: {rolId}});
			await RolsPermissions.bulkCreate(data);

			res.status(200).json({message: "Permisos actulizados"})
		}else{
			res.status(403).json({message: "No tienes permiso para realizar esta acción"});
		}
	}catch(e){
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" });
	}
}
