import { Op } from "sequelize";
import { bussinessSettigns } from "#models/SettingsModels.js";
import cloudinary, { uploadBrand, uploadDocument } from "#utils/cloudinary.js";

const excludeDate = ["createdAt", "updatedAt"];
const options = {
  attributes: {
    exclude: [...excludeDate],
  },
};

export const getOptions = async (req, res) => {
  try {
    const rows = await bussinessSettigns.findAll(options);
    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updateOptions = async (req, res) => {
  const data = req.body;
  try {
    for (let { key, value } of data) {
      const row = await bussinessSettigns.findOne({ where: { key } });
      const [result] = await bussinessSettigns.update(
        { value },
        { where: { key } }
      );
      if (!result && !row) await bussinessSettigns.create({ value, key });
    }
    const rows = await bussinessSettigns.findAll(options);
    res.status(200).json({ rows, message: "Cambios guardados" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const getBrand = async (req, res) => {
  try {
    const rows = await bussinessSettigns.findAll({
      ...options,
      where: { key: { [Op.in]: ["photo", "name"] } },
    });
    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updateBrandSign = async (req, res) => {
  const id = req.user_id;
  const user = req.body;
  try {
    const result = uploadBrand(`${id}-${Date.now()}`, id);
    res.status(200).json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json(e);
  }
};

export const updateBrand = async (req, res) => {
  const value = JSON.stringify(req.body);
  const key = "photo";
  try {
    const photo = await bussinessSettigns.findOne({
      ...options,
      where: { key },
    });

    if (photo?.value) cloudinary.uploader.destroy(photo.value.public_id);

    const [result] = await bussinessSettigns.update(
      { value },
      { where: { key } }
    );
    if (!result) await bussinessSettigns.create({ value, key });

    const rows = await bussinessSettigns.findAll({ ...options });

    res.status(200).json({ rows, message: "Foto actualizada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteBrand = async (req, res) => {
  const key = "photo";
  try {
    const { value } = await bussinessSettigns.findOne({ where: { key } });
    const { result } = await cloudinary.uploader.destroy(value?.public_id);
    if (result === "ok")
      await bussinessSettigns.update({ value: null }, { where: { key } });

    const rows = await bussinessSettigns.findAll({ ...options });

    res.status(200).json({ rows, message: "Foto eliminada" });
  } catch (e) {
    console.error(e);
    res.status(500).json(e);
  }
};

export const updateDocumentSign = async (req, res) => {
  try {
    const id = req.user_id;
    const { key } = req.params;
    let date = new Date();
    date = date.toLocaleString('es-CO', {dateStyle: "short"});
    date = date.replace(/\D/g, "");
    const result = uploadDocument(`${id}-${key}-${date}`, id);
    res.status(200).json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json(e);
  }
};

export const updateDocument = async (req, res) => {
  const { key } = req.params;
  const value = JSON.stringify(req.body);
  try {
    const row = await bussinessSettigns.findOne({ ...options, where: { key } });
    if (row && row[0]?.public_id) {
      cloudinary.uploader.destroy(row[0].public_id);
    }

    const [result] = await bussinessSettigns.update(
      { value },
      { where: { key } }
    );
    if (!result) await bussinessSettigns.create({ value, key });

    const rows = await bussinessSettigns.findAll({ ...options });

    res.status(200).json({ rows, message: "Documento actualizada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const deleteDocument = async (req, res) => {
  const { key } = req.params;
  try {
    const row = await bussinessSettigns.findOne({ ...options, where: { key } });
    if (row && row[0]?.public_id) {
      cloudinary.uploader.destroy(row[0].public_id);
    }
    await bussinessSettigns.update({ value: null }, { where: { key } });

    const rows = await bussinessSettigns.findAll({ ...options });

    res.status(200).json({ rows, message: "Documento eliminada" });
  } catch (e) {
    console.error(e);
    res.status(500).json(e);
  }
};
