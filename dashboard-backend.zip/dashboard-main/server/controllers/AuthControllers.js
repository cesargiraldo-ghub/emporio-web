import Users from "#models/users/UsersModels.js";
import UsersTokens from "#models/users/UsersTokensModels.js";
import { createToken } from "#utils/jwt.js";
import Mail from "#utils/mailers.js";
import bcrypt from "bcrypt";
import crypto from "crypto";
import * as Redis from "#utils/redis.js";
import { getRolPermissions } from "#models/RolsPermissionsModels.js";
import { mapModules } from "#utils/helpers.js";
import { ORIGIN } from "#config";
import { Op } from "sequelize";
import { bussinessSettigns } from "#models/SettingsModels.js";
import { rowsToJSON } from "#utils/helpers.js";

const fields = ["createdAt", "updatedAt"];
const options = {
  include: {
    all: true,
    attributes: {
      exclude: [...fields],
    },
  },
  attributes: {
    exclude: ["password", "genderId", "rolId", ...fields],
  },
};

export const signIn = async (req, res) => {
  const { email, keyword } = req.body;
  try {
    if (email && keyword) {
      const row = await Users.findOne({ where: { email } });
      if (row) {
        const { password, ...user } = row.toJSON();
        const compare = await bcrypt.compare(keyword, password);

        if (compare) {
          const { id } = user;
          const tokens = createToken({ id, email });
          res.status(200).json({
            tokens,
            message: `Bienvenido ${user.name} ${user.last}`,
          });
        } else {
          res.status(403).json({
            message: "Password incorrecto",
          });
        }
      } else {
        res.status(404).json({
          message: "Usuario no registrado",
        });
      }
    } else {
      res.status(400).json({
        message: "Email y Password son requeridos",
      });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const signUp = async (req, res) => {
  const { keyword, ...data } = req.body;
  try {
    const password = await bcrypt.hash(toString(keyword), 10);
    const result = await Users.create({ password, ...data });
    res.status(200).json({
      message: "Cuenta creada",
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const signOut = async (req, res) => {
  const { iat, exp } = req.auth;
  try {
    await Redis.setKey(iat, exp);
    res.status(200).json({
      message: "Vuelve pronto",
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const onSignIn = async (req, res) => {
  const id = req.user_id;
  try {
    const row = await Users.findOne({ ...options, where: { id } });
    if (row) {
      const result = await getRolPermissions(row.rol.id);
      let modules = [];
      if (result) modules = mapModules(result);

      res.status(200).json({
        row,
        modules,
      });
    } else {
      res.sendStatus(401);
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const createTokenPassword = async (req, res) => {
  try {
    const { email } = req.body;
    if (email) {
      let user = await Users.findOne({ where: { email } });
      if (user) {
        const result = await UsersTokens.findOne({
          where: { userId: user.id },
        });
        const token = crypto.randomBytes(32).toString("hex");
        let link = null;
        if (result) {
          let { userId } = result;
          await UsersTokens.update({ token }, { where: { userId } });
          link = `${ORIGIN}/reset-password/${userId}/${token}`;
        } else {
          let { userId } = await UsersTokens.create({ userId: user.id, token });
          link = `${ORIGIN}/reset-password/${userId}/${token}`;
        }

        const rows = await bussinessSettigns.findAll({
          where: { key: { [Op.in]: ["name", "photo"] } },
        });
        const bussiness = rowsToJSON(rows);

        user = user.toJSON();
        const context = { link, ...user, bussiness };
        const mail = link
          ? await Mail.sendMail({
              from: `"${bussiness.name}" <no-reply@emporiobienes.com>`,
              to: user.email,
              subject: "Recuperar contraseña",
              template: "template",
              context,
            })
          : null;

        res.status(200).json({
          message: "Correo enviado",
        });
      } else {
        res.status(404).json({
          message: "Usuario no registrado",
        });
      }
    } else {
      res.status(400).json({
        message: "Email requerido",
      });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const validateTokenPassword = async (req, res) => {
  const where = req.params;
  try {
    const result = await UsersTokens.findOne({ where });
    if (result) {
      res.sendStatus(200);
    } else {
      res.sendStatus(403);
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const updatePassword = async (req, res) => {
  const { userId, token } = req.params;
  const { keyword } = req.body;

  try {
    const result = await UsersTokens.findOne({ where: { userId, token } });
    if (result) {
      const password = await bcrypt.hash(keyword, 10);
      await Users.update({ password }, { where: { id: userId } });
      await UsersTokens.destroy({ where: { userId } });
      res.status(200).json({
        message: "Contraseña actualizada",
      });
    } else {
      res.sendStatus(403);
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};
