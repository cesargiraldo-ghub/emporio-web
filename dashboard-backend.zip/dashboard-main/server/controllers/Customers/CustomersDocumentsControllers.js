import Customers, {
  CustomersOptions,
  excelSchemaCustomers,
  excelRelationCustomers,
} from "#models/customers/CustomersModels.js";
import CustomersTypes from "#models/customers/CustomersTypesModels.js";
import writeXlsxFile from "write-excel-file/node";
import readXlsxFile from "read-excel-file/node";
import fs from "fs";
import puppeteer from "puppeteer";
import { clearString } from "#utils/helpers.js";

export const exportCustomers = async (req, res) => {
  try {
    const customersTypes = await CustomersTypes.findAll();
    const rows = await Customers.findAll(CustomersOptions);
    rows.forEach((row) => {
      row.customerType = row.customerType.map(
        (id) => customersTypes.find((ct) => ct.id == id)?.name
      );
    });
    console.log(rows);
    const file = await writeXlsxFile(rows, {
      schema: excelSchemaCustomers,
      buffer: true,
      fileName: `${Date.now()}-clientes.xlsx`,
    });
    res.type(
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.send(file);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Ocurrio un problema inesperado" });
  }
};

export const importCustomers = async (req, res) => {
  try {
    const excel = await readXlsxFile(req.file.path);
    const columns = excel.shift();

    const ct = await CustomersTypes.findAll();

    const data = excel.map((value) => {
      const result = {};

      columns.forEach(async (col, index) => {
        const prop = clearString(col);
        const column = excelRelationCustomers[prop];

        if (column == "customerType") {
          const array = clearString(value[index]).replace(/\s/g, "").split(",");
          const type = [];
          array.forEach((ar) => {
            const id = ct.find((item) => clearString(item.name) == ar)?.id;
            if (id) type.push(id);
          });

          result[column] = type;
        } else {
          result[column] = value[index];
        }
      });
      return result;
    });

    const currentRows = await Customers.findAll(CustomersOptions);

    const create = [];
    const update = [];
    data.forEach((item) => {
      const result = currentRows.find((row) => row?.nit == item?.nit);
      if (result) {
        update.push(item);
      } else {
        create.push(item);
      }
    });

    if (create.length) await Customers.bulkCreate(create);

    if (update.length) {
      for (let { id, ...item } of update) {
        await Customers.update(item, { where: { nit: item.nit } });
      }
    }

    const rows = await Customers.findAll(CustomersOptions);

    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ e, message: "Ocurrio un problema inesperado" });
  }
  fs.unlink(req.file.path, (error) => {
    if (error) return new Error();
    console.log(`Delete ${req.file.path}`);
  });
};
