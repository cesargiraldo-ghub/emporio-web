import Customers, { CustomersOptions } from "#models/customers/CustomersModels.js"

export const getCustomers = async (req, res) => {
	try {
		const rows = await Customers.findAll(CustomersOptions);

		res.status(200).json({ rows });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const getCustomer = async (req, res) => {
	try {
		const { id } = req.params;

		const row = await Customers.findOne({ ...CustomersOptions, where: { id } });
		res.status(200).json({ row });

	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const createCustomer = async (req, res) => {
	try {
		const { proprietor, leaseholder, ...data } = req.body;

		const { id } = await Customers.create({ ...data, proprietorId: proprietor, leaseholderId: leaseholder });
		const row = await Customers.findOne({ ...CustomersOptions, where: { id } });

		res.status(200).json({ row, message: "Cliente registrado" });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const updateCustomer = async (req, res) => {
	try {
		const { id } = req.params;
		const { proprietor, leaseholder, ...data } = req.body;

		await Customers.update({ ...data, proprietorId: proprietor, leaseholderId: leaseholder }, { where: { id } });
		const row = await Customers.findOne({ ...CustomersOptions, where: { id } });

		res.status(200).json({ row, message: "Cliente actualizado" });

	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}