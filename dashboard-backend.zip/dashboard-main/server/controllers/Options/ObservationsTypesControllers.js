import ObservationsTypes, {
  ObservationsTypesOptions,
} from "#models/ObservationTypesModels.js";
export const getObservationsTypes = async (req, res) => {
  try {
    const rows = await ObservationsTypes.findAll(ObservationsTypesOptions);

    res.status(200).json({ rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"})
  }
};

export const createObservationType = async (req, res) => {
  try {
    const { ranking, ...data } = req.body;
    const { id } = await ObservationsTypes.create({
      ...data,
      alias: data.name,
    });
    const row = await ObservationsTypes.findOne({
      attributes: {
        exclude: ["createdAt", "updatedAt"],
      },
      where: { id },
    });

    res.status(200).json({ row, message: "Tipo de observación creada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"})
  }
};

export const updateObservationType = async (req, res) => {
  try {
    const { id } = req.params;
    const { ranking, ...data } = req.body;
    await ObservationsTypes.update(
      { ...data, alias: data.name },
      { where: { id } }
    );
    const row = await ObservationsTypes.findOne({
      attributes: {
        exclude: ["createdAt", "updatedAt"],
      },
      where: { id },
    });

    res.status(200).json({ row, message: "Tipo de observación actualizada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"})
  }
};

export const deleteObservationType = async (req, res) => {
  try {
    const { id } = req.params;
    await ObservationsTypes.destroy({ where: { id } });

    res.status(200).json({ message: "Tipo de observación eliminada" });
  } catch (e) {
    console.error(e);
    res.status(500).json({message: "Ocurrio un problema inesperado"})
  }
};
