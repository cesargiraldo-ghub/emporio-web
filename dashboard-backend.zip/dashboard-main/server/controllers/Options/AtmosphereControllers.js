import Atmosphere, { AtmosphereOptions } from "#models/AtmosphereModels.js"

export const getAtmosphere = async (req, res) => {
	try {
		const rows = await Atmosphere.findAll(AtmosphereOptions);

		res.status(200).json({ rows });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const createAtmosphere = async (req, res) => {
	try {
		const { ranking, ...data } = req.body;
		const { id } = await Atmosphere.create({ ...data, alias: data.name });
		const row = await Atmosphere.findOne({
			attributes: {
				exclude: ["createdAt", "updatedAt"]
			},
			where: { id }
		});

		res.status(200).json({ row, message: "Ambiente creado" });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const updateAtmosphere = async (req, res) => {
	try {
		const { body } = req;

		for(let {alias, ranking, id, ...data} of body){
			await Atmosphere.update(data, { where: { id } });
		}
		
		const rows = await Atmosphere.findAll({
			attributes: {
				exclude: ["createdAt", "updatedAt"]
			}
		});

		res.status(200).json({ rows, message: "Ambiente actualizado" });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}

export const deleteAtmosphere = async (req, res) => {
	try {
		const { id } = req.params;
		await Atmosphere.destroy({ where: { id } });

		res.status(200).json({ message: "Ambiente eliminado" });
	} catch (e) {
		console.error(e);
		res.status(500).json({ message: "Ocurrio un problema inesperado" })
	}
}