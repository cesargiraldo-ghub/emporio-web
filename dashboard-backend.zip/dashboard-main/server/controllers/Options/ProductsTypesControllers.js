import ProductsTypes, { ProductsTypesOptions } from "#models/ProductsTypesModels.js"

export const getProductsTypes = async (req, res) => {
	try{
		const rows = await ProductsTypes.findAll(ProductsTypesOptions);

		res.status(200).json({rows});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const createProductType = async (req, res) => {
	try{
		const {ranking, ...data} = req.body;
		const { id } = await ProductsTypes.create({...data, alias: data.name});
		const row = await ProductsTypes.findOne({
			attributes: {
				exclude: ["createdAt", "updatedAt"]
			},
			where: { id }
		});

		res.status(200).json({row, message: "Tipo de inmueble creado"});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const updateProductType = async (req, res) => {
	try{
		const {id} = req.params;
		const {ranking, ...data} = req.body;
		await ProductsTypes.update({...data, alias: data.name}, {where: {id}});
		const row = await ProductsTypes.findOne({
			attributes: {
				exclude: ["createdAt", "updatedAt"]
			},
			where: { id }
		});

		res.status(200).json({row, message: "Tipo de inmueble actualizado"});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const deleteProductType = async (req, res) => {
	try{
		const {id} = req.params;
		await ProductsTypes.destroy({where: {id}});

		res.status(200).json({message: "Tipo de inmueble eliminado"});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}