import BussinessTypes from "#models/BussinessTypesModels.js"
import ProductsTypes from "#models/ProductsTypesModels.js"
import CustomersTypes from "#models/customers/CustomersTypesModels.js"

export const getCustomersTypes = async (req, res) => {
	try{
		const rows = await CustomersTypes.findAll({
			attributes: {
				exclude: ["createdAt", "updatedAt"]
			}
		});

		res.status(200).json({rows});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}

export const getBussinessTypes = async (req, res) => {
	try{
		const rows = await BussinessTypes.findAll({
			attributes: {
				exclude: ["createdAt", "updatedAt"]
			}
		});

		res.status(200).json({rows});
	}catch(e){
		console.error(e);
		res.status(500).json({message: "Ocurrio un problema inesperado"})
	}
}